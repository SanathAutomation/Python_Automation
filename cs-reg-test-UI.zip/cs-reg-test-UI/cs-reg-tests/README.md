# cs-reg-tests
CloudSure regression test repository.

## Overview
Tests will be structured so that they my be run by pytest.
Test environment specific tests and configurations are placed in separate folders.

## Test Environments


### okd03
CloudSure and Landslide release integration tests specific to the OKD4 cluster on okd03.
See [README.md](tests/okd03/README.md).

### open5gs-k3s
CloudSure and Landslide open5gs tests use a realistic 5g core network for tests.
See [README.md](tests/open5gs-k3s/README.md).

### universal
Universal tests run on any system by specifying command line parameters.
See [README.md](tests/universal/README.md).


## Development Environment
The repository contains a vscode .devcontainer directory which will automatically create a Docker
container with all the dependencies setup.

If you do not use vscode or do not want to use a devcontainer, you will need to create a virtual environment and install python requirements.
Use the following commands:
```bash
virtualenv -p `which python3.11` venv
source venv/bin/activate
pip install -r requirements.txt -r test-requirements.txt
export PYTHONPATH=`pwd`
```

## Coding Style
The code for this project is formatted using [black](https://github.com/psf/black) and imports
are organized with [isort](https://pycqa.github.io/isort/index.html).

There is a .pre-commit-config.yaml file which can be used to enable git hooks for your local
git repository to automatically format with black and run code validation checks with ruff.

Git does not provide a way to enable git hooks in the remote repository so you need to run the
below command to install the git hooks in the local repository if you want to use them.
``` bash
pre-commit install
```

You can manually run the pre-commit hooks using:
```bash
pre-commit run -a
```


The devcontainer configuration for this project enables git hooks and enable vscode format on save.

## Run Regression Tests
To run regression tests from the top-level repo directory:
``` bash
./run-reg-tests.sh tests/okd03
```

Optional CloudSure arguments:
```
  --cs_url=CS_URL       CloudSure application URL
  --aion_url=AION_URL   AION URL
  --email=EMAIL         User's AION email address
  --password=PASSWORD   User's AION password
  --subdomain=SUBDOMAIN
                        AION subdomain
  --project=PROJECT     CloudSure project
  --update_lib=UPDATE_LIB
                        CloudSure update library - IfNotPresent|Always|Never
  --lib_prefix=LIB_PREFIX
                        CloudSure library prefix
  --kubeconfig=KUBECONFIG
                        Kubernetes kubeconfig file
  --kubeconfig_env=KUBECONFIG_ENV
                        Environment name for kubeconfig file
  --profile_ls_overrides=PROFILE_LS_OVERRIDES
                        Landslide profile overrides
  --tc_ls_overrides=TC_LS_OVERRIDES
                        Landslide test case 'template_override_param' overrides
```

## Run UI Automation Tests
For UI Automation test case execution go to cs-reg-tests\uiAutomation.

Run tests using chrome browser with report generation:
```
pytest -s -v --html=Reports\report.html testCases/test_DragAndDropStartLandslide.py --browser chrome
```

Run tests using chrome browser:
```
pytest -s -v testCases/test_DragAndDropStartLandslide.py --browser chrome
```

Run tests using firefox browser:
```
pytest -s -v testCases/test_DragAndDropStartLandslide.py --browser firefox
```

Run tests using edge browser:
```
pytest -s -v testCases/test_DragAndDropStartLandslide.py

```

## Run Unit Tests
Unit tests verify regression APIs outside of the tests and uiAutomation directories.  They do not require a CloudSure installation.
To run the unit tests from the top-level repo directory:
``` bash
./run_tests.sh
```
