# open5gs k3s Tests
open5gs k3s tests use open5gs to test Landslide emulated traffic test cases.
Both Landslide and open5gs (in k3s) are running on VMs on Openstack (Mosel).

List of tests:
* test_open5gs_ls_100_sessions - baseline open5gs landslide test case
* test_open5gs_ls_100_sessions_cpu_impairment - impair user traffic by reducing upf pod limits and verify results using scoring
* test_open5gs_ls_100_sessions_pkt_loss - impair user traffic by introducing  upf packet loss and verify results using scoring
* test_open5gs_ls_100_sessions_pod_delete - impair user traffic by deleting the upf pod and verify results using scoring

# Usage
Setup open5gs as [documented](https://origin.spirenteng.com/display/CLDCNTR/Landslide+Open5gs).

## CloudSure Install

CloudSure install is assumed to run on a separate cluster from the open5gs k3s cluster.
This keeps test plane traffic local to Mosel and allows running the tests cases on different versions of CloudSure.

Chaos agents on the open5gs k3s cluster must be updated to the CloudSure instance.
Create an additional chaos controller LoadBalancer service on the cluster running CloudSure:
```bash
kubectl apply -n $CS_NAMESPACE -f - <<EOF
apiVersion: v1
kind: Service
metadata:
  annotations:
  name: cs-chaos-ctlr-lb
spec:
  ports:
  - name: http
    port: 5180
    protocol: TCP
    targetPort: http
  selector:
    app.kubernetes.io/name: chaos-ctlr
  type: LoadBalancer

EOF
```

Use the following Helm command to update the open5gs k3s cluster external chaos controller:
```bash
helm upgrade --install chaos oci://registry.aiontest.net/helm-charts/chaos --version "0.1.*" -n cs-chaos -f config/open5gs-k3s/helm/chaos_k3s.yaml --set "chaos-agent.externalChaosController.url=http://<LoadBalancerIP>:5180"
```

## Install Python Packages
See cs-reg-tests [README.md](../../README.md)

## Install Kubernetes Testing Resources
Known resources are required on the cluster under test for test cases to work.
For example, a pod delete test requires a named pod in a namespace.
Run the script below to add them (uses kubectl):
```bash
kubectl create namespace cs-reg-tests
./config/open5gs-k3s/k8s/apply_resources.sh -n cs-reg-tests
```

## Run Tests
Tests use the pytest framework.  The 'run-reg-tests.sh' wrapper script conveniently sets some default pytest arguments.

### Run All open5gs k3s Tests
Run from the top level directory:
```bash
./run-reg-tests.sh -s --cs_url $CS_URL --aion_url $AION_URL \
  tests/open5gs
```
