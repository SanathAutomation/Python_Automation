import pytest
from cstest.testcase import RunTestcase

from common import base
from common import impairment_actions_base as actions


def test_open5gs_ls_pod_delete(cs_tc: RunTestcase):
    ex = cs_tc.execute("config/open5gs-k3s/cs/tc_input/open5gs-k3s-ls-100-sessions-pod-delete.json")
    print(f"execution: {ex}")
    print(f"cs_url:{cs_tc.client.cs_url} results_id:{ex.results_id}")

    assert cs_tc.client.cs_url is not None

    pytest.cs_base_url = cs_tc.client.cs_url
    pytest.cs_result_id = ex.results_id

    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    full_name = "landslide_measurement.full_name = 'Test Summary::Sessions Established'"
    assert base.check_landslide_result(full_name, result_id, 100, 200, op="max") is True

    dict_check = {"tab": "'Test Summary'", "measurement": "'Sessions Pending'"}
    value_match = 100
    range_match = 5
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    dict_check = {"tab": "'Test Summary'", "measurement": "'Session Registers'"}
    value_match = 100
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    dict_check = {"tab": "'Test Summary'", "measurement": "'Session Deregisters'"}
    value_match = 100
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    dict_check = {"tab": "'Test Summary'", "measurement": "'Actual Session Connects'"}
    value_match = 175
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    dict_check = {"tab": "'Test Summary'", "measurement": "'Actual Session Disconnects'"}
    value_match = 175
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    dict_check = {"tab": "'L3 Client'", "measurement": "'Total Bytes Received'"}
    value_match = 40000000
    range_match = 35000000
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    assert actions.pod_del_test_validate_time_to_recover(result_id, 3) is True
