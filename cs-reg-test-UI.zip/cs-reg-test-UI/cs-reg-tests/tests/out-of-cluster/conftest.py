import pytest

import cstest.client as client
from cstest.library import Library, UpdatePolicy


@pytest.fixture(scope="session")
def cs_params(cs_params: dict) -> dict:
    params = cs_params
    if not params.get("cs_url"):
        params["cs_url"] = "http://10.109.123.29:31003"
    if not params.get("aion_url"):
        params["aion_url"] = "http://10.109.222.231"
    if not params.get("email"):
        params["email"] = "temeva-dev@spirent.com"
    if not params.get("password"):
        params["password"] = "spirent1234"
    if not params.get("project"):
        params["project"] = "cs-regression-universal-1"
    if not params.get("kubeconfig_env"):
        params["kubeconfig_env"] = "k8s-config"
    if not params.get("kubeconfig"):
        raise Exception("--kubeconfig is required for universal tests")
    return params


@pytest.fixture(autouse=True, scope="session")
def cs_update_library(cs_params: dict, cs_client: client.Client):
    update_libs = cs_params.get("update_lib", "")
    lib_prefix = cs_params.get("lib_prefix", "")
    kubeconfig = cs_params.get("kubeconfig", "")
    kubeconfig_env = cs_params.get("kubeconfig_env", "")
    if update_libs.lower() != "never":
        lib = Library(cs_client)
        try:
            update_policy = UpdatePolicy(update_libs.lower())
        except Exception:
            raise Exception(f"--update_libs {update_libs} should be one of IfNotPresent|Always|Never")
        lib.update(
            "config/ooc-k3s",
            update_policy=update_policy,
            lib_prefix=lib_prefix,
            kubeconfig=kubeconfig,
            kubeconfig_env=kubeconfig_env,
        )
