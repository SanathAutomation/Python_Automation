from cstest.testcase import RunTestcase
import pytest
from common import impairment_actions_base as actions

def test_impairment_node_taint(cs_tc: RunTestcase):
    ex = cs_tc.execute("config/ooc-k3s/cs/tc_input/impairment_node_taint.json")
    print(f"execution: {ex}")
    print(f"cs_url:{cs_tc.client.cs_url} results_id:{ex.results_id}")

    assert cs_tc.client.cs_url is not None
    assert ex.results_id is not None

    pytest.cs_base_url = cs_tc.client.cs_url
    pytest.cs_result_id = ex.results_id

def test_node_taint_test_node_impaired_input_objects():
    """
    In this test case we will compare the content in "Node Impaired Input Objects" Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    # Verify "Node Impaired Input Objects" view [Node Name, Is Impaired]
    values_to_match = ['ssu-k3s-worker03', True]
    assert actions.node_test_validate_node_impaired_input_objects(result_id, values_to_match) is True