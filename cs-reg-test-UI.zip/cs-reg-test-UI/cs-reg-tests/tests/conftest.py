# test/conftest.py
import json

import pytest
import requests
from pytest_metadata.plugin import metadata_key

import cstest.client as client
import cstest.testcase as tc
import cstest.utils.overrides as overrides

pytest.cs_base_url = None
pytest.cs_result_id = None
pytest.profile_ls_overrides = None


def pytest_addoption(parser):
    parser.addoption("--cs_url", help="CloudSure application URL")
    parser.addoption("--aion_url", help="AION URL", default="")
    parser.addoption("--email", help="User's AION email address", default="temeva-dev@spirent.com")
    parser.addoption("--password", help="User's AION password", default="spirent1234")
    parser.addoption("--subdomain", help="AION subdomain", default="spirent")
    parser.addoption("--project", help="CloudSure project", default="")
    parser.addoption("--update_lib", help="CloudSure update library - IfNotPresent|Always|Never", default="IfNotPresent")
    parser.addoption("--lib_prefix", help="CloudSure library prefix", default="")
    parser.addoption("--kubeconfig", help="Kubernetes kubeconfig file", default="")
    parser.addoption("--kubeconfig_env", help="Environment name for kubeconfig file", default="")
    parser.addoption("--profile_ls_overrides", help="Landslide profile overrides", default="")
    parser.addoption("--tc_ls_overrides", help="Landslide test case 'template_override_param' overrides", default="")

    # parser.addoption("--username", action="store", help="input useranme")
    # parser.addoption("--password", action="store", help="input password")


@pytest.fixture(scope="session")
def cs_params(request) -> dict:
    params = {}
    params["cs_url"] = request.config.getoption("--cs_url")
    params["aion_url"] = request.config.getoption("--aion_url")
    params["email"] = request.config.getoption("--email")
    params["password"] = request.config.getoption("--password")
    params["subdomain"] = request.config.getoption("--subdomain")
    params["project"] = request.config.getoption("--project")
    params["update_lib"] = request.config.getoption("--update_lib")
    params["lib_prefix"] = request.config.getoption("--lib_prefix")
    params["kubeconfig"] = request.config.getoption("--kubeconfig")
    params["kubeconfig_env"] = request.config.getoption("--kubeconfig_env")
    params["profile_ls_overrides"] = request.config.getoption("--profile_ls_overrides")
    params["tc_ls_overrides"] = request.config.getoption("--tc_ls_overrides")

    for req_key in ["cs_url", "aion_url", "email", "password", "subdomain", "project"]:
        if req_key not in params:
            pytest.skip()
    return params


@pytest.fixture(scope="session")
def cs_client(cs_params: dict) -> client.Client:
    pytest.profile_ls_overrides = overrides.parse(cs_params["profile_ls_overrides"])

    return client.Client(
        cs_url=cs_params["cs_url"],
        aion_url=cs_params["aion_url"],
        email=cs_params["email"],
        password=cs_params["password"],
        subdomain=cs_params["subdomain"],
    )


@pytest.fixture
def cs_tc(cs_params: dict, cs_client: client.Client) -> tc.RunTestcase:
    return tc.RunTestcase(
        client=cs_client,
        project_name=cs_params["project"],
        lib_prefix=cs_params["lib_prefix"],
        tc_ls_overrides=cs_params["tc_ls_overrides"],
        kubeconfig_env=cs_params["kubeconfig_env"]
    )


def pytest_html_report_title(report):
    """modifying the title  of html report"""
    report.title = "CloudSure Test Report"


@pytest.hookimpl(tryfirst=True)
def pytest_sessionfinish(session, exitstatus):
    base_url = pytest.cs_base_url
    if base_url:
        headers = {"Content-Type": "application/json"}
        url = f"{base_url}/api/appinfo"

        resp = requests.get(url, headers=headers)
        assert resp.status_code == 200
        response = json.loads(resp.content)
        session.config.stash[metadata_key][response["app_name"]] = response["app_version"]

    ls_url = ""
    if pytest.profile_ls_overrides and (ip_addr := pytest.profile_ls_overrides.get("ls_tas_addr")):
        ls_url = f"http://{ip_addr}:8080/api/testServers"

    # TODO: if ls_url is not overridden we could be using the value in the landslide profile
    #       we should get from file on cloudsure profile API

    if ls_url:
        username = "sms"
        password = "a1b2c3d4"
        resp = requests.get(ls_url, auth=(username, password))
        assert resp.status_code == 200
        response = json.loads(resp.content)
        session.config.stash[metadata_key]["landslide_version"] = response["testServers"][0]["version"]
