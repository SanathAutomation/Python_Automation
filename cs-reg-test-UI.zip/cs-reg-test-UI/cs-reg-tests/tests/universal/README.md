# Universal Tests
CloudSure universal tests are structured to run as easily as possible on different systems and Kubernetes distributions.
Ideally you can run all tests by specifying arguments to pytest.

List of tests:
* test_landslide_iterations - verify landslide iterations work
* test_landslide_pod_delete - verify landslide with POD delete works
* test_landslide_traffic_01 - verify landslide traffic works
* test_landslide_wait - verify landslide wait works

Tested Kuberentes distributions:
* Openshift 3
* OKD4
* k3s

# Usage

## Install CloudSure
Cloud native CloudSure installation is required.  See CloudSure helm installation documentation if you need to install it.
It should include the following:
* CloudSure application
* CloudSure impairment controller & agent(s) <- Now part of cloudsure helm chart. SCC and/or privileged need to be configured.
* CloudSure cs-prometheus

## Install Python Packages
See cs-reg-tests [README.md](../../README.md)

## Install Kubernetes Testing Resources
Known resources are required on the cluster under test for test cases to work.
For example, a pod delete test requires a named pod in a namespace. 
Run the script below to add them (uses kubectl):
```bash
kubectl create namespace cs-reg-tests
./config/universal/k8s/apply_resources.sh -n cs-reg-tests
```

## Run Tests
Tests use the pytest framework.  The 'run-reg-tests.sh' wrapper script conveniently sets some default pytest arguments.

### Run All Universal Tests
Run from the top level directory:
```bash
export LS_TAS_ADDR=10.0.0.1
export LS_TS_ID=1

./run-reg-tests.sh -s --cs_url $CS_URL --aion_url $AION_URL --kubeconfig $KUBECONFIG_FILE \
  --lib_prefix "[my-k8s] " \
  --project "[my-k8s] cs-regression-universal" \
  --profile_ls_overrides "ls_tas_addr=$LS_TAS_ADDR" \
  --tc_ls_overrides "ts_id=$LS_TS_ID" \
  tests/universal
```