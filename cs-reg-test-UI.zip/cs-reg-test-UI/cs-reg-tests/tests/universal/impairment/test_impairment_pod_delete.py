from cstest.testcase import RunTestcase
import pytest
from common import impairment_actions_base as actions

def test_impairment_mem(cs_tc: RunTestcase):
    ex = cs_tc.execute("config/universal/cs/tc_input/impairment/pod_delete.json")
    print(f"execution: {ex}")
    print(f"cs_url:{cs_tc.client.cs_url} results_id:{ex.results_id}")

    assert cs_tc.client.cs_url is not None
    assert ex.results_id is not None

    pytest.cs_base_url = cs_tc.client.cs_url
    pytest.cs_result_id = ex.results_id

def test_pod_del_test_time_to_recover():
    """
    In this test case we will compare the number of rows in "Pod-Delete Workflow Results " Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    assert actions.pod_del_test_validate_time_to_recover(result_id, 3) is True
    assert actions.pod_del_test_validate_pod_name(result_id, "reg-ss-0") is True
    