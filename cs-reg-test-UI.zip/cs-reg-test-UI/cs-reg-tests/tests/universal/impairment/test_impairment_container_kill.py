from cstest.testcase import RunTestcase
import pytest
from common import impairment_actions_base as actions


def test_impairment_container_kill(cs_tc: RunTestcase):
    ex = cs_tc.execute("config/universal/cs/tc_input/impairment/container_kill.json")
    print(f"execution: {ex}")
    print(f"cs_url:{cs_tc.client.cs_url} results_id:{ex.results_id}")

    assert cs_tc.client.cs_url is not None
    assert ex.results_id is not None

    pytest.cs_base_url = cs_tc.client.cs_url
    pytest.cs_result_id = ex.results_id


def test_container_kill_test_results():
    """
    In this test case we will compare the number of rows in "Container-Kill Workflow Results " Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    # Verify "Container Kill Work-Flow Results" view [Pod-Name, Container-Name, Time-to-Recover]
    values_to_match = ["reg-ss-0", "hello"]
    assert actions.container_kill_test_validate_workflow_results(result_id, values_to_match, 0) is True

    # Verify "Container Impaired Input Objects" view [Namespace, Pod-Name, Container-Name, Is-Impaired]
    values_to_match = ["cs-reg-tests", "reg-ss-0", "hello", True]
    assert actions.container_impaired_test_validate_container_name(result_id, values_to_match) is True
