from cstest.testcase import RunTestcase
import pytest
from common import base
from common import impairment_actions_base as actions


def test_ls_traffic(cs_tc: RunTestcase):
    ex = cs_tc.execute("config/universal/cs/tc_input/landslide/landslide_test1.json")
    print(f"execution: {ex}")
    print(f"cs_url:{cs_tc.client.cs_url} results_id:{ex.results_id}")

    assert cs_tc.client.cs_url is not None
    assert ex.results_id is not None

    pytest.cs_base_url = cs_tc.client.cs_url
    pytest.cs_result_id = ex.results_id


def test_workflow_execution_table_results():
    """
    In this test case we will compare "Workflow Execution" Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    # Verify "Workflow Execution" view [Action State]
    values_to_match = ["start.00.landslide.spirent.com", "Completed", ""]
    row = 3
    column_start = 4
    assert actions.workflow_execution_table_validate_action_state(result_id, values_to_match, row, column_start) is True

    values_to_match = ["stop.00.landslide.spirent.com", "Completed", ""]
    row = 8
    assert actions.workflow_execution_table_validate_action_state(result_id, values_to_match, row, column_start) is True


def test_landslide_test_measurements_results():
    """
    In this test will compare the number of rows and some values in "Landslide Test Measurements" Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    range_match = 0
    value_match = 952
    assert base.landslide_test_measurement_count(result_id, value_match) is True

    dict_check = {"tab": "'Test Summary'", "measurement": "'Sessions Pending'"}
    value_match = 200
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    dict_check = {"tab": "'Test Summary'", "measurement": "'Session Errors'"}
    value_match = 0
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    dict_check = {"tab": "'Test Summary'", "measurement": "'Actual Session Connects'"}
    value_match = 100
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    dict_check = {"tab": "'Test Summary'", "measurement": "'Actual Session Disconnects'"}
    value_match = 100
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    dict_check = {"tab": "'S1-AP'", "measurement": "'Init Context Setup Responses'"}
    value_match = 200
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True


def test_landslide_test_report_results():
    """
    In this test will compare the number of rows and some values in "Landslide Test Report" Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    range_match = 0
    value_match = 6150
    assert base.landslide_test_reports_count(result_id, value_match) is True

    dict_check = {"group": "'ESM'", "name": "'PDN Connectivity Success Count'", "elapsed_time": 60}
    value_match = 100
    assert base.landslide_test_report(result_id, dict_check, value_match, range_match) is True

    dict_check = {"group": "'EMM'", "name": "'Attach Completes'", "elapsed_time": 10}
    value_match = 200
    assert base.landslide_test_report(result_id, dict_check, value_match, range_match) is True

    dict_check = {"group": "'Test Summary'", "name": "'Sessions Established'", "elapsed_time": 50}
    value_match = 200
    assert base.landslide_test_report(result_id, dict_check, value_match, range_match) is True

    dict_check = {"group": "'Test Summary'", "name": "'Sessions Established'", "elapsed_time": 60}
    value_match = 0
    assert base.landslide_test_report(result_id, dict_check, value_match, range_match) is True


def test_landslide_test_sessions_chart_results():
    """
    In this test will compare the number of rows and some values in "Landslide Test Sessions Chart"
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    full_name_list = ["landslide_measurement.full_name = 'Test Summary::Sessions Established'",
                      "landslide_measurement.full_name = 'Test Summary::Sessions Pending'",
                      "landslide_measurement.full_name = 'Test Summary::Actual Session Connects'",
                      "landslide_measurement.full_name = 'Test Summary::Actual Session Disconnects'"]
    range_match = 5
    value_match = 65
    for full_name in full_name_list:
        assert base.landslide_test_Session_chart_count(full_name, result_id, value_match, range_match) is True

    full_name = "landslide_measurement.full_name = 'Test Summary::Sessions Established'"
    op = "="
    range_match = 3
    value_match_before_stopping = 49
    value_match_after_stopping = 16
    filter_value_before_stopping = 200
    filter_value_after_stopping = 0
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match_before_stopping, range_match,
                                                         filter_value_before_stopping, op) is True
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match_after_stopping, range_match,
                                                         filter_value_after_stopping, op) is True

    full_name = "landslide_measurement.full_name = 'Test Summary::Sessions Pending'"
    filter_value_before_stopping = 0
    filter_value_after_stopping = 200
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match_before_stopping, range_match,
                                                         filter_value_before_stopping, op) is True
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match_after_stopping, range_match,
                                                         filter_value_after_stopping, op) is True

    full_name = "landslide_measurement.full_name = 'Test Summary::Actual Session Connects'"
    filter_value = 100
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match, range_match, filter_value,
                                                         op) is True

    full_name = "landslide_measurement.full_name = 'Test Summary::Actual Session Disconnects'"
    filter_value_after_stopping = 100
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match_before_stopping, range_match,
                                                         filter_value_before_stopping, op) is True
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match_after_stopping, range_match,
                                                         filter_value_after_stopping, op) is True


def test_landslide_l3_client_server_chart_results():
    """
    In this test will compare the number of rows and some values in "Landslide L3 client server chart"
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    full_name_list = ["landslide_measurement.full_name = 'L3 Client::Total Bytes Received'",
                      "landslide_measurement.full_name = 'L3 Client::Total Bytes Sent'",
                      "landslide_measurement.full_name = 'L3 Server::Total Bytes Received'",
                      "landslide_measurement.full_name = 'L3 Server::Total Bytes Sent'"]

    range_match = 5
    value_match = 65
    for full_name in full_name_list:
        assert base.landslide_L3_Client_Server_chart_count(full_name, result_id, value_match, range_match) is True

    full_name = "landslide_measurement.full_name = 'L3 Client::Total Bytes Received'"
    op = ">="
    range_match = 5
    value_match = 11
    filter_value = 1600000
    assert base.landslide_L3_Client_Server_chart_range_count(full_name, result_id, value_match, range_match,
                                                             filter_value, op) is True

    full_name = "landslide_measurement.full_name = 'L3 Client::Total Bytes Sent'"
    filter_value = 1412000
    assert base.landslide_L3_Client_Server_chart_range_count(full_name, result_id, value_match, range_match,
                                                             filter_value, op) is True

    full_name = "landslide_measurement.full_name = 'L3 Server::Total Bytes Received'"
    filter_value = 1412000
    assert base.landslide_L3_Client_Server_chart_range_count(full_name, result_id, value_match, range_match,
                                                             filter_value, op) is True

    full_name = "landslide_measurement.full_name = 'L3 Server::Total Bytes Sent'"
    filter_value = 1600000
    assert base.landslide_L3_Client_Server_chart_range_count(full_name, result_id, value_match, range_match,
                                                             filter_value, op) is True
