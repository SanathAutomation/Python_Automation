from cstest.testcase import RunTestcase
import pytest
from common import base
from common import impairment_actions_base as actions


def test_ls_iterations(cs_tc: RunTestcase):
    ex = cs_tc.execute("config/universal/cs/tc_input/landslide/landslide_iterations.json")
    print(f"execution: {ex}")
    print(f"cs_url:{cs_tc.client.cs_url} results_id:{ex.results_id}")

    assert cs_tc.client.cs_url is not None
    assert ex.results_id is not None

    pytest.cs_base_url = cs_tc.client.cs_url
    pytest.cs_result_id = ex.results_id


def test_workflow_execution_table_results():
    """
    In this test case we will compare "Workflow Execution" Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    # Verify "Workflow Execution" view [Action State]
    values_to_match = ["continue.00.landslide.spirent.com", "Completed", ""]
    row = 21
    column_start = 4
    assert actions.workflow_execution_table_validate_action_state(result_id, values_to_match, row, column_start) is True

    values_to_match = ["wait.00.landslide.spirent.com", "Completed", ""]
    row = 24
    assert actions.workflow_execution_table_validate_action_state(result_id, values_to_match, row, column_start) is True


def test_landslide_test_measurements_results():
    """
    In this test will compare the number of rows and some values in "Landslide Test Measurements" Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    range_match = 0
    value_match = 952
    assert base.landslide_test_measurement_count(result_id, value_match) is True

    dict_check = {"tab": "'L4 Server'", "measurement": "'Socket TCP Active Count'"}
    value_match = 500
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    dict_check = {"tab": "'Test Summary'", "measurement": "'Actual Session Connects'"}
    value_match = 500
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    dict_check = {"tab": "'S1-AP'", "measurement": "'S1 Release Completes'"}
    value_match = 1000
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    dict_check = {"tab": "'Forward Node'", "measurement": "'Total Sent Packets'"}
    range_match = 5000
    value_match = 9500
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True

    dict_check = {"tab": "'L5-7 Server|Advanced'", "measurement": "'Host Command Messages Received'"}
    range_match = 3000
    value_match = 6000
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) is True


def test_landslide_test_report_results():
    """
    In this test will compare the number of rows and some values in "Landslide Test Report" Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    range_match = 0
    value_match = 6150
    assert base.landslide_test_reports_count(result_id, value_match) is True

    dict_check = {"group": "'SCTP'", "name": "'Socket Connect Count'", "elapsed_time": 15}
    value_match = 1
    assert base.landslide_test_report(result_id, dict_check, value_match, range_match) is True

    dict_check = {"group": "'S1-AP'", "name": "'Init Context Setup Responses'", "elapsed_time": 15}
    value_match = 1000
    assert base.landslide_test_report(result_id, dict_check, value_match, range_match) is True

    dict_check = {"group": "'ESM'", "name": "'Activate Context Accepts'", "elapsed_time": 15}
    value_match = 1000
    assert base.landslide_test_report(result_id, dict_check, value_match, range_match) is True

    dict_check = {"group": "'Test Summary'", "name": "'Sessions Established'", "elapsed_time": 15}
    range_match = 200
    value_match = 1000
    assert base.landslide_test_report(result_id, dict_check, value_match, range_match) is True


def test_landslide_test_sessions_chart_results():
    """
    In this test will compare the number of rows and some values in "Landslide Test Sessions Chart"
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    full_name_list = ["landslide_measurement.full_name = 'Test Summary::Sessions Established'",
                      "landslide_measurement.full_name = 'Test Summary::Sessions Pending'",
                      "landslide_measurement.full_name = 'Test Summary::Actual Session Connects'",
                      "landslide_measurement.full_name = 'Test Summary::Actual Session Disconnects'"]
    range_match = 10
    value_match = 60
    for full_name in full_name_list:
        assert base.landslide_test_Session_chart_count(full_name, result_id, value_match, range_match) is True

    full_name = "landslide_measurement.full_name = 'Test Summary::Sessions Established'"
    op = "="
    value_match_before_stopping = 16
    value_match_after_stopping = 25
    filter_value_before_stopping = 1000
    filter_value_after_stopping = 0
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match_before_stopping, range_match,
                                                         filter_value_before_stopping, op) is True
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match_after_stopping, range_match,
                                                         filter_value_after_stopping, op) is True

    full_name = "landslide_measurement.full_name = 'Test Summary::Sessions Pending'"
    value_match_before_stopping = 20
    value_match_after_stopping = 29
    filter_value_before_stopping = 0
    filter_value_after_stopping = 1000
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match_before_stopping, range_match,
                                                         filter_value_before_stopping, op) is True
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match_after_stopping, range_match,
                                                         filter_value_after_stopping, op) is True

    full_name = "landslide_measurement.full_name = 'Test Summary::Actual Session Connects'"
    value_match = 42
    filter_value = 500
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match, range_match, filter_value,
                                                         op) is True

    full_name = "landslide_measurement.full_name = 'Test Summary::Actual Session Disconnects'"
    value_match_before_stopping = 21
    value_match_after_stopping = 35
    filter_value_before_stopping = 500
    filter_value_after_stopping = 0
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match_before_stopping, range_match,
                                                         filter_value_before_stopping, op) is True
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, value_match_after_stopping, range_match,
                                                         filter_value_after_stopping, op) is True


def test_landslide_l3_client_server_chart_results():
    """
    In this test will compare the number of rows and some values in "Landslide L3 client server chart"
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    full_name_list = ["landslide_measurement.full_name = 'L3 Client::Total Bytes Received'",
                      "landslide_measurement.full_name = 'L3 Client::Total Bytes Sent'",
                      "landslide_measurement.full_name = 'L3 Server::Total Bytes Received'",
                      "landslide_measurement.full_name = 'L3 Server::Total Bytes Sent'"]

    range_match = 10
    value_match = 57
    for full_name in full_name_list:
        assert base.landslide_L3_Client_Server_chart_count(full_name, result_id, value_match, range_match) is True

    full_name = "landslide_measurement.full_name = 'L3 Client::Total Bytes Received'"
    op = ">="
    range_match = 10
    value_match = 30
    filter_value = 480000
    assert base.landslide_L3_Client_Server_chart_range_count(full_name, result_id, value_match, range_match,
                                                             filter_value, op) is True

    full_name = "landslide_measurement.full_name = 'L3 Client::Total Bytes Sent'"
    filter_value = 420000
    assert base.landslide_L3_Client_Server_chart_range_count(full_name, result_id, value_match, range_match,
                                                             filter_value, op) is True

    full_name = "landslide_measurement.full_name = 'L3 Server::Total Bytes Received'"
    filter_value = 420000
    assert base.landslide_L3_Client_Server_chart_range_count(full_name, result_id, value_match, range_match,
                                                             filter_value, op) is True

    full_name = "landslide_measurement.full_name = 'L3 Server::Total Bytes Sent'"
    filter_value = 480000
    assert base.landslide_L3_Client_Server_chart_range_count(full_name, result_id, value_match, range_match,
                                                             filter_value, op) is True
