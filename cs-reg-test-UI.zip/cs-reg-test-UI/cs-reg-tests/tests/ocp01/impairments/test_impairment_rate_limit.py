from cstest.testcase import RunTestcase
import pytest
from common import impairment_actions_base as actions

def test_impairment_rateLimit(cs_tc: RunTestcase):
    ex = cs_tc.execute("config/ocp01/cs/tc_input/impairment_rate_limit.json")
    print(f"execution: {ex}")
    print(f"cs_url:{cs_tc.client.cs_url} results_id:{ex.results_id}")

    assert cs_tc.client.cs_url is not None
    assert ex.results_id is not None

    pytest.cs_base_url = cs_tc.client.cs_url
    pytest.cs_result_id = ex.results_id

def test_rateLimit_Validate_resources():
    """
    In this test case we will compare the number of rows in "Container Memory Resources" Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    # Verify "Container Memory Resources" view [Namespace, Pod-Name, Container-Name, Actual-Memory-Limit, Target-Memory-Limit]
    values_to_match = ['sana-ocp01','ephemeral-nginx-0', 'nginx', 'True']
    assert actions.container_impaired_test_validate_container_name(result_id, values_to_match) is True