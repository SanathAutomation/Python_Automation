from cstest.testcase import RunTestcase
import pytest
from common import impairment_actions_base as actions

def test_impairment_mem(cs_tc: RunTestcase):
    ex = cs_tc.execute("config/ocp01/cs/tc_input/impairment_memory.json")
    print(f"execution: {ex}")
    print(f"cs_url:{cs_tc.client.cs_url} results_id:{ex.results_id}")

    assert cs_tc.client.cs_url is not None
    assert ex.results_id is not None

    pytest.cs_base_url = cs_tc.client.cs_url
    pytest.cs_result_id = ex.results_id

def test_mem_test_container_mem_resources():
    """
    In this test case we will compare the number of rows in "Container Memory Resources" Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    # Verify "Container Memory Resources" view [Namespace, Pod-Name, Container-Name, Actual-Memory-Limit, Target-Memory-Limit]
    values_to_match = ['cs-reg-tests','reg-ss-0', 'hello', 512000000, 51200000]
    assert actions.mem_hog_test_validate_mem_resources(result_id, values_to_match) is True