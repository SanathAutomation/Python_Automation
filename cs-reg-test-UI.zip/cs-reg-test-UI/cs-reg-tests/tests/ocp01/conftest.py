import pytest
import requests
import cstest.client as client
from cstest.library import Library, UpdatePolicy


@pytest.fixture(scope="session")
def cs_params(cs_params: dict) -> dict:
    params = cs_params
    if not params.get("cs_url"):
        params["cs_url"] = "http://10.224.225.71:31387"
    if not params.get("aion_url"):
        params["aion_url"] = "http://10.224.225.71:31461"
    if not params.get("email"):
        params["email"] = "temeva-dev@spirent.com"
    if not params.get("password"):
        params["password"] = "spirent1234"
    if not params.get("project"):
        params["project"] = "cs-regression-ocp01-1"
    if not params.get("kubeconfig"):
        params["kubeconfig"] = "config/ocp01/cs/profiles/environment/ocp01.yaml"
    if not params.get("kubeconfig_env"):
        params["kubeconfig_env"] = "ocp01"
    # print(f"cs_params: {params}")
    return params


@pytest.fixture(autouse=True, scope="session")
def cs_update_library(cs_params: dict, cs_client: client.Client):
    update_libs = cs_params.get("update_lib", "")
    lib_prefix = cs_params.get("lib_prefix", "")
    kubeconfig = cs_params.get("kubeconfig", "")
    kubeconfig_env = cs_params.get("kubeconfig_env", "")
    profile_ls_overrides = cs_params.get("profile_ls_overrides", "")
    if update_libs.lower() != "never":
        lib = Library(cs_client)
        try:
            update_policy = UpdatePolicy(update_libs.lower())
        except Exception:
            raise Exception(f"--update_libs {update_libs} should be one of IfNotPresent|Always|Never")
        lib.update(
            "config/ocp01",
            update_policy=update_policy,
            lib_prefix=lib_prefix,
            kubeconfig=kubeconfig,
            kubeconfig_env=kubeconfig_env,
            profile_ls_overrides=profile_ls_overrides,
        )


@pytest.fixture
def access_token(cs_params: dict):
    aion_url = cs_params.get("aion_url", "")
    auth_url = f'{aion_url}/api/iam/oauth2/token'
    
    # Replace these with your actual authentication parameters
    auth_data = {
        'grant_type': 'password',
        'username': 'temeva-dev@spirent.com',
        'password': 'spirent1234',
        'scope': "urn:c49638a625374b95a254d42dda06ad0b:idp:6351ec2acfa84e0b80e9e96934df494c"
    }

    # Make a request to the authentication endpoint
    response = requests.post(auth_url, data=auth_data)

    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Parse the response JSON to get the access token
        access_token = response.json().get('access_token')
        return access_token
    else:
        # If the request was unsuccessful, raise an exception
        raise ValueError(f"Failed to get access token. Status code: {response.status_code}, Response: {response.text}")


@pytest.fixture
def access_token_basic_user(cs_params: dict):
    aion_url = cs_params.get("aion_url", "")
    auth_url = f'{aion_url}/api/iam/oauth2/token'
    
    # Replace these with your actual authentication parameters
    auth_data = {
        "grant_type": "password",
        "username": "temeva-dev@spirent.com",
        "password": "spirent1234",
        "scope": "urn:c49638a625374b95a254d42dda06ad0b:idp:6351ec2acfa84e0b80e9e96934df494c"
    }

    # Make a request to the authentication endpoint
    response = requests.post(auth_url, data=auth_data)

    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Parse the response JSON to get the access token
        access_token = response.json().get('access_token')
        return access_token
    else:
        # If the request was unsuccessful, raise an exception
        raise ValueError(f"Failed to get access token. Status code: {response.status_code}, Response: {response.text}")


class ValueStorage:
    credential_id = None
    profile_id = None
