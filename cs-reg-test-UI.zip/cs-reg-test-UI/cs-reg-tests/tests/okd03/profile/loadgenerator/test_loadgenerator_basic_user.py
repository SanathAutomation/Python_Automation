from common import base, loadgenerator_mgmt_base
import os


def test_loadgenerator_basic_user(access_token: str, access_token_basic_user: str, cs_params: dict):
    credential_name = "cs-regression-load-generator"
    category_name = "landslide"
    profile_name = "cs-regression-load-generator"
    profile_template_id = "load_generators"

    # Step-1 : Create Credential ID for basic user
    relative_path = "config/okd03/cs/profiles/landslide/landslide-tas2.json"
    file_path = os.path.join(os.getcwd(), relative_path)

    encoded_content = base.encode_file_with_base64(file_path)
    assert isinstance(encoded_content, bytes), "Encoded content should be bytes."

    # Convert the byte string to a string using the decode() method
    decoded_string = encoded_content.decode("utf-8")
    response = loadgenerator_mgmt_base.create_loadgenerator_credentials(access_token_basic_user, credential_name, category_name, decoded_string, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    credential_id = data['id']
    assert data['name'] == credential_name
    assert data['category'] == category_name

    # Step-2: Create the load generator profile for Basic User
    # will check that load generator profile already exits or not
    profile = loadgenerator_mgmt_base.get_profile_by_name(access_token_basic_user, profile_name, cs_params)
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        loadgenerator_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    response = loadgenerator_mgmt_base.create_loadgenerator_profile(access_token_basic_user, credential_name, profile_name, profile_template_id, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 403
    data = response.json()
    assert data['code'] == "PERMISSION_ERROR"

    # Step-3: Create the load generator profile for Admin User
    response = loadgenerator_mgmt_base.create_loadgenerator_profile(access_token, credential_name, profile_name, profile_template_id, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id

    # Step-4: Get the Credential using credential ID for basic user
    response = loadgenerator_mgmt_base.get_credential_by_id(access_token_basic_user, credential_id, cs_params)

    credentials = response.json()
    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert credentials['id'] == credential_id

    # Step-5: Get the Profile load generator using profile ID for basic user 
    response = loadgenerator_mgmt_base.get_profile_by_id(access_token_basic_user, profile_id, cs_params)

    profiles = response.json()
    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles['id'] == profile_id

    # Step-6: Get the tas service status for basic user
    response = loadgenerator_mgmt_base.get_services_tas_status(access_token_basic_user, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert 'licenseId' in response.json()
    assert 'licenseName' in response.json()
    assert 'licenseFile' in response.json()

    # Step-7: Get the tas user information for basic user 
    response = loadgenerator_mgmt_base.get_services_tas_user_info(access_token_basic_user, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert 'url' in response.json()
    assert 'username' in response.json()
    assert response.json()['isActive'] == True
    assert response.json()['alwaysLocalAuthenticate'] == False

    # Step-8: Get the service libraries of tas for basic user
    response = loadgenerator_mgmt_base.get_services_tas_libraries(access_token_basic_user, credential_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 200

    # Step-9: Update load generator profile for basic user
    profile_name = "cs-load-generator-regression"
    response = loadgenerator_mgmt_base.update_loadgenerator_profile(access_token_basic_user, credential_name, profile_id, profile_name, profile_template_id, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 403
    data = response.json()
    assert data['code'] == "PERMISSION_ERROR"


    # Step-10: Delete the credential by giving credential id for basic user
    response = loadgenerator_mgmt_base.delete_credential_by_id(access_token_basic_user, credential_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    response = loadgenerator_mgmt_base.get_credential_by_id(access_token_basic_user, credential_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404

    # Step-11: Delete the profile by giving profile ID for basic user
    response = loadgenerator_mgmt_base.delete_profile_by_id(access_token_basic_user, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 403
    data = response.json()
    assert data['code'] == "PERMISSION_ERROR"


    # Step-12: Delete the profile by giving profile ID for admin user
    response = loadgenerator_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    response = loadgenerator_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404
