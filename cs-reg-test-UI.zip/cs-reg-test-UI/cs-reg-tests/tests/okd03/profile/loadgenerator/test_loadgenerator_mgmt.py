from common import base, loadgenerator_mgmt_base
from tests.okd03.conftest import ValueStorage
import os


def test_create_credential_loadgenerator(access_token: str, cs_params: dict):
    relative_path = "config/okd03/cs/profiles/landslide/landslide-tas2.json"
    file_path = os.path.join(os.getcwd(), relative_path)

    encoded_content = base.encode_file_with_base64(file_path)
    assert isinstance(encoded_content, bytes), "Encoded content should be bytes."

    credential_name = "cs-regression-env"
    category_name = "landslide"
    
    # Convert the byte string to a string using the decode() method
    decoded_string = encoded_content.decode("utf-8")
    response = loadgenerator_mgmt_base.create_loadgenerator_credentials(access_token, credential_name, category_name, decoded_string, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()

    # Credential ID which we are storing here will be deleted in separte test case
    # name - "test_delete_credential_by_id_present"
    ValueStorage.credential_id = data['id']
    assert data['name'] == credential_name
    assert data['category'] == category_name


def test_create_profile_loadgenerator(access_token: str, cs_params: dict):
    """
    Will check first that profile is already present or not
    IF present, then will delete previous profile and create new profile
    """
    credential_name = "cs-regression-env"
    profile_name = "cs-regression-env"
    profile_template_id = "load_generators"
    credential_id = ValueStorage.credential_id

    profile_id = loadgenerator_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    if profile_id:
        loadgenerator_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    response = loadgenerator_mgmt_base.create_loadgenerator_profile(access_token, credential_name, profile_name, profile_template_id, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()

    # Profile ID which we are storing here will be deleted in separte test case
    # name - "test_delete_profile_by_id_present"
    ValueStorage.profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id


def test_get_credential_by_name_present(access_token: str, cs_params: dict):
    credential_name = "cs-regression-env"
    response = loadgenerator_mgmt_base.get_credential_by_name(access_token, credential_name, cs_params)


    # Perform assertions on the response as needed
    assert response["credentials"]['name'] == credential_name
    assert response["status_code"] == 200


def test_get_credential_by_name_not_present(access_token: str, cs_params: dict):
    credential_name = "cs-regression"
    response = loadgenerator_mgmt_base.get_credential_by_name(access_token, credential_name, cs_params)

    # Perform assertions on the response as needed
    assert response == None


def test_get_credential_by_id_present(access_token: str, cs_params: dict):
    credential_id = ValueStorage.credential_id
    response = loadgenerator_mgmt_base.get_credential_by_id(access_token, credential_id, cs_params)

    credentials = response.json()
    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert credentials['id'] == credential_id


def test_get_credential_by_id_not_present(access_token: str, cs_params: dict):
    credential_id = "9e30601b93704fdabedd7380f259623"
    response = loadgenerator_mgmt_base.get_credential_by_id(access_token, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404


def test_get_profile_by_name_present(access_token: str, cs_params: dict):
    profile_name = "cs-regression-env"
    response = loadgenerator_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)

    # Perform assertions on the response as needed
    assert response["profile"]['name'] == profile_name
    assert response["status_code"] == 200


def test_get_profile_by_name_not_present(access_token: str, cs_params: dict):
    profile_name = "cs-regression"
    response = loadgenerator_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)

    # Perform assertions on the response as needed
    assert response == None


def test_get_profile_by_id_present(access_token: str, cs_params: dict):
    profile_id = ValueStorage.profile_id
    response = loadgenerator_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)

    profiles = response.json()

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles['id'] == profile_id
    

def test_get_profile_by_id_not_present(access_token: str, cs_params: dict):
    profile_id = "9e30601b93704fdabedd7380f259623"
    response = loadgenerator_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404


def test_get_service_tas_status(access_token: str, cs_params: dict):
    credential_id = ValueStorage.credential_id
    response = loadgenerator_mgmt_base.get_services_tas_status(access_token, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert 'licenseId' in response.json()
    assert 'licenseName' in response.json()
    assert 'licenseFile' in response.json()


def test_get_service_tas_user_information(access_token: str, cs_params: dict):
    credential_id = ValueStorage.credential_id
    response = loadgenerator_mgmt_base.get_services_tas_user_info(access_token, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert 'url' in response.json()
    assert 'username' in response.json()
    assert response.json()['isActive'] == True
    assert response.json()['alwaysLocalAuthenticate'] == False



def test_get_service_tas_libraries(access_token: str, cs_params: dict):
    credential_id = ValueStorage.credential_id
    response = loadgenerator_mgmt_base.get_services_tas_libraries(access_token, credential_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 200


def test_update_profile_loadgenerator(access_token: str, cs_params: dict):
    credential_name = "cs-env-regression"
    profile_id = ValueStorage.profile_id
    profile_name = "cs-env-regression"
    profile_template_id = "load_generators"
    credential_id = ValueStorage.credential_id
    response = loadgenerator_mgmt_base.update_loadgenerator_profile(access_token, credential_name, profile_id, profile_name, profile_template_id, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    ValueStorage.profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id


def test_delete_credential_by_id_present(access_token: str, cs_params: dict):
    credential_id = ValueStorage.credential_id
    response = loadgenerator_mgmt_base.delete_credential_by_id(access_token, credential_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    response = loadgenerator_mgmt_base.get_credential_by_id(access_token, credential_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404
    

def test_delete_profile_by_id_present(access_token: str, cs_params: dict):
    profile_id = ValueStorage.profile_id
    response = loadgenerator_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    response = loadgenerator_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404
    

def test_delete_profile_by_id_not_present(access_token: str, cs_params: dict):
    profile_id = "218dd560063c4cdab5eec3c615e1ae3b"
    response = loadgenerator_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 404
    data = response.json()
    assert data['code'] == "RESOURCE_NOT_FOUND"
