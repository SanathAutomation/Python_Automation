from common import profile_mgmt_base


def test_scenario_pod_delete(access_token: str, cs_params: dict):
    """
    In this test case we will do all the api's testing for pod delete with landslide
    api's include - post, get, put and delete
    """
    profile_name = "cs-regression-scenario"
    profile_template_id = "scenarios"

    # will check that scneario profile already exits or not
    profile = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    profile_data = {
        "id":"",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "actions":[
                {
                    "config":{
                    "selection":{
                        "namespace":"cs-reg-tests",
                        "selection_method":{
                            "type":"SELECTION_COUNT",
                            "count":1,
                            "order":"RANDOM"
                        },
                        "targets":[
                            {
                                "process_input_method":{
                                "pod_name":"reg-ss-0",
                                "type":"POD_NAME"
                                }
                            }
                        ]
                    },
                    "recovery_interval_sec":30
                    },
                    "name":"Pod Delete",
                    "description":"Pod Delete",
                    "urn":"poddelete.00.impairment.spirent.com",
                    "delay_sec":2
                },
                {
                    "config":{
                    "template_type":"BASIC",
                    "template_id":"landslide_basic_template",
                    "template_file_name":"",
                    "template_override_param":[
                        {
                            "name":"library",
                            "value":"342"
                        },
                        {
                            "name":"ts_id",
                            "value":"2"
                        },
                        {
                            "name":"duration",
                            "value":"600"
                        },
                        {
                            "name":"session",
                            "value":"GK-T01-01_Basic_Services_MME_100_Sessions"
                        }
                    ]
                    },
                    "name":"Start Landslide",
                    "urn":"start.00.landslide.spirent.com",
                    "description":"Start Landslide",
                    "run_when":"AfterPrevious",
                    "delay_sec":2
                },
                {
                    "delay_sec":2,
                    "name":"Continue Landslide",
                    "urn":"continue.00.landslide.spirent.com",
                    "description":"Continue Landslide",
                    "run_when":"AfterPrevious"
                },
                {
                    "delay_sec":0,
                    "name":"Wait Landslide",
                    "urn":"wait.00.landslide.spirent.com",
                    "description":"Wait Landslide",
                    "run_when":"AfterPrevious",
                    "config":{
                        "state":"RUNNING",
                        "iteration":1
                    }
                },
                {
                    "delay_sec":2,
                    "name":"Stop Landslide",
                    "description":"Stop Landslide",
                    "urn":"stop.00.landslide.spirent.com",
                    "run_when":"AfterPrevious"
                }
            ],
            "description":"",
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh scenario profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id

    # check that profile present or not using profile name(present)
    response = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # Perform assertions on the response as needed
    assert response["profile"]['name'] == profile_name
    assert response["status_code"] == 200

    # check that profile present or not using profile name(not present)
    profile_name_not_present = "cs-regression"
    response = profile_mgmt_base.get_profile_by_name(access_token, profile_name_not_present, cs_params)

    # Perform assertions on the response as needed
    assert response == None


    # check that profile present or not using profile ID(present)
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    profiles = response.json()

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles['id'] == profile_id


    # check that profile present or not using profile ID(not present)
    profile_id_not_present = "9e30601b93704fdabedd7380f259623"
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id_not_present, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404

    profile_name = "cs-scenario-regression"
    profile_data_update = {
        "id": profile_id,
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "actions":[
                {
                    "config":{
                    "selection":{
                        "namespace":"cs-reg-tests",
                        "selection_method":{
                            "type":"SELECTION_COUNT",
                            "count":1,
                            "order":"RANDOM"
                        },
                        "targets":[
                            {
                                "process_input_method":{
                                "pod_name":"reg-ss-0",
                                "type":"POD_NAME"
                                }
                            }
                        ]
                    },
                    "recovery_interval_sec":30
                    },
                    "name":"Pod Delete",
                    "description":"Pod Delete",
                    "urn":"poddelete.00.impairment.spirent.com",
                    "delay_sec":2
                },
                {
                    "config":{
                    "template_type":"BASIC",
                    "template_id":"landslide_basic_template",
                    "template_file_name":"",
                    "template_override_param":[
                        {
                            "name":"library",
                            "value":"342"
                        },
                        {
                            "name":"ts_id",
                            "value":"2"
                        },
                        {
                            "name":"duration",
                            "value":"600"
                        },
                        {
                            "name":"session",
                            "value":"GK-T01-01_Basic_Services_MME_100_Sessions"
                        }
                    ]
                    },
                    "name":"Start Landslide",
                    "urn":"start.00.landslide.spirent.com",
                    "description":"Start Landslide",
                    "run_when":"AfterPrevious",
                    "delay_sec":2
                },
                {
                    "delay_sec":2,
                    "name":"Continue Landslide",
                    "urn":"continue.00.landslide.spirent.com",
                    "description":"Continue Landslide",
                    "run_when":"AfterPrevious"
                },
                {
                    "delay_sec":0,
                    "name":"Wait Landslide",
                    "urn":"wait.00.landslide.spirent.com",
                    "description":"Wait Landslide",
                    "run_when":"AfterPrevious",
                    "config":{
                        "state":"RUNNING",
                        "iteration":1
                    }
                },
                {
                    "delay_sec":2,
                    "name":"Stop Landslide",
                    "description":"Stop Landslide",
                    "urn":"stop.00.landslide.spirent.com",
                    "run_when":"AfterPrevious"
                }
            ],
            "description":"",
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    # update the profile
    response = profile_mgmt_base.update_profile(access_token, profile_id, profile_data_update, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id    

    # Delete the profile(present)
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    # after deleting check profile present or not 
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404

    # delete the profile(not present)
    profile_id_not_present = "218dd560063c4cdab5eec3c615e1ae3b"
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id_not_present, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 404
    data = response.json()
    assert data['code'] == "RESOURCE_NOT_FOUND"


def test_scenario_pod_delete_recreate(access_token: str, cs_params: dict):
    """
    In this test case we will do all the api's testing for pod delete with landslide
    api's include - post, get, put and delete
    will try to again create profile and check the result
    """
    profile_name = "cs-regression-scenario"
    profile_template_id = "scenarios"

    # will check that scneario profile already exits or not
    profile = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    profile_data = {
        "id":"",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "actions":[
                {
                    "config":{
                    "selection":{
                        "namespace":"cs-reg-tests",
                        "selection_method":{
                            "type":"SELECTION_COUNT",
                            "count":1,
                            "order":"RANDOM"
                        },
                        "targets":[
                            {
                                "process_input_method":{
                                "pod_name":"reg-ss-0",
                                "type":"POD_NAME"
                                }
                            }
                        ]
                    },
                    "recovery_interval_sec":30
                    },
                    "name":"Pod Delete",
                    "description":"Pod Delete",
                    "urn":"poddelete.00.impairment.spirent.com",
                    "delay_sec":2
                },
                {
                    "config":{
                    "template_type":"BASIC",
                    "template_id":"landslide_basic_template",
                    "template_file_name":"",
                    "template_override_param":[
                        {
                            "name":"library",
                            "value":"342"
                        },
                        {
                            "name":"ts_id",
                            "value":"2"
                        },
                        {
                            "name":"duration",
                            "value":"600"
                        },
                        {
                            "name":"session",
                            "value":"GK-T01-01_Basic_Services_MME_100_Sessions"
                        }
                    ]
                    },
                    "name":"Start Landslide",
                    "urn":"start.00.landslide.spirent.com",
                    "description":"Start Landslide",
                    "run_when":"AfterPrevious",
                    "delay_sec":2
                },
                {
                    "delay_sec":2,
                    "name":"Continue Landslide",
                    "urn":"continue.00.landslide.spirent.com",
                    "description":"Continue Landslide",
                    "run_when":"AfterPrevious"
                },
                {
                    "delay_sec":0,
                    "name":"Wait Landslide",
                    "urn":"wait.00.landslide.spirent.com",
                    "description":"Wait Landslide",
                    "run_when":"AfterPrevious",
                    "config":{
                        "state":"RUNNING",
                        "iteration":1
                    }
                },
                {
                    "delay_sec":2,
                    "name":"Stop Landslide",
                    "description":"Stop Landslide",
                    "urn":"stop.00.landslide.spirent.com",
                    "run_when":"AfterPrevious"
                }
            ],
            "description":"",
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh scenario profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id

    # check that profile present or not using profile name(present)
    response = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # Perform assertions on the response as needed
    assert response["profile"]['name'] == profile_name
    assert response["status_code"] == 200


    # check that profile present or not using profile ID(present)
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    profiles = response.json()

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles['id'] == profile_id

    # again create the same scenario profile with same name
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 409
    data = response.json()
    assert data['code'] == "RESOURCE_CONFLICT"

    # Delete the profile(present)
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    # after deleting check profile present or not 
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404


def test_scenario_pod_delete_negative_case_1(access_token: str, cs_params: dict):
    """
    In this test case we will try to create scenario with invalid input for negative test case
    """
    profile_name = "cs-regression-scenario"
    profile_template_id = "scenarios"
    
    profile_data = {
        "id":"",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "actions":[
                {
                    "config":{
                    "selection":{
                        "namespace":"cs-reg-tests",
                        "selection_method":{
                            "type":"SELECTION_PERCENTAGE",
                            "percentage":101,
                            "order":"RANDOM"
                        },
                        "targets":[
                            {
                                "process_input_method":{
                                "pod_name":"reg-ss-0",
                                "type":"POD_NAME"
                                }
                            }
                        ]
                    },
                    "recovery_interval_sec":30
                    },
                    "name":"Pod Delete",
                    "description":"Pod Delete",
                    "urn":"poddelete.00.impairment.spirent.com",
                    "delay_sec":2
                }
            ],
            "description":"",
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh scenario profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 400
    data = response.json()
    assert data['code'] == "VALIDATION_ERROR"


def test_scenario_pod_delete_negative_case_2(access_token: str, cs_params: dict):
    """
    In this test case we will try to create scenario with invalid input for negative test case
    """
    profile_name = "abc"
    profile_template_id = "scenarios"
    
    profile_data = {
        "id":"",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "actions":[
                {
                    "config":{
                    "selection":{
                        "namespace":"cs-reg-tests",
                        "selection_method":{
                            "type":"SELECTION_PERCENTAGE",
                            "percentage":10,
                            "order":"RANDOM"
                        },
                        "targets":[
                            {
                                "process_input_method":{
                                "pod_name":"reg-ss-0",
                                "type":"POD_NAME"
                                }
                            }
                        ]
                    },
                    "recovery_interval_sec":30
                    },
                    "name":"Pod Delete",
                    "description":"Pod Delete",
                    "urn":"poddelete.00.impairment.spirent.com",
                    "delay_sec":2
                }
            ],
            "description":"",
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh scenario profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 400
    data = response.json()
    assert data['code'] == "VALIDATION_ERROR"


def test_scenario_pod_delete_negative_case_3(access_token: str, cs_params: dict):
    """
    In this test case we will try to create scenario with invalid input for negative test case
    """
    profile_name = "cs-regression-scenario"
    profile_template_id = "scenarios"
    
    profile_data = {
        "id":"",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "actions":[
                {
                    "config":{
                    "selection":{
                        "namespace":"cs-reg-tests",
                        "selection_method":{
                            "type":"SELECTION_PERCENTAGE",
                            "percentage":101,
                            "order":"RANDOM"
                        },
                        "targets":[
                            {
                                "process_input_method":{
                                "pod_name":"reg-ss-0",
                                "type":"POD_NAME"
                                }
                            }
                        ]
                    },
                    "recovery_interval_sec": "sec"
                    },
                    "name":"Pod Delete",
                    "description":"Pod Delete",
                    "urn":"poddelete.00.impairment.spirent.com",
                    "delay_sec":2
                }
            ],
            "description":"",
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh scenario profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 400
    data = response.json()
    assert data['code'] == "VALIDATION_ERROR"