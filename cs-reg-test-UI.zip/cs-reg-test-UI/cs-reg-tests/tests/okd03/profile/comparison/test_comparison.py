from common import profile_mgmt_base


def test_comparison_profile(access_token: str, cs_params: dict):
    """
    In this test case we will do all the api's testing for comparison
    api's include - post, get, put and delete
    """
    profile_name = "cs-regression-comparison"
    profile_template_id = "comparison"

    # will check that profile already exits or not
    profile = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    profile_data = {
        "id":"",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                        {
                            "name":"cs-regression-cadvisor",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"10",
                                "alert":-5,
                                "enable": True,
                                "improve":50,
                                "threshold_type":"ACTUAL",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        },
                        {
                            "name":"cs-regression-cadvisor1",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"5",
                                "alert":0,
                                "enable": True,
                                "improve":101,
                                "threshold_type":"ACTUAL",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        }
                    ]
                },
                "container_kill":{
                    "kpis":{
                        "name":"cs-regression-containerkill",
                        "config":{
                            "improvement_direction":"NEGATIVE",
                            "units":"sec",
                            "alert":50,
                            "enable": True,
                            "improve":-50,
                            "threshold_type":"PERCENT"
                        }
                    }
                },
                "kube_state":{
                    "kpis":[
                        {
                            "name":"cs-regression-kubestate",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"15",
                                "alert":0,
                                "enable": True,
                                "improve":10,
                                "threshold_type":"PERCENT",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"kube_daemonset_created"
                        }
                    ]
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id

    # check that profile present or not using profile name(present)
    response = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # Perform assertions on the response as needed
    assert response["profile"]['name'] == profile_name
    assert response["status_code"] == 200

    # check that profile present or not using profile name(not present)
    profile_name_not_present = "cs-regression"
    response = profile_mgmt_base.get_profile_by_name(access_token, profile_name_not_present, cs_params)

    # Perform assertions on the response as needed
    assert response == None


    # check that profile present or not using profile ID(present)
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    profiles = response.json()

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles['id'] == profile_id


    # check that profile present or not using profile ID(not present)
    profile_id_not_present = "9e30601b93704fdabedd7380f259623"
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id_not_present, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404

    profile_name = "cs-comparison-regression"
    profile_data_update = {
        "id": profile_id,
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                        {
                            "name":"cs-regression-cadvisor",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"10",
                                "alert":-5,
                                "enable": True,
                                "improve":50,
                                "threshold_type":"ACTUAL",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        },
                        {
                            "name":"cs-regression-cadvisor1",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"5",
                                "alert":0,
                                "enable": True,
                                "improve":101,
                                "threshold_type":"ACTUAL",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        }
                    ]
                },
                "container_kill":{
                    "kpis":{
                        "name":"cs-regression-containerkill",
                        "config":{
                            "improvement_direction":"NEGATIVE",
                            "units":"sec",
                            "alert":50,
                            "enable": True,
                            "improve":-50,
                            "threshold_type":"PERCENT"
                        }
                    }
                },
                "kube_state":{
                    "kpis":[
                        {
                            "name":"cs-regression-kubestate",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"15",
                                "alert":0,
                                "enable": True,
                                "improve":10,
                                "threshold_type":"PERCENT",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"kube_daemonset_created"
                        }
                    ]
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }

    # update the profile
    response = profile_mgmt_base.update_profile(access_token, profile_id, profile_data_update, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id    

    # Delete the profile(present)
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    # after deleting check profile present or not 
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404

    # delete the profile(not present)
    profile_id_not_present = "218dd560063c4cdab5eec3c615e1ae3b"
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id_not_present, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 404
    data = response.json()
    assert data['code'] == "RESOURCE_NOT_FOUND"


def test_comparison_profile_recreate(access_token: str, cs_params: dict):
    """
    In this test case we will try to recreate comparison with same name
    """
    profile_name = "cs-regression-comparison"
    profile_template_id = "comparison"

    # will check that profile already exits or not
    profile = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    profile_data = {
        "id":"",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                        {
                            "name":"cs-regression-cadvisor",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"10",
                                "alert":-5,
                                "enable": True,
                                "improve":50,
                                "threshold_type":"ACTUAL",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        },
                        {
                            "name":"cs-regression-cadvisor1",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"5",
                                "alert":0,
                                "enable": True,
                                "improve":101,
                                "threshold_type":"ACTUAL",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        }
                    ]
                },
                "container_kill":{
                    "kpis":{
                        "name":"cs-regression-containerkill",
                        "config":{
                            "improvement_direction":"NEGATIVE",
                            "units":"sec",
                            "alert":50,
                            "enable": True,
                            "improve":-50,
                            "threshold_type":"PERCENT"
                        }
                    }
                },
                "kube_state":{
                    "kpis":[
                        {
                            "name":"cs-regression-kubestate",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"15",
                                "alert":0,
                                "enable": True,
                                "improve":10,
                                "threshold_type":"PERCENT",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"kube_daemonset_created"
                        }
                    ]
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id

    # check that profile present or not using profile ID(present)
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    profiles = response.json()

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles['id'] == profile_id

    # again create the same profile with same name
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 409
    data = response.json()
    assert data['code'] == "RESOURCE_CONFLICT"

    # Delete the profile(present)
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    # after deleting check profile present or not 
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404
