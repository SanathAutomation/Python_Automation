from common import profile_mgmt_base


def test_comparison_with_landslide_test_report(access_token: str, cs_params: dict):
    """
    In this test case we will try to create comparison with landslide kpi
    """
    profile_name = "cs-regression-comparison"
    profile_template_id = "comparison"

    # will check that profile already exits or not
    profile = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    profile_data = {
        "id": "",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                        {
                            "name":"cs-regression-cadvisor",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"10",
                                "alert":0,
                                "enable": True,
                                "improve":0,
                                "threshold_type":"ACTUAL",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        }
                    ]
                },
                "landslide":{
                    "kpis":[
                        {
                            "config":{
                                "aggregation_method":"LAST",
                                "alert":-5,
                                "enable": True,
                                "improve":10,
                                "improvement_direction":"POSITIVE",
                                "threshold_type":"ACTUAL",
                                "units":"10"
                            },
                            "measurement_name":"Command DSCP Best Effort",
                            "name":"rsinghlandslide",
                            "tab_name":"L5-7 Server|DSCP"
                        },
                        {
                            "config":{
                                "aggregation_method":"LAST",
                                "alert":-50,
                                "enable": True,
                                "improve":25,
                                "improvement_direction":"POSITIVE",
                                "threshold_type":"PERCENT",
                                "units":"10"
                            },
                            "measurement_name":"Host Attempted Mainflow Transaction Count",
                            "name":"rsinghlandslide1",
                            "tab_name":"L5-7 Server|Advanced"
                        }
                    ],
                    "metrics_type":"Test Report",
                    "comparison_mode":"FAVORITE"
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id

    # Delete the profile(present)
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    # after deleting check profile present or not 
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404


def test_comparison_with_landslide_test_measurement(access_token: str, cs_params: dict):
    """
    In this test case we will try to create comparison with landslide kpi
    """
    profile_name = "cs-regression-comparison"
    profile_template_id = "comparison"

    # will check that profile already exits or not
    profile = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    profile_data = {
        "id": "",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                        {
                            "name":"cs-regression-cadvisor",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"10",
                                "alert":0,
                                "enable": True,
                                "improve":0,
                                "threshold_type":"ACTUAL",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        }
                    ]
                },
                "landslide":{
                    "kpis":[
                        {
                            "name":"cs-regression-landslide",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"10",
                                "alert":-5,
                                "enable": True,
                                "improve":10,
                                "threshold_type":"ACTUAL",
                                "aggregation_method":"LAST"
                            },
                            "measurement_name":"Command DSCP Best Effort",
                            "tab_name":"L5-7 Server|DSCP"
                        },
                        {
                            "name":"cs-regression-landslide1",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"10",
                                "alert":-50,
                                "enable": True,
                                "improve":25,
                                "threshold_type":"PERCENT",
                                "aggregation_method":"LAST"
                            },
                            "measurement_name":"Host Attempted Mainflow Transaction Count",
                            "tab_name":"L5-7 Server|Advanced"
                        }
                    ],
                    "metrics_type":"Test Measurements",
                    "comparison_mode":"SELECTED"
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id

    # Delete the profile(present)
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    # after deleting check profile present or not 
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404