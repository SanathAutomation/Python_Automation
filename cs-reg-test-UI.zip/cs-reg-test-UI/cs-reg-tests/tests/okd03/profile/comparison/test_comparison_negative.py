from common import profile_mgmt_base


def test_comparison_invalid_profile_name(access_token: str, cs_params: dict):
    """
    In this test case we will try to create comparison with invalid input for negative test case
    """
    profile_name = "abc"
    profile_template_id = "comparison"

    
    profile_data = {
        "id": "",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                        {
                            "name":"cs-regression-cadvisor",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"10",
                                "alert":-15,
                                "enable": True,
                                "improve":20,
                                "threshold_type":"ACTUAL",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        }
                    ]
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 400
    data = response.json()
    assert data['code'] == "VALIDATION_ERROR"


def test_comparison_invalid_template_id(access_token: str, cs_params: dict):
    """
    In this test case we will try to create comparison with invalid input for negative test case
    """
    profile_name = "cs-regressopn-comparison"
    profile_template_id = "compare"

    
    profile_data = {
        "id": "",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                        {
                            "name":"cs-regression-cadvisor",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"10",
                                "alert":-15,
                                "enable": True,
                                "improve":20,
                                "threshold_type":"ACTUAL",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        }
                    ]
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 400
    data = response.json()
    assert data['code'] == "VALIDATION_ERROR"


def test_comparison_invalid_string(access_token: str, cs_params: dict):
    """
    In this test case we will try to create comparison with invalid input for negative test case
    """
    profile_name = "cs-regressopn-comparison"
    profile_template_id = "comparison"

    
    profile_data = {
        "id": "",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                        {
                            "name":"cs-regression-cadvisor",
                            "config":{
                                "improvement_direction":"POSITIVE",
                                "units":"10",
                                "alert":-15,
                                "enable": "true",
                                "improve":20,
                                "threshold_type":"ACTUAL",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        }
                    ]
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 400
    data = response.json()
    assert data['code'] == "VALIDATION_ERROR"
