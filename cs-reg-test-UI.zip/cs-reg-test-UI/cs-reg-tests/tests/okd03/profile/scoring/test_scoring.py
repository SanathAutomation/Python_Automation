from common import profile_mgmt_base


def test_scoring_profile(access_token: str, cs_params: dict):
    """
    In this test case we will do all the api's testing for scoring
    api's include - post, get, put and delete
    """
    profile_name = "cs-regression-scoring"
    profile_template_id = "scoring"

    # will check that profile already exits or not
    profile = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    profile_data = {
        "id": "",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                        {
                            "name":"cs-regression-cadvisor",
                            "config":{
                                "enable": True,
                                "improvement_direction":"POSITIVE",
                                "threshold_value":100,
                                "weight":25,
                                "units":"10",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        },
                        {
                            "name":"cs-regression-cadvisor1",
                            "config":{
                                "enable": True,
                                "improvement_direction":"POSITIVE",
                                "threshold_value":100,
                                "weight":25,
                                "units":"5",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        }
                    ]
                },
                "container_kill":{
                    "kpis":{
                        "name":"cs-regression-container-kill",
                        "config":{
                            "enable": True,
                            "improvement_direction":"NEGATIVE",
                            "threshold_value":100,
                            "weight":25,
                            "units":"sec"
                        }
                    }
                },
                "kube_state":{
                    "kpis":[
                        {
                            "name":"cs-regression-kube-state",
                            "config":{
                                "enable": True,
                                "improvement_direction":"POSITIVE",
                                "threshold_value":100,
                                "weight":25,
                                "units":"15",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"kube_daemonset_created"
                        }
                    ]
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id

    # check that profile present or not using profile name(present)
    response = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # Perform assertions on the response as needed
    assert response["profile"]['name'] == profile_name
    assert response["status_code"] == 200

    # check that profile present or not using profile name(not present)
    profile_name_not_present = "cs-regression"
    response = profile_mgmt_base.get_profile_by_name(access_token, profile_name_not_present, cs_params)

    # Perform assertions on the response as needed
    assert response == None


    # check that profile present or not using profile ID(present)
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    profiles = response.json()

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles['id'] == profile_id


    # check that profile present or not using profile ID(not present)
    profile_id_not_present = "9e30601b93704fdabedd7380f259623"
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id_not_present, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404

    profile_name = "cs-kpi-regression"
    profile_data_update = {
        "id": profile_id,
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                        {
                            "name":"cs-regression-cadvisor",
                            "config":{
                                "enable": True,
                                "improvement_direction":"POSITIVE",
                                "threshold_value":100,
                                "weight":25,
                                "units":"10",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        },
                        {
                            "name":"cs-regression-cadvisor1",
                            "config":{
                                "enable": True,
                                "improvement_direction":"POSITIVE",
                                "threshold_value":100,
                                "weight":25,
                                "units":"5",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        }
                    ]
                },
                "container_kill":{
                    "kpis":{
                        "name":"cs-regression-container-kill",
                        "config":{
                            "enable": True,
                            "improvement_direction":"NEGATIVE",
                            "threshold_value":100,
                            "weight":25,
                            "units":"sec"
                        }
                    }
                },
                "kube_state":{
                    "kpis":[
                        {
                            "name":"cs-regression-kube-state",
                            "config":{
                                "enable": True,
                                "improvement_direction":"POSITIVE",
                                "threshold_value":100,
                                "weight":25,
                                "units":"15",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"kube_daemonset_created"
                        }
                    ]
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    # update the profile
    response = profile_mgmt_base.update_profile(access_token, profile_id, profile_data_update, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id    

    # Delete the profile(present)
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    # after deleting check profile present or not 
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404

    # delete the profile(not present)
    profile_id_not_present = "218dd560063c4cdab5eec3c615e1ae3b"
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id_not_present, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 404
    data = response.json()
    assert data['code'] == "RESOURCE_NOT_FOUND"


def test_scoring_profile_recreate(access_token: str, cs_params: dict):
    """
    In this test case we will try to recreate scoring with same name
    """
    profile_name = "cs-regression-scoring"
    profile_template_id = "scoring"

    # will check that profile already exits or not
    profile = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    profile_data = {
        "id": "",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                        {
                            "name":"cs-regression-cadvisor",
                            "config":{
                                "enable": True,
                                "improvement_direction":"POSITIVE",
                                "threshold_value":100,
                                "weight":25,
                                "units":"10",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        },
                        {
                            "name":"cs-regression-cadvisor1",
                            "config":{
                                "enable": True,
                                "improvement_direction":"POSITIVE",
                                "threshold_value":100,
                                "weight":25,
                                "units":"5",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"container_cpu_cfs_periods_total"
                        }
                    ]
                },
                "container_kill":{
                    "kpis":{
                        "name":"cs-regression-container-kill",
                        "config":{
                            "enable": True,
                            "improvement_direction":"NEGATIVE",
                            "threshold_value":100,
                            "weight":25,
                            "units":"sec"
                        }
                    }
                },
                "kube_state":{
                    "kpis":[
                        {
                            "name":"cs-regression-kube-state",
                            "config":{
                                "enable": True,
                                "improvement_direction":"POSITIVE",
                                "threshold_value":100,
                                "weight":25,
                                "units":"15",
                                "aggregation_method":"AVG"
                            },
                            "metric_name":"kube_daemonset_created"
                        }
                    ]
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id

    # check that profile present or not using profile ID(present)
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    profiles = response.json()

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles['id'] == profile_id

    # again create the same profile with same name
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 409
    data = response.json()
    assert data['code'] == "RESOURCE_CONFLICT"

    # Delete the profile(present)
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    # after deleting check profile present or not 
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404
