from common import profile_mgmt_base


def test_scoring_invalid_profile_name(access_token: str, cs_params: dict):
    """
    In this test case we will try to create scoring with invalid input for negative test case
    """
    profile_name = "abc"
    profile_template_id = "scoring"

    
    profile_data = {
        "id":"",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                    {
                        "name":"cs-regression-cadvisor",
                        "config":{
                            "enable":True,
                            "improvement_direction":"POSITIVE",
                            "threshold_value":100,
                            "weight":100,
                            "units":"10",
                            "aggregation_method":"AVG"
                        },
                        "metric_name":"container_cpu_cfs_periods_total"
                    }
                    ]
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 400
    data = response.json()
    assert data['code'] == "VALIDATION_ERROR"


def test_scoring_invalid_template_id(access_token: str, cs_params: dict):
    """
    In this test case we will try to create scoring with invalid input for negative test case
    """
    profile_name = "cs-regressopn-scoring"
    profile_template_id = "score"

    
    profile_data = {
        "id":"",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                    {
                        "name":"cs-regression-cadvisor",
                        "config":{
                            "enable":True,
                            "improvement_direction":"POSITIVE",
                            "threshold_value":100,
                            "weight":100,
                            "units":"10",
                            "aggregation_method":"AVG"
                        },
                        "metric_name":"container_cpu_cfs_periods_total"
                    }
                    ]
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 400
    data = response.json()
    assert data['code'] == "VALIDATION_ERROR"


def test_scoring_invalid_string(access_token: str, cs_params: dict):
    """
    In this test case we will try to create scoring with invalid input for negative test case
    """
    profile_name = "cs-regressopn-scoring"
    profile_template_id = "scoring"

    
    profile_data = {
        "id":"",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "description":"",
            "kpi_classes":{
                "cadvisor":{
                    "kpis":[
                    {
                        "name":"cs-regression-cadvisor",
                        "config":{
                            "enable":"true",
                            "improvement_direction":"POSITIVE",
                            "threshold_value":100,
                            "weight":100,
                            "units":"10",
                            "aggregation_method":"AVG"
                        },
                        "metric_name":"container_cpu_cfs_periods_total"
                    }
                    ]
                }
            },
            "name": profile_name
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 400
    data = response.json()
    assert data['code'] == "VALIDATION_ERROR"
