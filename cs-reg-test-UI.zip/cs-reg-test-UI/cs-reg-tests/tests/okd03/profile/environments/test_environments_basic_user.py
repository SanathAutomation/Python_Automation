from common import base, environment_mgmt_base
import os



def test_environment_basic_user(access_token: str, access_token_basic_user: str, cs_params: dict):
    credential_name = "cs-regression-env"
    category_name = "environment"
    content_filename = "config.yaml"
    profile_name = "cs-regression-env"
    profile_template_id = "environments"

    # Step-1 : Create Credential ID for basic user
    folder_path = os.path.join(os.path.dirname(__file__), 'data')  # Assuming 'data' is a folder in your project
    file_path = os.path.join(folder_path, 'config.yaml')

    assert os.path.exists(file_path), f"{file_path} does not exist."
    encoded_content = base.encode_file_with_base64(file_path)
    assert isinstance(encoded_content, bytes), "Encoded content should be bytes."


    # Convert the byte string to a string using the decode() method
    decoded_string = encoded_content.decode("utf-8")
    response = environment_mgmt_base.create_environment_credentials(access_token_basic_user, credential_name, category_name, decoded_string, content_filename, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    credential_id = data['id']
    assert data['name'] == credential_name
    assert data['category'] == category_name
    assert data['content_filename'] == content_filename

    # Step-2: Create the Environment profile for Basic User
    # will check that Environment already exits or not
    profile = environment_mgmt_base.get_profile_by_name(access_token_basic_user, profile_name, cs_params)
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        environment_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    response = environment_mgmt_base.create_environment_profile(access_token_basic_user, credential_name, profile_name, profile_template_id, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 403
    data = response.json()
    assert data['code'] == "PERMISSION_ERROR"

    # Step-3: Create the Environment profile for Admin User
    response = environment_mgmt_base.create_environment_profile(access_token, credential_name, profile_name, profile_template_id, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id

    # Step-4: Get the Credential using credential ID for basic user
    response = environment_mgmt_base.get_credential_by_id(access_token_basic_user, credential_id, cs_params)

    credentials = response.json()
    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert credentials['id'] == credential_id

    # Step-5: Get the Profile environment using profile ID for basic user 
    response = environment_mgmt_base.get_profile_by_id(access_token_basic_user, profile_id, cs_params)

    profiles = response.json()
    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles['id'] == profile_id

    # Step-6: Get the environment for basic user
    response = environment_mgmt_base.get_environment(access_token_basic_user, profile_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    environment = response.json()
    assert environment['name'] == profile_name

    # Step-7: Get the environment(not present) for basic user
    env_name = "cs-regression"
    response = environment_mgmt_base.get_environment(access_token_basic_user, env_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404

    # Step-8: Get the environment pods for basic user
    response = environment_mgmt_base.get_environment_pods(access_token, profile_name, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert len(response.json()[0]) > 0
    assert response.json()[0]['environment'] == profile_name

    # Step-9: Get the environment workloads for basic user
    response = environment_mgmt_base.get_environment_workloads(access_token, profile_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert len(response.json()[0]) > 0
    assert response.json()[0]['environment'] == profile_name

    # Step-10: Get the environment namespace for basic user
    response = environment_mgmt_base.get_environment_namespaces(access_token, profile_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert len(response.json()[0]) > 0
    assert response.json()[0]['environment'] == profile_name


    # Step-11: Update credential environment by basic user    
    credential_name = "cs-env-regression"
    response = environment_mgmt_base.update_environment_credentials(access_token_basic_user, credential_id, credential_name, category_name, decoded_string, content_filename, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    credential_id = data['id']
    assert data['name'] == credential_name
    assert data['category'] == category_name
    assert data['content_filename'] == content_filename

    # Step-12: Update environment profile for basic user
    profile_name = "cs-env-regression"
    response = environment_mgmt_base.update_environment_profile(access_token_basic_user, credential_name, profile_id, profile_name, profile_template_id, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 403
    data = response.json()
    assert data['code'] == "PERMISSION_ERROR"


    # Step-13: Delete the credential by giving credential id for basic user
    response = environment_mgmt_base.delete_credential_by_id(access_token_basic_user, credential_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    response = environment_mgmt_base.get_credential_by_id(access_token_basic_user, credential_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404

    # Step-14: Delete the profile by giving profile ID for basic user
    response = environment_mgmt_base.delete_profile_by_id(access_token_basic_user, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 403
    data = response.json()
    assert data['code'] == "PERMISSION_ERROR"


    # Step-15: Delete the profile by giving profile ID for admin user
    response = environment_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    response = environment_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404
