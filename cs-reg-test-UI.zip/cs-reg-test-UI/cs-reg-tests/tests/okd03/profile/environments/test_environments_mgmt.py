from common import base, environment_mgmt_base
from tests.okd03.conftest import ValueStorage
import os


def test_create_credential_environment(access_token: str, cs_params: dict):
    folder_path = os.path.join(os.path.dirname(__file__), "data")  # Assuming 'data' is a folder in your project
    file_path = os.path.join(folder_path, "config.yaml")

    assert os.path.exists(file_path), f"{file_path} does not exist."
    encoded_content = base.encode_file_with_base64(file_path)
    assert isinstance(encoded_content, bytes), "Encoded content should be bytes."

    credential_name = "cs-regression-env"
    category_name = "environment"
    content_filename = "config.yaml"

    # Convert the byte string to a string using the decode() method
    decoded_string = encoded_content.decode("utf-8")
    response = environment_mgmt_base.create_environment_credentials(
        access_token, credential_name, category_name, decoded_string, content_filename, cs_params
    )

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    ValueStorage.credential_id = data["id"]
    assert data["name"] == credential_name
    assert data["category"] == category_name
    assert data["content_filename"] == content_filename


def test_create_exiting_credential_environment(access_token: str, cs_params: dict):
    """
    @fix is required to stop creating credentials with same payload
    """
    pass


def test_create_profile_environment(access_token: str, cs_params: dict):
    credential_name = "cs-regression-env"
    profile_name = "cs-regression-env"
    profile_template_id = "environments"
    credential_id = ValueStorage.credential_id

    # Check if profile exists from previous test run and remove it
    response = environment_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    if response and response["status_code"] == 200:
        environment_mgmt_base.delete_profile_by_id(access_token, response["profile"]["id"], cs_params)

    response = environment_mgmt_base.create_environment_profile(
        access_token, credential_name, profile_name, profile_template_id, credential_id, cs_params
    )

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    ValueStorage.profile_id = data["id"]
    assert data["name"] == profile_name
    assert data["profile_template_id"] == profile_template_id


def test_get_credential_by_name_present(access_token: str, cs_params: dict):
    credential_name = "cs-regression-env"
    response = environment_mgmt_base.get_credential_by_name(access_token, credential_name, cs_params)

    # Perform assertions on the response as needed
    assert response["credentials"]["name"] == credential_name
    assert response["status_code"] == 200


def test_get_credential_by_name_not_present(access_token: str, cs_params: dict):
    credential_name = "cs-regression"
    response = environment_mgmt_base.get_credential_by_name(access_token, credential_name, cs_params)

    # Perform assertions on the response as needed
    assert response is None


def test_get_credential_by_id_present(access_token: str, cs_params: dict):
    credential_id = ValueStorage.credential_id
    response = environment_mgmt_base.get_credential_by_id(access_token, credential_id, cs_params)

    credentials = response.json()
    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert credentials["id"] == credential_id


def test_get_credential_by_id_not_present(access_token: str, cs_params: dict):
    credential_id = "9e30601b93704fdabedd7380f259623"
    response = environment_mgmt_base.get_credential_by_id(access_token, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404


def test_get_profile_by_name_present(access_token: str, cs_params: dict):
    profile_name = "cs-regression-env"
    response = environment_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)

    # Perform assertions on the response as needed
    assert response["profile"]["name"] == profile_name
    assert response["status_code"] == 200


def test_get_profile_by_name_not_present(access_token: str, cs_params: dict):
    profile_name = "cs-regression"
    response = environment_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)

    # Perform assertions on the response as needed
    assert response is None


def test_get_profile_by_id_present(access_token: str, cs_params: dict):
    profile_id = ValueStorage.profile_id
    response = environment_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)

    profiles = response.json()

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles["id"] == profile_id


def test_get_profile_by_id_not_present(access_token: str, cs_params: dict):
    profile_id = "9e30601b93704fdabedd7380f259623"
    response = environment_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404


def test_get_environment_present(access_token: str, cs_params: dict):
    env_name = "cs-regression-env"
    response = environment_mgmt_base.get_environment(access_token, env_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    environment = response.json()
    assert environment["name"] == env_name


def test_get_environment_not_present(access_token: str, cs_params: dict):
    env_name = "cs-regression"
    response = environment_mgmt_base.get_environment(access_token, env_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404


def test_get_environment_pods(access_token: str, cs_params: dict):
    """
    @todo - need fix even if environment not present return 200 status code
    """
    env_name = "cs-regression-env"
    response = environment_mgmt_base.get_environment_pods(access_token, env_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert len(response.json()[0]) > 0
    assert response.json()[0]["environment"] == env_name


def test_get_environment_workloads(access_token: str, cs_params: dict):
    env_name = "cs-regression-env"
    response = environment_mgmt_base.get_environment_workloads(access_token, env_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert len(response.json()[0]) > 0
    assert response.json()[0]["environment"] == env_name


def test_get_environment_namespaces(access_token: str, cs_params: dict):
    env_name = "cs-regression-env"
    response = environment_mgmt_base.get_environment_namespaces(access_token, env_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert len(response.json()[0]) > 0
    assert response.json()[0]["environment"] == env_name


def test_update_credential_environment(access_token: str, cs_params: dict):
    folder_path = os.path.join(os.path.dirname(__file__), "data")  # Assuming 'data' is a folder in your project
    file_path = os.path.join(folder_path, "config.yaml")
    assert os.path.exists(file_path), f"{file_path} does not exist."    
    encoded_content = base.encode_file_with_base64(file_path)
    
    credential_name = "cs-env-regression"
    category_name = "environment"
    content_filename = "config.yaml"
    credential_id = ValueStorage.credential_id

    # Convert the byte string to a string using the decode() method
    decoded_string = encoded_content.decode("utf-8")
    response = environment_mgmt_base.update_environment_credentials(
        access_token, credential_id, credential_name, category_name, decoded_string, content_filename, cs_params
    )

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    ValueStorage.credential_id = data["id"]
    assert data["name"] == credential_name
    assert data["category"] == category_name
    assert data["content_filename"] == content_filename


def test_update_profile_environment(access_token: str, cs_params: dict):
    credential_name = "cs-env-regression"
    profile_id = ValueStorage.profile_id
    profile_name = "cs-env-regression"
    profile_template_id = "environments"
    credential_id = ValueStorage.credential_id
    response = environment_mgmt_base.update_environment_profile(
        access_token, credential_name, profile_id, profile_name, profile_template_id, credential_id, cs_params
    )

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    ValueStorage.profile_id = data["id"]
    assert data["name"] == profile_name
    assert data["profile_template_id"] == profile_template_id


def test_delete_credential_by_id_present(access_token: str, cs_params: dict):
    credential_id = ValueStorage.credential_id
    response = environment_mgmt_base.delete_credential_by_id(access_token, credential_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 204

    response = environment_mgmt_base.get_credential_by_id(access_token, credential_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404


def test_delete_credential_by_id_not_present(access_token: str, cs_params: dict):
    """
    @todo - need a fix, getting same reponse even if id present or not
    """
    pass


def test_delete_profile_by_id_present(access_token: str, cs_params: dict):
    profile_id = ValueStorage.profile_id
    response = environment_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 204

    response = environment_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404


def test_delete_profile_by_id_not_present(access_token: str, cs_params: dict):
    profile_id = "218dd560063c4cdab5eec3c615e1ae3b"
    response = environment_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404
    data = response.json()
    assert data["code"] == "RESOURCE_NOT_FOUND"
