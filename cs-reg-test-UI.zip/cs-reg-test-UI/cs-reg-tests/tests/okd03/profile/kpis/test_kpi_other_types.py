from common import profile_mgmt_base


def test_kpi_type_kube_state(access_token: str, cs_params: dict):
    """
    In this test case we will check post api's call for Kpi of type kube state
    """
    profile_name = "cs-regression-kpi"
    profile_template_id = "kpis"

    # will check that scneario profile already exits or not
    profile = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    profile_data = {
        "id":"",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "name": profile_name,
            "kpi_type":"KUBE_STATE",
            "kpi_class":{
                "metric_name":"kube_daemonset_created",
                "config":{
                    "aggregation_method":"AVG",
                    "improvement_direction":"POSITIVE",
                    "units":"10"
                }
            }
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id


    # check that profile present or not using profile ID(present)
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    profiles = response.json()

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles['id'] == profile_id

    # Delete the profile(present)
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    # after deleting check profile present or not 
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404


def test_kpi_type_landslide(access_token: str, cs_params: dict):
    """
    In this test case we will check post api's call for Kpi of type landslide
    """
    profile_name = "cs-regression-kpi"
    profile_template_id = "kpis"

    # will check that scneario profile already exits or not
    profile = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    profile_data = {
        "id":"",
        "name":profile_name,
        "version":"1.0.0",
        "input":{
            "name":profile_name,
            "kpi_type":"LANDSLIDE",
            "kpi_class":{
                "tab_name":"L5-7 Server|DSCP",
                "measurement_name":"Command DSCP Best Effort",
                "config":{
                    "aggregation_method":"LAST",
                    "improvement_direction":"POSITIVE",
                    "units":"10"
                }
            }
        },
        "profile_template_id":profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id


    # check that profile present or not using profile ID(present)
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    profiles = response.json()

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles['id'] == profile_id

    # Delete the profile(present)
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    # after deleting check profile present or not 
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404


def test_kpi_type_node_exporter(access_token: str, cs_params: dict):
    """
    In this test case we will check post api's call for Kpi of type node exporter
    """
    profile_name = "cs-regression-kpi"
    profile_template_id = "kpis"

    # will check that scneario profile already exits or not
    profile = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    profile_data = {
        "id":"",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "name": profile_name,
            "kpi_type":"NODE_EXPORTER",
            "kpi_class":{
                "metric_name":"node_boot_time_seconds",
                "config":{
                    "aggregation_method":"AVG",
                    "improvement_direction":"POSITIVE",
                    "units":"10"
                }
            }
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id


    # check that profile present or not using profile ID(present)
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    profiles = response.json()

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles['id'] == profile_id

    # Delete the profile(present)
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    # after deleting check profile present or not 
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404


def test_kpi_type_pod_delete(access_token: str, cs_params: dict):
    """
    In this test case we will check post api's call for Kpi of type pod delete
    """
    profile_name = "cs-regression-kpi"
    profile_template_id = "kpis"

    # will check that scneario profile already exits or not
    profile = profile_mgmt_base.get_profile_by_name(access_token, profile_name, cs_params)
    
    # if exists, then first delete that profile
    if profile:
        profile_id = profile['profile']['id']
        profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    profile_data = {
        "id":"",
        "name": profile_name,
        "version":"1.0.0",
        "input":{
            "name": profile_name,
            "kpi_type":"POD_DELETE",
            "kpi_class":{
                "config":{
                    "improvement_direction":"NEGATIVE",
                    "units":"sec"
                }
            }
        },
        "profile_template_id": profile_template_id
    }
    
    # create a fresh profile using post request
    response = profile_mgmt_base.create_profile(access_token, profile_data, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    profile_id = data['id']
    assert data['name'] == profile_name
    assert data ['profile_template_id'] == profile_template_id


    # check that profile present or not using profile ID(present)
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    profiles = response.json()

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert profiles['id'] == profile_id

    # Delete the profile(present)
    response = profile_mgmt_base.delete_profile_by_id(access_token, profile_id, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204

    # after deleting check profile present or not 
    response = profile_mgmt_base.get_profile_by_id(access_token, profile_id, cs_params)
    # Perform assertions on the response as needed
    assert response.status_code == 404
