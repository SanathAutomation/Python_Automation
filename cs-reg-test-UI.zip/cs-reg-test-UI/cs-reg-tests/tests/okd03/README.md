# okd03 Tests
CloudSure and Landslide tests verify CloudSure compatibility with different release versions of CloudSure and Landslide.
Tests assume AION and CloudSure are installed on okd03 and Landslide tests run in loopback.

List of tests:
* test_impairment_cpu - verify CPU impairment works
* test_landslide_iterations - verify landslide iterations work
* test_landslide_pod_delete - verify landslide with POD delete works
* test_landslide_traffic_01 - verify landslide traffic works
* test_landslide_tls_traffic_01 - verify landslide TLS traffic works
* test_landslide_wait - verify landslide wait works

# Usage

## Install AION & CloudSure
CloudSure and AION installation configurations are located in [config/okd03/helm](config/okd03/helm).
The configuration can optionally be upgraded in the cs-regression-okd03 jenkins job.

CloudSure clean install requires creating a public CloudSure URL on node port 31003.
If that is not possible, you will have to update the tests/okd03/conftest.py defaults.
Other than that the tests should just run after clean CloudSure install.

AION clean install requires creating a public AION URL on node port 31461.
If that is not possible, you will have to update the tests/okd03/conftest.py defaults.
To create the fixed node port number the AION helm chart should be installed with a ClusterIP and the node port created after.

AION clean install also requires rehosting the CloudSure licenses:
* 5G CNF Resiliency
* CloudSure Analytics


## Install Python Packages
See cs-reg-tests [README.md](../../README.md)

## Install Kubernetes Testing Resources
Known resources are required on the cluster under test for test cases to work.
For example, a pod delete test requires a named pod in a namespace. 
Run the script below to add them (uses kubectl):
```bash
kubectl create namespace cs-reg-tests
./config/universal/k8s/apply_resources.sh -n cs-reg-tests
```

## Run Tests
Tests use the pytest framework.  The 'run-reg-tests.sh' wrapper script conveniently sets some default pytest arguments.

### Run All Universal Tests
Run from the top level directory:
```bash
./run-reg-tests.sh -s  \
  tests/okd03
```