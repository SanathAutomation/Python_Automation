from common import import_export_base
from common import project_mgmt_base as pmb
from common import testcase_mgmt_base as tmb

def test_import_export(access_token: str, cs_params: dict):
    project_name = "cs-regression-project-import-export"
    testcase_name = "cs-regression-testcase-import-export"
    
    # Import the TestCase
    response = import_export_base.import_testcase(access_token, project_name, testcase_name, cs_params)

    # Perform assertions on the response of Importing Testcase
    assert response.status_code == 200
    data = response.json()
    assert data['name'] == testcase_name
    assert data['project_name'] == project_name
    assert data['testcase_template_id'] == "spirent_resiliency.RESILIENCY_WORKFLOW"
    assert data['testcase_template_name'] == "RESILIENCY_WORKFLOW"
    testcase_id = data['id']

    # Export the TestCase
    response = import_export_base.export_testcase(access_token, testcase_id, cs_params)

    # Perform assertions on the response of Exporting Testcase
    assert response.status_code == 200
    response_content = response.content.decode("utf-8")
    assert 'landslide-template.json' in response_content
    assert 'cs-regression-testcase-import-export.yaml' in response_content
    assert 'metadata.json' in response_content

    # Delete the testcase
    response = tmb.delete_testcase_without_id(access_token, project_name, testcase_name, cs_params)
    assert response.status_code == 204

    # delete the project
    response = pmb.delete_project(access_token, project_name, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204
