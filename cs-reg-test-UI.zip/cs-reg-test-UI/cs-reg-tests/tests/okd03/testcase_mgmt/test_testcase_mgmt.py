from common import testcase_mgmt_base


def test_get_project_details_present(access_token: str, cs_params: dict):
    proj_name = "cs-regression-proj"
    response = testcase_mgmt_base.get_project_details(access_token, proj_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    assert data['name'] == proj_name
    assert 'id' in response.json()
    assert 'testcases' in response.json()


def test_get_project_details_not_present(access_token: str, cs_params: dict):
    proj_name = "cs-regression-proj-not-present"
    response = testcase_mgmt_base.get_project_details(access_token, proj_name, cs_params)

    # Perform assertions on the response as needed
    assert response == False


def test_get_project_details_with_id_present(access_token: str, cs_params: dict):
    proj_id = "7e280e3d9b55466d9b104c2fdc25e67f"
    response = testcase_mgmt_base.get_project_details_with_id(access_token, proj_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    assert data['name'] == "cs-regression-proj"
    assert 'id' in response.json()
    assert 'testcases' in response.json()


def test_get_project_details_with_id_not_present(access_token: str, cs_params: dict):
    proj_id = "7e280e3d9b55466d9b104c2fdc25e67"
    response = testcase_mgmt_base.get_project_details_with_id(access_token, proj_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404
    data = response.json()
    assert data['code'] == "RESOURCE_NOT_FOUND"


def test_create_blank_testcase(access_token: str, cs_params: dict):
    proj_name = "cs-regression-proj"
    testcase_name = "cs-regression_test1"
    response = testcase_mgmt_base.create_blank_testcase(access_token, proj_name, testcase_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    data = response.json()
    assert data['name'] == testcase_name
    assert data['project_name'] == proj_name
    assert data ['testcase_template_id'] == 'spirent_resiliency.RESILIENCY_WORKFLOW'


def test_create_existing_blank_testcase(access_token: str, cs_params: dict):
    proj_name = "cs-regression-proj"
    testcase_name = "cs-regression_test1"
    response = testcase_mgmt_base.create_blank_testcase(access_token, proj_name, testcase_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 409
    data = response.json()
    assert data['code'] == "RESOURCE_CONFLICT"


def test_get_testcase_details(access_token: str, cs_params: dict):
    proj_name = "cs-regression-proj"
    testcase_name = "cs-regression_test1"
    response = testcase_mgmt_base.get_testcase_details(access_token, proj_name, testcase_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    assert data['name'] == testcase_name
    assert data['project_name'] == proj_name
    assert data ['testcase_template_id'] == 'spirent_resiliency.RESILIENCY_WORKFLOW'


def test_get_testcase_details_with_id_not_present(access_token: str, cs_params: dict):
    testcase_id = "6b3e0898c78942f695ea40226b4026f"
    response = testcase_mgmt_base.get_testcase_details_with_id(access_token, testcase_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404
    data = response.json()
    assert data['code'] == "RESOURCE_NOT_FOUND"


def test_update_testcase_environment(access_token: str, cs_params: dict):
    proj_name = "cs-regression-proj"
    testcase_name = "cs-regression_test1"
    response = testcase_mgmt_base.update_testcase(access_token, proj_name, testcase_name, cs_params)

    assert response.status_code == 200
    data = response.json()
    assert data['name'] == testcase_name
    assert data['project_name'] == proj_name
    assert data ['testcase_template_id'] == 'spirent_resiliency.RESILIENCY_WORKFLOW'


def test_update_testcase_scenario(access_token: str, cs_params: dict):
    proj_name = "cs-regression-proj"
    testcase_name = "cs-regression_test1"
    response = testcase_mgmt_base.update_testcase_scenario(access_token, proj_name, testcase_name, cs_params)

    assert response.status_code == 200
    data = response.json()
    assert data['name'] == testcase_name
    assert data['project_name'] == proj_name
    assert data ['testcase_template_id'] == 'spirent_resiliency.RESILIENCY_WORKFLOW'


def test_delete_testcase(access_token: str, cs_params: dict):
    proj_name = "cs-regression-proj"
    testcase_name = "cs-regression_test1"
    response = testcase_mgmt_base.delete_testcase_without_id(access_token, proj_name, testcase_name, cs_params)

    assert response.status_code == 204


def test_delete_testcase_with_id_not_present(access_token: str, cs_params: dict):
    testcase_id = "6b3e0898c78942f695ea40226b4026f"
    response = testcase_mgmt_base.delete_testcase_with_id(access_token, testcase_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404
    data = response.json()
    assert data['code'] == "RESOURCE_NOT_FOUND"
