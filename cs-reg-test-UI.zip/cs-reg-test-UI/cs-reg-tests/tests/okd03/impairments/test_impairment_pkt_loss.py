from cstest.testcase import RunTestcase
# import pytest
# from common import impairment_actions_base as actions


def test_impairment_pkt_loss(cs_tc: RunTestcase):
    # OKD03 doesn't support pkt_loss, fix this error : http://10.143.138.24:31003/results/3d841b9b57944cbb97989b6a4fcc75b1

    assert cs_tc.client.cs_url is not None
    print("Commented for now, Will be enabled back soon")
    # ex = cs_tc.execute("config/okd03/cs/tc_input/impairment_pkt_loss.json")
    # print(f"execution: {ex}")
    # print(f"cs_url:{cs_tc.client.cs_url} results_id:{ex.results_id}")

    # assert ex.results_id is not None

    # pytest.cs_base_url = cs_tc.client.cs_url
    # pytest.cs_result_id = ex.results_id
