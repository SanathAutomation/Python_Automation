from cstest.testcase import RunTestcase
import pytest
from common import base


def test_ls_traffic(cs_tc: RunTestcase):
    ex = cs_tc.execute("config/okd03/cs/tc_input/landslide_tls_test1.json")
    print(f"execution: {ex}")
    print(f"cs_url:{cs_tc.client.cs_url} results_id:{ex.results_id}")

    assert cs_tc.client.cs_url is not None
    assert ex.results_id is not None

    pytest.cs_base_url = cs_tc.client.cs_url
    pytest.cs_result_id = ex.results_id


def test_landslide_test_measurement_count():
    """
    In this test case we will compare the number of rows in "Landslide Test Measurements" Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    assert base.landslide_test_measurement_count(result_id, 900) is True


def test_landslide_test_reports_count():
    """
    In this test case we will compare the number of rows in "Landslide Test Reports" Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    assert base.landslide_test_reports_count(result_id, 5000) is True


def test_landslide_test_measurement():
    """
    In this test case we will compare some of the values from particular row and column in "Landslide Test Measurements" table from ResultSet
    from Resultset we get the query output in form of rows and each row will be list of list.
    So, in the list we can check is some value is present for some column then what is other value which is asssociated with it.
    Example :
    if
    {column1 = 'tab', value1 = "EMM"}, {column2 = 'measurement', value2 = 'Auth Requests'}, then  {column3 = 'value', value3 = 400}
    should match, similarly:
    {column1 = 'tab', value1 = "EMM"}, {column2 = 'measurement', value2 = 'Security Mode Completes}, then  {column3 = 'value', value3 = 400}
    {column1 = 'tab', value1 = "ESM"}, {column2 = 'measurement', value2 = 'Activate Context Requests'}, then  {column3 = 'value', value3 = 400}
    {column1 = 'tab', value1 = "L3 Client"}, {column2 = 'measurement', value2 = 'Total Packets Sent'}, then  {column3 = 'value', value3 = 12800}
    {column1 = 'tab', value1 = "L3 Client"}, {column2 = 'measurement', value2 = 'Total Packets Received'}, then  {column3 = 'value', value3 = 8500}
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    dict_check = {"tab": "'EMM'", "measurement": "'Auth Requests'"}
    value_match = 300
    range_match = 200
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) == True


def test_landslide_test_report():
    """
    In this test case we will compare some of the values from particular row and column in "Landslide Test Measurements" table from ResultSet
    from Resultset we get the query output in form of rows and each row will be list of list.
    So, in the list we can check is some value is present for some column then what is other value which is asssociated with it.
    Example :
    if
    {column1 = 'group', value1 = "ESM"}, {column2 = 'name', value2 = 'PDN Connectivity Success Count'}, {column3 = 'elapsed_time', value3 = "30"}
    then  {column3 = 'value', value3 = 100}
    should match, similarly:
    {column1 = 'tab', value1 = "EMM"}, {column2 = 'measurement', value2 = 'Security Mode Completes},
     then  {column3 = 'value', value3 = 400}
    {column1 = 'tab', value1 = "ESM"}, {column2 = 'measurement', value2 = 'Activate Context Requests'},
    then  {column3 = 'value', value3 = 400}
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    dict_check = {"group": "'ESM'", "name": "'PDN Connectivity Success Count'", "elapsed_time": 30}
    value_match = 300
    range_match = 200
    assert base.landslide_test_report(result_id, dict_check, value_match, range_match) == True


def test_landslide_Sessions_Established():
    """
    In this test case we will compare the number of rows in "Landslide Test Session chart" Section from Results
    we will filter for 'Test Summary::Sessions Established'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'Test Summary::Sessions Established'"
    assert base.check_landslide_result(full_name, result_id, 200, 200, op="max") is True
    assert base.check_landslide_result(full_name, result_id, 0, 0, op="min") is True


def test_landslide_L3_Client_Total_Bytes_Received():
    """
    In this test case we will compare the number of rows in "Landslide L3 client server chart" Section from Results
    we will filter for 'L3 Client::Total Bytes Received'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'L3 Client::Total Bytes Received'"
    assert base.check_landslide_result(full_name, result_id, 1000000, 4000000, op="max") is True


def test_landslide_report_table():
    """
    In this test case we will compare the columns in "Landslide Report" table
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    column_list = base.landslide_tables_details(result_id, "landslide_report")
    assert column_list == ["timestamp", "is_summary", "value", "interval", "iteration", "elapsed_time"]
    assert len(column_list) == 6


def test_landslide_test_measurement_column_check():
    """
    In this test case we will check that column contain null values or not for "Landslide Test Measurements" Table from Results
    column names are :
    test_measurements.tab as tab",
    test_measurements.measurement as measurement",
    test_measurements.value as value",
    test_measurements.is_favorite as is_favorite"
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    assert base.landslide_test_measurement_column_null_check(result_id, ["tab", "measurement", "value", "is_favorite"]) == True
