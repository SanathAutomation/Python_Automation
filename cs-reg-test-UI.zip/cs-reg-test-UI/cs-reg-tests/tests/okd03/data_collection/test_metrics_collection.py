from cstest.testcase import RunTestcase
import pytest
from common import metrics_collection_base as mcb


def test_ls_pod_delete_conatiner_kill(cs_tc: RunTestcase):
    ex = cs_tc.execute("config/okd03/cs/tc_input/metrics_landslide_pod_delete.json")
    print(f"execution: {ex}")
    print(f"cs_url:{cs_tc.client.cs_url} results_id:{ex.results_id}")

    assert cs_tc.client.cs_url is not None
    assert ex.results_id is not None

    pytest.cs_base_url = cs_tc.client.cs_url
    pytest.cs_result_id = ex.results_id


def test_kube_state_metrics_daemonset_metrics():
    """
    In this test case we will compare total number of rows in "Kube state metrics daemonset" table from results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = []
    assert mcb.kube_state_metrics_daemonset_metrics(result_id, 15, filter) is True

    filter = ["metrics_kube_state_daemonset_id.daemonset = 'cs-chaos-agent'"]
    assert mcb.kube_state_metrics_daemonset_metrics(result_id, 7, filter) is True

    filter = ["metrics_kube_state_daemonset_id.daemonset = 'cs-prometheus-node-exporter'"]
    assert mcb.kube_state_metrics_daemonset_metrics(result_id, 7, filter) is True


def test_kube_state_metrics_deployment_metrics():
    """
    In this test case we will compare total number of rows in "Kube state metrics deployment" table from results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = []
    assert mcb.kube_state_metrics_deployment_metrics(result_id, 150, filter) is True

    filter = ["metrics_kube_state_deployment_id.deployment = 'cs-ana-comparison'"]
    assert mcb.kube_state_metrics_deployment_metrics(result_id, 10, filter) is True

    filter = ["metrics_kube_state_deployment_id.deployment = 'cs-credential-manager'"]
    assert mcb.kube_state_metrics_deployment_metrics(result_id, 10, filter) is True

    filter = ["metrics_kube_state_deployment_id.deployment = 'cs-workflow-landslide-driver'"]
    assert mcb.kube_state_metrics_deployment_metrics(result_id, 10, filter) is True


def test_kube_state_metrics_pod_metrics():
    """
    In this test case we will compare total number of rows in "Kube state metrics pod" table from results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = [
                "view.metrics_kube_state_pod_id_pod >> 'cs-ana-comparison' OR view.metrics_kube_state_pod_id_pod >> 'cs-app'"
            ]
    assert mcb.kube_state_metrics_pod_metrics(result_id, 300, filter) is True

    filter = [
                "view.metrics_kube_state_pod_id_pod >> 'cs-chaos' OR view.metrics_kube_state_pod_id_pod >> 'cs-credential-manager'"
            ]
    assert mcb.kube_state_metrics_pod_metrics(result_id, 900, filter) is True

    filter = [
                "view.metrics_kube_state_pod_id_pod >> 'cs-data-ingestion-controller' OR view.metrics_kube_state_pod_id_pod >> 'cs-data-metrics-converter'"
            ]
    assert mcb.kube_state_metrics_pod_metrics(result_id, 300, filter) is True

    filter = [
                "view.metrics_kube_state_pod_id_pod >> 'cs-dev-telemeter' OR view.metrics_kube_state_pod_id_pod >> 'cs-init'"
            ]
    assert mcb.kube_state_metrics_pod_metrics(result_id, 200, filter) is True


def test_kube_state_metrics_replicaset_metrics():
    """
    In this test case we will compare total number of rows in "Kube state metrics replicaset" table from results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = [
                "view.metrics_kube_state_replicaset_id_replicaset >> 'cs-ana-comparison' OR view.metrics_kube_state_replicaset_id_replicaset >> 'cs-chaos' OR view.metrics_kube_state_replicaset_id_replicaset >> 'cs-credential-manager'"
            ]
    assert mcb.kube_state_metrics_replicaset_metrics(result_id, 55, filter) is True

    filter = [
                "view.metrics_kube_state_replicaset_id_replicaset >> 'cs-data-ingestion-controller' OR view.metrics_kube_state_replicaset_id_replicaset >> 'cs-log-opensearch' OR view.metrics_kube_state_replicaset_id_replicaset >> 'cs-logs-collector'"
            ]
    assert mcb.kube_state_metrics_replicaset_metrics(result_id, 55, filter) is True

    filter = [
                "view.metrics_kube_state_replicaset_id_replicaset >> 'cs-workflow'"
            ]
    assert mcb.kube_state_metrics_replicaset_metrics(result_id, 55, filter) is True

    
def test_kube_state_metrics_statefulset_metrics():
    """
    In this test case we will compare total number of rows in "Kube state metrics statefullset" table from results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = []
    assert mcb.kube_state_metrics_statefulset_metrics(result_id, 130, filter) is True

    filter = [
                "view.metrics_kube_state_statefulset_id_statefulset = 'cs-app' OR view.metrics_kube_state_statefulset_id_statefulset = 'cs-test-exec'"
            ]
    assert mcb.kube_state_metrics_statefulset_metrics(result_id, 35, filter) is True

    filter = [
                "view.metrics_kube_state_statefulset_id_statefulset = 'cs-results' OR view.metrics_kube_state_statefulset_id_statefulset = 'cs-results-db'"
            ]
    assert mcb.kube_state_metrics_statefulset_metrics(result_id, 35, filter) is True


def test_kube_state_metrics_service_metrics():
    """
    In this test case we will compare total number of rows in "Kube state metrics service metrics" table from results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = []
    assert mcb.kube_state_metrics_service_metrics(result_id, 800, filter) is True

    filter = [
                "view.metrics_kube_state_service_id_service = 'cs-logs-collector' OR view.metrics_kube_state_service_id_service = 'cs-nginx'"
            ]
    assert mcb.kube_state_metrics_service_metrics(result_id, 55, filter) is True

    filter = [
                "view.metrics_kube_state_service_id_service = 'opensearch-cluster-master' OR view.metrics_kube_state_service_id_service = 'cs-results-db'"
            ]
    assert mcb.kube_state_metrics_service_metrics(result_id, 55, filter) is True


def test_node_exporter_metrics():
    """
    In this test case we will compare total number of rows in "node exporter metrics" table from results
    """
    # pytest.cs_result_id = "uyalu3yrrnbfxg54"
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = []
    assert mcb.node_exporter_metrics(result_id, 10, filter) is True


def test_node_exporter_collector_metrics():
    """
    In this test case we will compare total number of rows in "node exporter collector metrics" table from results
    """
    # pytest.cs_result_id = "uyalu3yrrnbfxg54"
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = []
    assert mcb.node_exporter_collector_metrics(result_id, 600, filter) is True


def test_node_exporter_cpu_metrics():
    """
    In this test case we will compare total number of rows in "node exporter cpu metrics" table from results
    """
    # pytest.cs_result_id = "uyalu3yrrnbfxg54"
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = []
    assert mcb.node_exporter_cpu_metrics(result_id, 800, filter) is True


def test_node_exporter_memory_metrics():
    """
    In this test case we will compare total number of rows in "node exporter memory metrics" table from results
    """
    # pytest.cs_result_id = "uyalu3yrrnbfxg54"
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = []
    assert mcb.node_exporter_memory_metrics(result_id, 10, filter) is True


def test_node_exporter_device_metrics():
    """
    In this test case we will compare total number of rows in "node exporter device metrics" table from results
    """
    # pytest.cs_result_id = "uyalu3yrrnbfxg54"
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = []
    assert mcb.node_exporter_device_metrics(result_id, 40, filter) is True


def test_node_exporter_filesystem_metrics():
    """
    In this test case we will compare total number of rows in "node exporter filesystem metrics" table from results
    """
    # pytest.cs_result_id = "uyalu3yrrnbfxg54"
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = []
    assert mcb.node_exporter_filesystem_metrics(result_id, 2000, filter) is True


def test_node_exporter_network_metrics():
    """
    In this test case we will compare total number of rows in "node exporter network metrics" table from results
    """
    # pytest.cs_result_id = "uyalu3yrrnbfxg54"
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = []
    assert mcb.node_exporter_network_metrics(result_id, 700, filter) is True


def test_node_exporter_uname_metrics():
    """
    In this test case we will compare total number of rows in "node exporter uname metrics" table from results
    """
    # pytest.cs_result_id = "uyalu3yrrnbfxg54"
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    filter = []
    assert mcb.node_exporter_uname_metrics(result_id, 10, filter) is True
