from common import project_mgmt_base


def test_access_token(access_token: str, cs_params: dict):
    """
    This method is use to check the access of cloudsure application
    """
    response = project_mgmt_base.check_access_token(access_token, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    assert 'token' in response.json()


def test_project_id_not_present(access_token: str, cs_params: dict):
    proj_id = "7e280e3d9b55466d9b104c2fdc25e67"
    response = project_mgmt_base.get_project_with_id(access_token, proj_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 404
    project_name = response.json()['code']
    assert project_name == 'RESOURCE_NOT_FOUND'


def test_project_id_present(access_token: str, cs_params: dict):
    proj_id = "7e280e3d9b55466d9b104c2fdc25e67f"
    response = project_mgmt_base.get_project_with_id(access_token, proj_id, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    project_name = response.json()['name']
    assert project_name == 'cs-regression-proj'


def test_project_list(access_token: str, cs_params: dict):
    proj_name = "cs-regression-proj"
    response = project_mgmt_base.get_project_with_name(access_token, proj_name, cs_params)

    # Perform assertions on the response as needed
    assert response == True


def test_create_projects(access_token: str, cs_params: dict):
    proj_name = "cs-regression-proj-test"
    response = project_mgmt_base.create_project(access_token, proj_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 201
    assert 'created_at' in response.json()


def test_duplicate_projects(access_token: str, cs_params: dict):
    proj_name = "cs-regression-proj-test"
    response = project_mgmt_base.create_project(access_token, proj_name, cs_params)

    # Perform assertions on the response as needed
    assert response.status_code == 409
    data = response.json()
    assert data['code'] == "RESOURCE_CONFLICT"


def test_modify_project_name_present(access_token: str, cs_params: dict):
    proj_old_name = "cs-regression-proj-test"
    proj_new_name = "cs-regression-test-proj"
    response = project_mgmt_base.modify_project_name(access_token, proj_old_name, cs_params, proj_new_name)

    # Perform assertions on the response as needed
    assert response.status_code == 200
    data = response.json()
    assert data['name'] == "cs-regression-test-proj"


def test_delete_project_present(access_token: str, cs_params: dict):
    proj_name = "cs-regression-test-proj"
    response = project_mgmt_base.delete_project(access_token, proj_name, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 204


def test_delete_projects_not_present(access_token: str, cs_params: dict):
    proj_name = "cs-regression-test"
    response = project_mgmt_base.delete_project(access_token, proj_name, cs_params)
    
    # Perform assertions on the response as needed
    assert response.status_code == 404
    data = response.json()
    assert data['code'] == "RESOURCE_NOT_FOUND"
