from cstest.testcase import RunTestcase
import pytest
from common import base


def test_ls_traffic(cs_tc: RunTestcase):
    ex = cs_tc.execute("config/okd03/cs/tc_input/landslide_compatibility_test.json")
    print(f"execution: {ex}")
    print(f"cs_url:{cs_tc.client.cs_url} results_id:{ex.results_id}")

    assert cs_tc.client.cs_url is not None
    assert ex.results_id is not None

    pytest.cs_base_url = cs_tc.client.cs_url
    pytest.cs_result_id = ex.results_id


def test_landslide_test_measurement_count():
    """
    In this test case we will compare the number of rows in "Landslide Test Measurements" Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    assert base.landslide_test_measurement_count(result_id, 900) is True


def test_landslide_test_reports_count():
    """
    In this test case we will compare the number of rows in "Landslide Test Reports" Section from Results
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    assert base.landslide_test_reports_count(result_id, 5000) is True


def test_landslide_test_measurement():
    """
    In this test case we will compare some of the values from particular row and column in "Landslide Test Measurements" table from ResultSet
    from Resultset we get the query output in form of rows and each row will be list of list. 
    So, in the list we can check is some value is present for some column then what is other value which is asssociated with it.
    Example :
    if
    {column1 = 'tab', value1 = "EMM"}, {column2 = 'measurement', value2 = 'Auth Requests'}, then  {column3 = 'value', value3 = 400} 
    should match, similarly:
    {column1 = 'tab', value1 = "EMM"}, {column2 = 'measurement', value2 = 'Security Mode Completes}, then  {column3 = 'value', value3 = 400}
    {column1 = 'tab', value1 = "ESM"}, {column2 = 'measurement', value2 = 'Activate Context Requests'}, then  {column3 = 'value', value3 = 400}
    {column1 = 'tab', value1 = "L3 Client"}, {column2 = 'measurement', value2 = 'Total Packets Sent'}, then  {column3 = 'value', value3 = 12800}
    {column1 = 'tab', value1 = "L3 Client"}, {column2 = 'measurement', value2 = 'Total Packets Received'}, then  {column3 = 'value', value3 = 8500}
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    
    dict_check = {"tab": "'EMM'", "measurement":"'Auth Requests'"}
    value_match = 400
    range_match = 10
    assert base.landslide_test_measurement(result_id, dict_check, value_match, range_match) == True
 

def test_landslide_test_report():
    """
    In this test case we will compare some of the values from particular row and column in "Landslide Test Measurements" table from ResultSet
    from Resultset we get the query output in form of rows and each row will be list of list. 
    So, in the list we can check is some value is present for some column then what is other value which is asssociated with it.
    Example :
    if
    {column1 = 'group', value1 = "ESM"}, {column2 = 'name', value2 = 'PDN Connectivity Success Count'}, {column3 = 'elapsed_time', value3 = "30"}
    then  {column3 = 'value', value3 = 100} 
    should match, similarly:
    {column1 = 'tab', value1 = "EMM"}, {column2 = 'measurement', value2 = 'Security Mode Completes},
     then  {column3 = 'value', value3 = 400}
    {column1 = 'tab', value1 = "ESM"}, {column2 = 'measurement', value2 = 'Activate Context Requests'}, 
    then  {column3 = 'value', value3 = 400}
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    dict_check= {"group": "'ESM'", "name": "'PDN Connectivity Success Count'", "elapsed_time" : 30}
    value_match = 100
    range_match = 10
    assert base.landslide_test_report(result_id, dict_check, value_match, range_match) == True


def test_landslide_Sessions_Established_count():
    """
    In this test case we will compare the number of rows in "Landslide Test Session chart" Section from Results
    we will filter for 'Test Summary::Sessions Established'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'Test Summary::Sessions Established'"
    assert base.landslide_test_Session_chart_count(full_name, result_id, 56) is True


def test_landslide_Sessions_Pending_count():
    """
    In this test case we will compare the number of rows in "Landslide Test Session chart" Section from Results
    we will filter for 'Test Summary::Sessions Pending'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'Test Summary::Sessions Pending'"
    assert base.landslide_test_Session_chart_count(full_name, result_id, 56) is True


def test_landslide_Actual_Session_Connects_count():
    """
    In this test case we will compare the number of rows in "Landslide Test Session chart" Section from Results
    we will filter for 'Test Summary::Actual Session Connects'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'Test Summary::Actual Session Connects'"
    assert base.landslide_test_Session_chart_count(full_name, result_id, 56) is True


def test_landslide_Actual_Session_Disconnects_count():
    """
    In this test case we will compare the number of rows in "Landslide Test Session chart" Section from Results
    we will filter for 'Test Summary::Actual Session Disconnects'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'Test Summary::Actual Session Disconnects'"
    assert base.landslide_test_Session_chart_count(full_name, result_id, 56) is True


def test_landslide_Sessions_Established_range_count():
    """
    In this test case we will compare the number of rows in "Landslide Test Session chart" Section from Results
    we will filter based on some condition for 'Test Summary::Sessions Established'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'Test Summary::Sessions Established'"
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, 46, 10, 100) is True


def test_landslide_Sessions_Pending_range_count():
    """
    In this test case we will compare the number of rows in "Landslide Test Session chart" Section from Results
    we will filter based on some condition for 'Test Summary::Sessions Pending'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'Test Summary::Sessions Pending'"
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, 1, 10, 100) is True


def test_landslide_Actual_Session_Connects_range_count():
    """
    In this test case we will compare the number of rows in "Landslide Test Session chart" Section from Results
    we will filter for 'Test Summary::Actual Session Connects'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'Test Summary::Actual Session Connects'"
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, 12, 10, 100) is True


def test_landslide_Actual_Session_Disconnects_range_count():
    """
    In this test case we will compare the number of rows in "Landslide Test Session chart" Section from Results
    we will filter for 'Test Summary::Actual Session Disconnects'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'Test Summary::Actual Session Disconnects'"
    assert base.landslide_test_Session_chart_range_count(full_name, result_id, 10, 10, 100) is True


def test_landslide_L3_Client_chart_Total_Bytes_Received():
    """
    In this test case we will compare the number of rows in "Landslide L3 client server chart" Section from Results
    we will filter for 'L3 Client::Total Bytes Received'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'L3 Client::Total Bytes Received'"
    assert base.landslide_L3_Client_Server_chart_count(full_name, result_id, 50) is True


def test_landslide_L3_Client_chart_Total_Bytes_Sent():
    """
    In this test case we will compare the number of rows in "Landslide L3 client server chart" Section from Results
    we will filter for 'L3 Client::Total Bytes Sent'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'L3 Client::Total Bytes Sent'"
    assert base.landslide_L3_Client_Server_chart_count(full_name, result_id, 50) is True


def test_landslide_L3_Server_chart_Total_Bytes_Received():
    """
    In this test case we will compare the number of rows in "Landslide L3 client server chart" Section from Results
    we will filter for 'L3 Server::Total Bytes Received'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'L3 Server::Total Bytes Received'"
    assert base.landslide_L3_Client_Server_chart_count(full_name, result_id, 50) is True


def test_landslide_L3_Server_chart_Total_Bytes_Sent():
    """
    In this test case we will compare the number of rows in "Landslide L3 client server chart" Section from Results
    we will filter for 'L3 Server::Total Bytes Sent'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'L3 Server::Total Bytes Sent'"
    assert base.landslide_L3_Client_Server_chart_count(full_name, result_id, 50) is True


def test_landslide_L3_Client_chart_Total_Bytes_Received_range_count():
    """
    In this test case we will compare the number of rows in "Landslide L3 client server chart" Section from Results
    we will filter for 'L3 Client::Total Bytes Received'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'L3 Client::Total Bytes Received'"
    assert base.landslide_L3_Client_Server_chart_range_count(full_name, result_id, 17, 10, 771095, op=">") is True


def test_landslide_L3_Client_chart_Total_Bytes_Sent_range_count():
    """
    In this test case we will compare the number of rows in "Landslide L3 client server chart" Section from Results
    we will filter for 'L3 Client::Total Bytes Receieved'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'L3 Client::Total Bytes Sent'"
    assert base.landslide_L3_Client_Server_chart_range_count(full_name, result_id, 17, 10, 771095, op=">") is True


def test_landslide_L3_server_chart_Total_bytes_received_range_count():
    """
    In this test case we will compare the number of rows in "Landslide L3 client server chart" Section from Results
    we will filter for 'L3 Server::Total Bytes Received'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'L3 Server::Total Bytes Received'"
    assert base.landslide_L3_Client_Server_chart_range_count(full_name, result_id, 17, 10, 771095, op=">") is True


def test_landslide_L3_server_chart_Total_bytes_sent_range_count():
    """
    In this test case we will compare the number of rows in "Landslide L3 client server chart" Section from Results
    we will filter for 'L3 Server::Total Bytes sent'
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    full_name = "landslide_measurement.full_name = 'L3 Server::Total Bytes Sent'"
    assert base.landslide_L3_Client_Server_chart_range_count(full_name, result_id, 17, 10, 771095, op=">") is True


def test_landslide_report_table():
    """
    In this test case we will compare the columns in "Landslide Report" table
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    column_list = base.landslide_tables_details(result_id, "landslide_report")
    assert column_list == ["timestamp", "is_summary", "value", "interval", "iteration", "elapsed_time"]
    assert len(column_list) == 6


def test_landslide_result_table():
    """
    In this test case we will compare the columns in "Landslide Result" table
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    column_list = base.landslide_tables_details(result_id, "landslide_result")
    assert column_list == ["timestamp", "is_summary", "value", "interval", "iteration", "elapsed_time", "actual_time"]
    assert len(column_list) == 7


def test_landslide_result_detailed_table():
    """
    In this test case we will compare the columns in "Landslide Result Detailed" table
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id

    column_list = base.landslide_tables_details(result_id, "landslide_result_detailed")
    assert column_list == ["timestamp", "value", "interval", "iteration", "elapsed_time", "actual_time"]
    assert len(column_list) == 6


def test_landslide_state_table():
    """
    In this test case we will compare the columns in "Landslide State" table
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    column_list = base.landslide_tables_details(result_id, "landslide_state")
    assert column_list == ["timestamp", "state", "iteration", "name"]
    assert len(column_list) == 4


def test_landslide_test_criteria():
    """
    In this test case we will compare the columns in "Landslide Test Criteria" table
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    column_list = base.landslide_tables_details(result_id, "test_criteria")
    assert column_list == ["timestamp", "id", "description", "status", "failure_count"]
    assert len(column_list) == 5


def test_landslide_test_measurement_table():
    """
    In this test case we will compare the columns in "Landslide test measurement" table
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    column_list = base.landslide_tables_details(result_id, "test_measurements")
    assert column_list == ["timestamp", "tab", "measurement", "value", "is_favorite"]
    assert len(column_list) == 5


def test_landslide_test_measurement_column_check():
    """
    In this test case we will check that column contain null values or not for "Landslide Test Measurements" Table from Results
    column names are :
    test_measurements.tab as tab",
    test_measurements.measurement as measurement",
    test_measurements.value as value",
    test_measurements.is_favorite as is_favorite"
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    assert base.landslide_test_measurement_column_null_check(result_id, ['tab', 'measurement', 'value', 'is_favorite']) == True


def test_landslide_test_report_column_check():
    """
    In this test case we will check that column contain null values or not for "Landslide Test Reports" Table from Results
    column names are :
    "landslide_measurement.group as group",
    "landslide_measurement.name as name",
    "landslide_test_case.index as tc_index",
    "landslide_test_server.name as server_name",
    "landslide_report.is_summary as is_summary",
    "landslide_report.iteration as iteration",
    "landslide_report.interval as interval",
    "landslide_report.elapsed_time as elapsed_time",
    "landslide_report.value as value"
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    assert base.landslide_test_report_column_null_check(result_id, ['group','name','interval']) == True


@pytest.mark.skip(reason="values in table are getting change on each run")
def test_landslide_test_measurement_complete_table_check():
    """
    In this test case we will check that complete data for "Landslide Test Measurements" Table from Results
    are same or different.
    pass the no. of rows to get from result, if pass value will be equal or greater than record in file,
    the test will pass else fail.
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    assert base.landslide_test_measurement_table_symmetric_diff(result_id, 1000) == True


@pytest.mark.skip(reason="values in table are getting change on each run")
def test_landslide_test_report_complete_table_check():
    """
    In this test case we will check that complete data for "Landslide Test Measurements" Table from Results
    are same or different.
    pass the no. of rows to get from result, if pass value will be equal or greater than record in file,
    the test will pass else fail.
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    assert base.landslide_test_report_table_symmetric_diff(result_id, 5115) == True


def test_landslide_states_complete_table_check():
    """
    In this test case we will check that complete data for "Landslide states" Table from Results
    are same or different.
    pass the no. of rows to get from result, if pass value will be equal or greater than record in file,
    the test will pass else fail.
    """
    if not pytest.cs_result_id:
        pytest.skip("skipping test, result id not found")

    result_id = pytest.cs_result_id
    assert base.landslide_states_table_symmetric_diff(result_id, 10) == True
