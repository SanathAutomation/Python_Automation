#!/bin/bash
set -euo pipefail

# Run the unit tests with additional checks
python3.11 -m pytest \
    --ignore=./cstest \
    "$@"