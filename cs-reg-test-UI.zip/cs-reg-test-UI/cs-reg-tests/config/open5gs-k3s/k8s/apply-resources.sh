#!/bin/bash
set -euo pipefail

NS=""
CLEAN="0"
SDIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )

POSITIONAL_ARGS=()
while [[ $# -gt 0 ]]; do
  case $1 in
    -n|--namespace)
      NS="$2"
      shift # past argument
      shift # past value
      ;;
    -c|--clean)
      CLEAN="$2"
      shift # past argument
      shift # past value
      ;;
    -*|--*)
      echo "Unknown option $1"
      exit 1
      ;;
    *)
      POSITIONAL_ARGS+=("$1") # save positional arg
      shift # past argument
      ;;
  esac
done

if [ -z "${NS}" ]; then
  echo "You must set --namespace | -n"
  exit 1
fi

update () {
  if [ "$CLEAN" == "1" ]; then
    CMD="kubectl delete -n ${NS} -f ${SDIR}/$1" 
    echo "$CMD"
    $CMD
  fi
  CMD="kubectl apply -n ${NS} -f ${SDIR}/$1" 
  echo "$CMD"
  $CMD
}

update nginx.yaml
