##  Chaos agent install
open5gs-k3s assumes CloudSure is installed elsewhere to reduce resource requirements
Before running tests change the agents to point to the external chaos controller address
```bash
helm upgrade --install chaos oci://registry.aiontest.net/helm-charts/chaos-agent --version "0.1.*" -n cs-chaos -f chaos_k3s.yaml --set "externalChaosController.url=http://10.109.119.56:5180"
```
