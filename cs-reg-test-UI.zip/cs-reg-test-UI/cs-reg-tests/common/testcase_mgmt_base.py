import requests

from common import project_mgmt_base as pmb


def check_access_token_cs_url(access_token: str, cs_params: dict):
    """
    This method is used to check cloudsure url and access_token is not empty
    """
    cs_url = cs_params.get("cs_url", "")

    if not cs_url:
        raise ValueError("Cloudsure URL not found")
    if not access_token:
        raise ValueError("Access Token is missing")
    return access_token, cs_url


def get_project(proj_id: str, cs_url: str, headers: dict):
    """
    In this method we use get request to obtain particular project details
    """
    api_url = f'{cs_url}/api/projects/{proj_id}'
    response = requests.get(api_url, headers=headers)
    return response


def get_project_details(access_token: str, proj_name: str, cs_params: dict):
    """
    This method is use to get the details of project by providing project name
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    proj_id = pmb.get_project_id(cs_url, headers, proj_name)
    if proj_id:
        return get_project(proj_id, cs_url, headers)
    else:
        return False


def get_project_details_with_id(access_token: str, proj_id: str, cs_params: dict):
    """
    This method is use to get the details of project by providing project id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}
    if proj_id:
        return get_project(proj_id, cs_url, headers)


def create_blank_testcase(access_token: str, proj_name: str, testcase_name: str, cs_params: dict):
    """
    This method is use to create the testcase by providing project name and testcase name
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    proj_id = pmb.get_project_id(cs_url, headers, proj_name)
    proj_data = {
        "id": "",
        "name": testcase_name,
        "enabled": True,
        "description": "",
        "input": {
        },
        "version": "",
        "test_package_id": "",
        "testcase_template_id": "spirent_resiliency.RESILIENCY_WORKFLOW",
        "testcase_template_name": "",
        "project_id": proj_id,
        "input_valid": True,
        "created_by": "",
        "updated_by": "",
        "ui_metadata": {
        },
        "testcase_type": ""
    }

    api_url = f'{cs_url}/api/testcases'
    response = requests.post(api_url, data=proj_data, headers=headers)
    return response


def get_testcase(testcase_id: str, cs_url: str, headers: dict):
    """
    In this method we use get request to obtain particular testcase details
    """
    api_url = f'{cs_url}/api/testcases/{testcase_id}'
    response = requests.get(api_url, headers=headers)
    return response


def get_testcase_details(access_token: str, proj_name: str, testcase_name: str, cs_params: dict):
    """
    This method is use to get the testcase by providing project name and testcase name
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    project_details = get_project_details(access_token, proj_name, cs_params)
    testcases = project_details.json()['testcases']
    testcase_id = None
    for testcase in testcases:
        if testcase['name'] == testcase_name:
            testcase_id = testcase['id']

    if testcase_id:
        return get_testcase(testcase_id, cs_url, headers)


def get_testcase_details_with_id(access_token: str, testcase_id: str, cs_params: dict):
    """
    This method is use to get the testcase by providing testcase id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    if testcase_id:
        return get_testcase(testcase_id, cs_url, headers)


def update_testcase(access_token: str, proj_name: str, testcase_name: str, cs_params: dict):
    """
    This method is use to update the testcase by providing project name and testcase name
    """
    test_details = get_testcase_details(access_token, proj_name, testcase_name, cs_params)
    test_details_data = test_details.json()
    project_id = test_details_data['project_id']
    test_id = test_details_data['id']

    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    proj_data = {
        "id": test_id,
        "name": testcase_name,
        "enabled": True,
        "input": {
            "debug": {
                "app_ip": "",
                "result_server_url": "",
                "write_only_related_object_events": False
            },
            "environment": {
                "cluster_id": "48af410e-6060-4ed9-928a-b3875f5cef24",
                "credential_id": "0015ca0d10164d5d9d31d380e04e3ea8",
                "description": "",
                "name": "okd03"
            },
            "load_generator": {
                "credential_id": "",
                "description": "",
                "name": ""
            },
            "workflow_controller": {
                "delete_workflow": True,
                "poll_status_interval_ms": 1000,
                "poll_status_max_wait_ms": 500,
                "url": "http://cs-workflow-engine-controller"
            }
        },
        "version": "1.0.0",
        "test_package_id": "spirent_resiliency",
        "testcase_template_id": "spirent_resiliency.RESILIENCY_WORKFLOW",
        "testcase_template_name": "RESILIENCY_WORKFLOW",
        "project_id": project_id,
        "project_name": proj_name,
        "input_valid": True,
        "ui_metadata": {
        },
        "testcase_type": "TEST"
    }

    api_url = f'{cs_url}/api/testcases/{test_id}'
    response = requests.put(api_url, json=proj_data, headers=headers)
    return response


def update_testcase_scenario(access_token: str, proj_name: str, testcase_name: str, cs_params: dict):
    """
    This method is use to update the testcase by providing project name and testcase name
    In this section we are updating scenario
    """
    test_details = get_testcase_details(access_token, proj_name, testcase_name, cs_params)
    test_details_data = test_details.json()
    project_id = test_details_data['project_id']
    test_id = test_details_data['id']

    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    proj_data = {
        "id": test_id,
        "name": testcase_name,
        "enabled": True,
        "input": {
            "debug": {
                "app_ip": "",
                "result_server_url": "",
                "write_only_related_object_events": False
            },
            "environment": {
                "cluster_id": "48af410e-6060-4ed9-928a-b3875f5cef24",
                "credential_id": "0015ca0d10164d5d9d31d380e04e3ea8",
                "description": "",
                "name": "okd03"
            },
            "load_generator": {
                "credential_id": "",
                "description": "",
                "name": ""
            },
            "workflow_controller": {
                "delete_workflow": True,
                "poll_status_interval_ms": 1000,
                "poll_status_max_wait_ms": 500,
                "url": "http://cs-workflow-engine-controller"
            },
            "scenario": {
                "name": "Blank Scenario",
                "actions": [
                    {
                        "config": {
                            "selection": {
                                "namespace": "cs-test-reg",
                                "selection_method": {
                                    "type": "SELECTION_COUNT",
                                    "count": 1,
                                    "order": "RANDOM"
                                },
                                "targets": [
                                    {
                                       "process_input_method": {
                                            "pod_name": "reg-ss-0",
                                            "type": "POD_NAME"
                                        }
                                    }
                                ]
                            },
                            "recovery_interval_sec": 40
                        },
                        "name": "Pod Delete",
                        "description": "Pod Delete",
                        "urn": "poddelete.00.impairment.spirent.com",
                        "run_when": "AfterPrevious",
                        "delay_sec": 10
                    }
                ],
                "delay_sec": 5
            }
        },
        "version": "1.0.0",
        "test_package_id": "spirent_resiliency",
        "testcase_template_id": "spirent_resiliency.RESILIENCY_WORKFLOW",
        "testcase_template_name": "RESILIENCY_WORKFLOW",
        "project_id": project_id,
        "project_name": proj_name,
        "input_valid": True,
        "ui_metadata": {
        },
        "testcase_type": "TEST"
    }

    api_url = f'{cs_url}/api/testcases/{test_id}'
    response = requests.put(api_url, json=proj_data, headers=headers)
    return response


def delete_testcase(cs_url: str, headers: dict, testcase_id: str):
    """
    In this method we use delete request to delete testcase
    """
    api_url = f'{cs_url}/api/testcases/{testcase_id}'
    response = requests.delete(api_url, headers=headers)
    return response


def delete_testcase_without_id(access_token: str, proj_name: str, testcase_name: str, cs_params: dict):
    """
    This method is use to delete the testcase by providing project name and testcase name
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    project_details = get_project_details(access_token, proj_name, cs_params)
    testcases = project_details.json()['testcases']
    testcase_id = None
    for testcase in testcases:
        if testcase['name'] == testcase_name:
            testcase_id = testcase['id']

    if testcase_id:
        return delete_testcase(cs_url, headers, testcase_id)


def delete_testcase_with_id(access_token: str, testcase_id: str, cs_params: dict):
    """
    This method is use to delete the testcase by providing testcase id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    if testcase_id:
        return delete_testcase(cs_url, headers, testcase_id)
