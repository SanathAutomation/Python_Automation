import json

import requests


def check_access_token_cs_url(access_token: str, cs_params: dict):
    """
    This method is used to check cloudsure url and access_token is not empty
    """
    cs_url = cs_params.get("cs_url", "")

    if not cs_url:
        raise ValueError("Cloudsure URL not found")
    if not access_token:
        raise ValueError("Access Token is missing")
    return access_token, cs_url


def create_analysis_testcase(access_token: str, testcase_payload, cs_params: dict):
    """
    This method is use to create the testcase
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    # headers = {'Authorization': f'Bearer {access_token}'}
    headers = {"Content-Type": "application/json", 'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/testcases'
    response = requests.post(api_url, data=json.dumps(testcase_payload), headers=headers)
    return response


def get_testcase_by_name(access_token: str, testcase_name: str, cs_params: dict):
    """
    This method is use to get the details of testcase by providing testcase name
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/testcases?testcase_type=ANALYSIS&name={testcase_name}'
    response = requests.get(api_url, headers=headers)

    if response.json()['items']:
        return response.json()[0]['id']
    else:
        return None


def get_testcase_by_id(access_token: str, analysis_id: str, cs_params: dict):
    """
    This method is use to get the testcase by providing testcase id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/testcases/{analysis_id}'
    response = requests.get(api_url, headers=headers)
    return response


def update_analysis_testcase(access_token: str, analysis_id, testcase_payload, cs_params: dict):
    """
    This method is use to update the testcase by providing analysis id and testcase payload
    """

    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {"Content-Type": "application/json", 'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/testcases/{analysis_id}'
    response = requests.put(api_url, json=testcase_payload, headers=headers)
    return response


def delete_testcase_by_id(access_token: str, analysis_id: str, cs_params: dict):
    """
    This method is use to delete the testcase by providing testcase id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/testcases/{analysis_id}'
    response = requests.delete(api_url, headers=headers)
    return response
