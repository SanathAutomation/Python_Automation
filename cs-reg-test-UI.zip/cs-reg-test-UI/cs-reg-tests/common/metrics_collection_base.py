import json

import pytest
import requests


def get_result(data):
    """
    This function is used to get the data of table through post request
    """
    if not pytest.cs_base_url:
        pytest.skip("skipping test, cloudsure url not found")
    base_url = pytest.cs_base_url
    headers = {"Content-Type": "application/json"}
    url = f"{base_url}/tciq/queries"

    resp = requests.post(url, headers=headers, data=json.dumps(data))
    assert resp.status_code == 200
    response = json.loads(resp.content)
    return response["result"]["rows"]


def kube_state_metrics_daemonset_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "kube state damemonset metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_kube_state_daemonset.timestamp) as timestamp",
                                    "metrics_kube_state_daemonset_id.daemonset as metrics_kube_state_daemonset_id_daemonset",
                                    "(metrics_kube_state_daemonset.kube_daemonset_created) as kube_daemonset_created",
                                    "(metrics_kube_state_daemonset.kube_daemonset_status_current_number_scheduled) as \
                                        kube_daemonset_status_current_number_scheduled",
                                    "(metrics_kube_state_daemonset.kube_daemonset_status_desired_number_scheduled) as \
                                        kube_daemonset_status_desired_number_scheduled",
                                    "(metrics_kube_state_daemonset.kube_daemonset_status_number_available) as \
                                        kube_daemonset_status_number_available",
                                    "(metrics_kube_state_daemonset.kube_daemonset_status_number_misscheduled) as \
                                        kube_daemonset_status_number_misscheduled",
                                    "(metrics_kube_state_daemonset.kube_daemonset_status_number_ready) as \
                                        kube_daemonset_status_number_ready",
                                    "(metrics_kube_state_daemonset.kube_daemonset_status_number_unavailable) as \
                                        kube_daemonset_status_number_unavailable",
                                    "(metrics_kube_state_daemonset.kube_daemonset_status_observed_generation) as \
                                        kube_daemonset_status_observed_generation"
                                ],
                                "filters": filter,
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_kube_state_daemonset_id_daemonset as metrics_kube_state_daemonset_id_daemonset",
                            "view.kube_daemonset_created as kube_daemonset_created",
                            "view.kube_daemonset_status_current_number_scheduled as \
                                kube_daemonset_status_current_number_scheduled",
                            "view.kube_daemonset_status_desired_number_scheduled as\
                                 kube_daemonset_status_desired_number_scheduled",
                            "view.kube_daemonset_status_number_available as kube_daemonset_status_number_available",
                            "view.kube_daemonset_status_number_misscheduled as kube_daemonset_status_number_misscheduled",
                            "view.kube_daemonset_status_number_ready as kube_daemonset_status_number_ready",
                            "view.kube_daemonset_status_number_unavailable as kube_daemonset_status_number_unavailable",
                            "view.kube_daemonset_status_observed_generation as kube_daemonset_status_observed_generation"
                        ],
                        "filters": [
                        ],
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def kube_state_metrics_deployment_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "kube state deployment metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_kube_state_deployment.timestamp) as timestamp",
                                    "metrics_kube_state_deployment_id.deployment as metrics_kube_state_deployment_id_deployment",
                                    "(metrics_kube_state_deployment.kube_deployment_created) as kube_deployment_created",
                                    "(metrics_kube_state_deployment.kube_deployment_status_replicas) as \
                                        kube_deployment_status_replicas",
                                    "(metrics_kube_state_deployment.kube_deployment_status_replicas_ready) as \
                                        kube_deployment_status_replicas_ready",
                                    "(metrics_kube_state_deployment.kube_deployment_status_replicas_available) as \
                                        kube_deployment_status_replicas_available",
                                    "(metrics_kube_state_deployment.kube_deployment_status_replicas_unavailable) as \
                                        kube_deployment_status_replicas_unavailable",
                                    "(metrics_kube_state_deployment.kube_deployment_status_observed_generation) as \
                                        kube_deployment_status_observed_generation",
                                    "(metrics_kube_state_deployment.kube_deployment_status_condition) as \
                                        kube_deployment_status_condition",
                                    "(metrics_kube_state_deployment.kube_deployment_spec_replicas) as \
                                        kube_deployment_spec_replicas",
                                    "metrics_kube_state_id.namespace as metrics_kube_state_id_namespace"
                                ],
                                "filters": filter,
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_kube_state_deployment_id_deployment as metrics_kube_state_deployment_id_deployment",
                            "view.kube_deployment_created as kube_deployment_created",
                            "view.kube_deployment_status_replicas as kube_deployment_status_replicas",
                            "view.kube_deployment_status_replicas_ready as kube_deployment_status_replicas_ready",
                            "view.kube_deployment_status_replicas_available as kube_deployment_status_replicas_available",
                            "view.kube_deployment_status_replicas_unavailable as kube_deployment_status_replicas_unavailable",
                            "view.kube_deployment_status_observed_generation as kube_deployment_status_observed_generation",
                            "view.kube_deployment_status_condition as kube_deployment_status_condition",
                            "view.kube_deployment_spec_replicas as kube_deployment_spec_replicas",
                            "view.metrics_kube_state_id_namespace as metrics_kube_state_id_namespace"
                        ],
                        "filters": [
                        ],
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def kube_state_metrics_pod_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "kube state pod metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_kube_state_pod.timestamp) as timestamp",
                                    "metrics_kube_state_pod_id.pod as metrics_kube_state_pod_id_pod",
                                    "(metrics_kube_state_pod.kube_pod_container_info) as kube_pod_container_info",
                                    "(metrics_kube_state_pod.kube_pod_container_state_started) as \
                                        kube_pod_container_state_started",
                                    "(metrics_kube_state_pod.kube_pod_container_status_ready) as kube_pod_container_status_ready",
                                    "(metrics_kube_state_pod.kube_pod_container_status_restarts_total) as \
                                        kube_pod_container_status_restarts_total",
                                    "(metrics_kube_state_pod.kube_pod_container_status_running) as \
                                        kube_pod_container_status_running",
                                    "(metrics_kube_state_pod.kube_pod_container_status_terminated) as \
                                        kube_pod_container_status_terminated",
                                    "(metrics_kube_state_pod.kube_pod_container_status_waiting) as \
                                        kube_pod_container_status_waiting",
                                    "metrics_kube_state_pod_id.uid as metrics_kube_state_pod_id_uid",
                                    "metrics_kube_state_pod_id.image as metrics_kube_state_pod_id_image",
                                    "metrics_kube_state_pod_id.pod_ip as metrics_kube_state_pod_id_pod_ip"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_kube_state_pod_id_pod as metrics_kube_state_pod_id_pod",
                            "view.kube_pod_container_info as kube_pod_container_info",
                            "view.kube_pod_container_state_started as kube_pod_container_state_started",
                            "view.kube_pod_container_status_ready as kube_pod_container_status_ready",
                            "view.kube_pod_container_status_restarts_total as kube_pod_container_status_restarts_total",
                            "view.kube_pod_container_status_running as kube_pod_container_status_running",
                            "view.kube_pod_container_status_terminated as kube_pod_container_status_terminated",
                            "view.kube_pod_container_status_waiting as kube_pod_container_status_waiting",
                            "view.metrics_kube_state_pod_id_uid as metrics_kube_state_pod_id_uid",
                            "view.metrics_kube_state_pod_id_image as metrics_kube_state_pod_id_image",
                            "view.metrics_kube_state_pod_id_pod_ip as metrics_kube_state_pod_id_pod_ip"
                        ],
                        "filters": filter,
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def kube_state_metrics_replicaset_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "kube state replicaset metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_kube_state_replicaset.timestamp) as timestamp",
                                    "metrics_kube_state_replicaset_id.replicaset as metrics_kube_state_replicaset_id_replicaset",
                                    "(metrics_kube_state_replicaset.kube_replicaset_created) as kube_replicaset_created",
                                    "(metrics_kube_state_replicaset.kube_replicaset_labels) as kube_replicaset_labels",
                                    "(metrics_kube_state_replicaset.kube_replicaset_metadata_generation) as \
                                        kube_replicaset_metadata_generation",
                                    "(metrics_kube_state_replicaset.kube_replicaset_owner) as kube_replicaset_owner",
                                    "(metrics_kube_state_replicaset.kube_replicaset_spec_replicas) as \
                                        kube_replicaset_spec_replicas",
                                    "(metrics_kube_state_replicaset.kube_replicaset_status_fully_labeled_replicas) as \
                                        kube_replicaset_status_fully_labeled_replicas",
                                    "metrics_kube_state_replicaset_id.owner_kind as metrics_kube_state_replicaset_id_owner_kind",
                                    "metrics_kube_state_replicaset_id.owner_name as metrics_kube_state_replicaset_id_owner_name"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_kube_state_replicaset_id_replicaset as metrics_kube_state_replicaset_id_replicaset",
                            "view.kube_replicaset_created as kube_replicaset_created",
                            "view.kube_replicaset_labels as kube_replicaset_labels",
                            "view.kube_replicaset_metadata_generation as kube_replicaset_metadata_generation",
                            "view.kube_replicaset_owner as kube_replicaset_owner",
                            "view.kube_replicaset_spec_replicas as kube_replicaset_spec_replicas",
                            "view.kube_replicaset_status_fully_labeled_replicas as kube_replicaset_status_fully_labeled_replicas",
                            "view.metrics_kube_state_replicaset_id_owner_kind as metrics_kube_state_replicaset_id_owner_kind",
                            "view.metrics_kube_state_replicaset_id_owner_name as metrics_kube_state_replicaset_id_owner_name"
                        ],
                        "filters": filter,
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def kube_state_metrics_statefulset_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "kube state statefullset metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_kube_state_statefulset.timestamp) as timestamp",
                                    "metrics_kube_state_statefulset_id.statefulset as \
                                        metrics_kube_state_statefulset_id_statefulset",
                                    "(metrics_kube_state_statefulset.kube_statefulset_created) as kube_statefulset_created",
                                    "(metrics_kube_state_statefulset.kube_statefulset_labels) as kube_statefulset_labels",
                                    "(metrics_kube_state_statefulset.kube_statefulset_metadata_generation) as \
                                        kube_statefulset_metadata_generation",
                                    "(metrics_kube_state_statefulset.kube_statefulset_replicas) as kube_statefulset_replicas",
                                    "(metrics_kube_state_statefulset.kube_statefulset_status_current_revision) as \
                                        kube_statefulset_status_current_revision",
                                    "(metrics_kube_state_statefulset.kube_statefulset_status_observed_generation) as \
                                        kube_statefulset_status_observed_generation",
                                    "(metrics_kube_state_statefulset.kube_statefulset_status_replicas) as \
                                        kube_statefulset_status_replicas",
                                    "(metrics_kube_state_statefulset.kube_statefulset_status_replicas_current) as \
                                        kube_statefulset_status_replicas_current",
                                    "metrics_kube_state_statefulset_id.revision as metrics_kube_state_statefulset_id_revision"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_kube_state_statefulset_id_statefulset as metrics_kube_state_statefulset_id_statefulset",
                            "view.kube_statefulset_created as kube_statefulset_created",
                            "view.kube_statefulset_labels as kube_statefulset_labels",
                            "view.kube_statefulset_metadata_generation as kube_statefulset_metadata_generation",
                            "view.kube_statefulset_replicas as kube_statefulset_replicas",
                            "view.kube_statefulset_status_current_revision as kube_statefulset_status_current_revision",
                            "view.kube_statefulset_status_observed_generation as kube_statefulset_status_observed_generation",
                            "view.kube_statefulset_status_replicas as kube_statefulset_status_replicas",
                            "view.kube_statefulset_status_replicas_current as kube_statefulset_status_replicas_current",
                            "view.metrics_kube_state_statefulset_id_revision as metrics_kube_state_statefulset_id_revision"
                        ],
                        "filters": filter,
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def kube_state_metrics_service_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "kube state service metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_kube_state_service.timestamp) as timestamp",
                                    "metrics_kube_state_service_id.service as metrics_kube_state_service_id_service",
                                    "(metrics_kube_state_service.kube_service_info) as kube_service_info",
                                    "(metrics_kube_state_service.kube_service_created) as kube_service_created",
                                    "(metrics_kube_state_service.kube_service_spec_type) as kube_service_spec_type",
                                    "(metrics_kube_state_service.kube_service_labels) as kube_service_labels",
                                    "(metrics_kube_state_service.kube_service_spec_external_ip) as kube_service_spec_external_ip",
                                    "metrics_kube_state_service_id.uid as metrics_kube_state_service_id_uid",
                                    "metrics_kube_state_service_id.ip as metrics_kube_state_service_id_ip",
                                    "metrics_kube_state_service_id.external_name as metrics_kube_state_service_id_external_name"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_kube_state_service_id_service as metrics_kube_state_service_id_service",
                            "view.kube_service_info as kube_service_info",
                            "view.kube_service_created as kube_service_created",
                            "view.kube_service_spec_type as kube_service_spec_type",
                            "view.kube_service_labels as kube_service_labels",
                            "view.kube_service_spec_external_ip as kube_service_spec_external_ip",
                            "view.metrics_kube_state_service_id_uid as metrics_kube_state_service_id_uid",
                            "view.metrics_kube_state_service_id_ip as metrics_kube_state_service_id_ip",
                            "view.metrics_kube_state_service_id_external_name as metrics_kube_state_service_id_external_name"
                        ],
                        "filters": filter,
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def node_exporter_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "node exporter metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_node_exporter.timestamp) as timestamp",
                                    "metrics_node_exporter_node_id.instance as metrics_node_exporter_node_id_instance",
                                    "(metrics_node_exporter.node_context_switches_total) as node_context_switches_total",
                                    "(metrics_node_exporter.node_entropy_available_bits) as node_entropy_available_bits",
                                    "(metrics_node_exporter.node_exporter_build_info) as node_exporter_build_info",
                                    "(metrics_node_exporter.node_filefd_allocated) as node_filefd_allocated",
                                    "(metrics_node_exporter.node_filefd_maximum) as node_filefd_maximum",
                                    "(metrics_node_exporter.node_forks_total) as node_forks_total",
                                    "(metrics_node_exporter.node_intr_total) as node_intr_total",
                                    "(metrics_node_exporter.node_load1) as node_load1",
                                    "(metrics_node_exporter.node_load5) as node_load5",
                                    "(metrics_node_exporter.node_load15) as node_load15",
                                    "metrics_node_exporter_node_id.id as metrics_node_exporter_node_id_id"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_node_exporter_node_id_instance as metrics_node_exporter_node_id_instance",
                            "view.node_context_switches_total as node_context_switches_total",
                            "view.node_entropy_available_bits as node_entropy_available_bits",
                            "view.node_exporter_build_info as node_exporter_build_info",
                            "view.node_filefd_allocated as node_filefd_allocated",
                            "view.node_filefd_maximum as node_filefd_maximum",
                            "view.node_forks_total as node_forks_total",
                            "view.node_intr_total as node_intr_total",
                            "view.node_load1 as node_load1",
                            "view.node_load5 as node_load5",
                            "view.node_load15 as node_load15",
                            "view.metrics_node_exporter_node_id_id as metrics_node_exporter_node_id_id"
                        ],
                        "filters": [
                        ],
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def node_exporter_collector_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "node exporter collector metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_node_exporter_collector.timestamp) as timestamp",
                                    "metrics_node_exporter_collector_id.collector as \
                                        metrics_node_exporter_collector_id_collector",
                                    "(metrics_node_exporter_collector.node_scrape_collector_duration_seconds) as \
                                        node_scrape_collector_duration_seconds",
                                    "(metrics_node_exporter_collector.node_scrape_collector_success) as \
                                        node_scrape_collector_success",
                                    "metrics_node_exporter_node_id.instance as metrics_node_exporter_node_id_instance",
                                    "metrics_node_exporter_node_id.id as metrics_node_exporter_node_id_id"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_node_exporter_collector_id_collector as metrics_node_exporter_collector_id_collector",
                            "view.node_scrape_collector_duration_seconds as node_scrape_collector_duration_seconds",
                            "view.node_scrape_collector_success as node_scrape_collector_success",
                            "view.metrics_node_exporter_node_id_instance as metrics_node_exporter_node_id_instance",
                            "view.metrics_node_exporter_node_id_id as metrics_node_exporter_node_id_id"
                        ],
                        "filters": [
                        ],
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def node_exporter_cpu_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "node exporter cpu metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_node_exporter_cpu.timestamp) as timestamp",
                                    "metrics_node_exporter_cpu_id.cpu as metrics_node_exporter_cpu_id_cpu",
                                    "metrics_node_exporter_cpu_id.mode as metrics_node_exporter_cpu_id_mode",
                                    "(metrics_node_exporter_cpu.node_cpu_guest_seconds_total) as node_cpu_guest_seconds_total",
                                    "(metrics_node_exporter_cpu.node_cpu_seconds_total) as node_cpu_seconds_total",
                                    "metrics_node_exporter_node_id.instance as metrics_node_exporter_node_id_instance",
                                    "metrics_node_exporter_node_id.id as metrics_node_exporter_node_id_id"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_node_exporter_cpu_id_cpu as metrics_node_exporter_cpu_id_cpu",
                            "view.metrics_node_exporter_cpu_id_mode as metrics_node_exporter_cpu_id_mode",
                            "view.node_cpu_guest_seconds_total as node_cpu_guest_seconds_total",
                            "view.node_cpu_seconds_total as node_cpu_seconds_total",
                            "view.metrics_node_exporter_node_id_instance as metrics_node_exporter_node_id_instance",
                            "view.metrics_node_exporter_node_id_id as metrics_node_exporter_node_id_id"
                        ],
                        "filters": [
                        ],
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def node_exporter_memory_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "node exporter memory metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_node_exporter.timestamp) as timestamp",
                                    "metrics_node_exporter_node_id.instance as metrics_node_exporter_node_id_instance",
                                    "(metrics_node_exporter.node_memory_active_anon_bytes) as node_memory_active_anon_bytes",
                                    "(metrics_node_exporter.node_memory_active_bytes) as node_memory_active_bytes",
                                    "(metrics_node_exporter.node_memory_active_file_bytes) as node_memory_active_file_bytes",
                                    "(metrics_node_exporter.node_memory_anonhugepages_bytes) as node_memory_anonhugepages_bytes",
                                    "(metrics_node_exporter.node_memory_anonpages_bytes) as node_memory_anonpages_bytes",
                                    "(metrics_node_exporter.node_memory_bounce_bytes) as node_memory_bounce_bytes",
                                    "(metrics_node_exporter.node_memory_buffers_bytes) as node_memory_buffers_bytes",
                                    "(metrics_node_exporter.node_memory_cached_bytes) as node_memory_cached_bytes",
                                    "(metrics_node_exporter.node_memory_commitlimit_bytes) as node_memory_commitlimit_bytes",
                                    "(metrics_node_exporter.node_memory_committed_as_bytes) as node_memory_committed_as_bytes",
                                    "(metrics_node_exporter.node_memory_directmap1g_bytes) as node_memory_directmap1g_bytes",
                                    "(metrics_node_exporter.node_memory_directmap2m_bytes) as node_memory_directmap2m_bytes",
                                    "(metrics_node_exporter.node_memory_directmap4k_bytes) as node_memory_directmap4k_bytes",
                                    "(metrics_node_exporter.node_memory_dirty_bytes) as node_memory_dirty_bytes",
                                    "(metrics_node_exporter.node_memory_hugepages_free) as node_memory_hugepages_free",
                                    "(metrics_node_exporter.node_memory_hugepages_rsvd) as node_memory_hugepages_rsvd",
                                    "(metrics_node_exporter.node_memory_hugepages_surp) as node_memory_hugepages_surp",
                                    "(metrics_node_exporter.node_memory_hugepages_total) as node_memory_hugepages_total",
                                    "(metrics_node_exporter.node_memory_hugepagesize_bytes) as node_memory_hugepagesize_bytes",
                                    "(metrics_node_exporter.node_memory_inactive_anon_bytes) as node_memory_inactive_anon_bytes",
                                    "(metrics_node_exporter.node_memory_inactive_bytes) as node_memory_inactive_bytes",
                                    "(metrics_node_exporter.node_memory_inactive_file_bytes) as node_memory_inactive_file_bytes",
                                    "(metrics_node_exporter.node_memory_kernelstack_bytes) as node_memory_kernelstack_bytes",
                                    "(metrics_node_exporter.node_memory_mapped_bytes) as node_memory_mapped_bytes",
                                    "(metrics_node_exporter.node_memory_memavailable_bytes) as node_memory_memavailable_bytes",
                                    "(metrics_node_exporter.node_memory_memfree_bytes) as node_memory_memfree_bytes",
                                    "(metrics_node_exporter.node_memory_memtotal_bytes) as node_memory_memtotal_bytes",
                                    "(metrics_node_exporter.node_memory_mlocked_bytes) as node_memory_mlocked_bytes",
                                    "(metrics_node_exporter.node_memory_nfs_unstable_bytes) as node_memory_nfs_unstable_bytes",
                                    "(metrics_node_exporter.node_memory_pagetables_bytes) as node_memory_pagetables_bytes",
                                    "(metrics_node_exporter.node_memory_shmem_bytes) as node_memory_shmem_bytes",
                                    "(metrics_node_exporter.node_memory_shmemhugepages_bytes) as \
                                        node_memory_shmemhugepages_bytes",
                                    "(metrics_node_exporter.node_memory_shmempmdmapped_bytes) as \
                                        node_memory_shmempmdmapped_bytes",
                                    "(metrics_node_exporter.node_memory_slab_bytes) as node_memory_slab_bytes",
                                    "(metrics_node_exporter.node_memory_sreclaimable_bytes) as node_memory_sreclaimable_bytes",
                                    "(metrics_node_exporter.node_memory_sunreclaim_bytes) as node_memory_sunreclaim_bytes",
                                    "(metrics_node_exporter.node_memory_swapcached_bytes) as node_memory_swapcached_bytes",
                                    "(metrics_node_exporter.node_memory_swapfree_bytes) as node_memory_swapfree_bytes",
                                    "(metrics_node_exporter.node_memory_swaptotal_bytes) as node_memory_swaptotal_bytes",
                                    "(metrics_node_exporter.node_memory_unevictable_bytes) as node_memory_unevictable_bytes",
                                    "(metrics_node_exporter.node_memory_vmallocchunk_bytes) as node_memory_vmallocchunk_bytes",
                                    "(metrics_node_exporter.node_memory_vmalloctotal_bytes) as node_memory_vmalloctotal_bytes",
                                    "(metrics_node_exporter.node_memory_vmallocused_bytes) as node_memory_vmallocused_bytes",
                                    "(metrics_node_exporter.node_memory_writeback_bytes) as node_memory_writeback_bytes",
                                    "(metrics_node_exporter.node_memory_writebacktmp_bytes) as node_memory_writebacktmp_bytes",
                                    "metrics_node_exporter_node_id.id as metrics_node_exporter_node_id_id"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_node_exporter_node_id_instance as metrics_node_exporter_node_id_instance",
                            "view.node_memory_active_anon_bytes as node_memory_active_anon_bytes",
                            "view.node_memory_active_bytes as node_memory_active_bytes",
                            "view.node_memory_active_file_bytes as node_memory_active_file_bytes",
                            "view.node_memory_anonhugepages_bytes as node_memory_anonhugepages_bytes",
                            "view.node_memory_anonpages_bytes as node_memory_anonpages_bytes",
                            "view.node_memory_bounce_bytes as node_memory_bounce_bytes",
                            "view.node_memory_buffers_bytes as node_memory_buffers_bytes",
                            "view.node_memory_cached_bytes as node_memory_cached_bytes",
                            "view.node_memory_commitlimit_bytes as node_memory_commitlimit_bytes",
                            "view.node_memory_committed_as_bytes as node_memory_committed_as_bytes",
                            "view.node_memory_directmap1g_bytes as node_memory_directmap1g_bytes",
                            "view.node_memory_directmap2m_bytes as node_memory_directmap2m_bytes",
                            "view.node_memory_directmap4k_bytes as node_memory_directmap4k_bytes",
                            "view.node_memory_dirty_bytes as node_memory_dirty_bytes",
                            "view.node_memory_hugepages_free as node_memory_hugepages_free",
                            "view.node_memory_hugepages_rsvd as node_memory_hugepages_rsvd",
                            "view.node_memory_hugepages_surp as node_memory_hugepages_surp",
                            "view.node_memory_hugepages_total as node_memory_hugepages_total",
                            "view.node_memory_hugepagesize_bytes as node_memory_hugepagesize_bytes",
                            "view.node_memory_inactive_anon_bytes as node_memory_inactive_anon_bytes",
                            "view.node_memory_inactive_bytes as node_memory_inactive_bytes",
                            "view.node_memory_inactive_file_bytes as node_memory_inactive_file_bytes",
                            "view.node_memory_kernelstack_bytes as node_memory_kernelstack_bytes",
                            "view.node_memory_mapped_bytes as node_memory_mapped_bytes",
                            "view.node_memory_memavailable_bytes as node_memory_memavailable_bytes",
                            "view.node_memory_memfree_bytes as node_memory_memfree_bytes",
                            "view.node_memory_memtotal_bytes as node_memory_memtotal_bytes",
                            "view.node_memory_mlocked_bytes as node_memory_mlocked_bytes",
                            "view.node_memory_nfs_unstable_bytes as node_memory_nfs_unstable_bytes",
                            "view.node_memory_pagetables_bytes as node_memory_pagetables_bytes",
                            "view.node_memory_shmem_bytes as node_memory_shmem_bytes",
                            "view.node_memory_shmemhugepages_bytes as node_memory_shmemhugepages_bytes",
                            "view.node_memory_shmempmdmapped_bytes as node_memory_shmempmdmapped_bytes",
                            "view.node_memory_slab_bytes as node_memory_slab_bytes",
                            "view.node_memory_sreclaimable_bytes as node_memory_sreclaimable_bytes",
                            "view.node_memory_sunreclaim_bytes as node_memory_sunreclaim_bytes",
                            "view.node_memory_swapcached_bytes as node_memory_swapcached_bytes",
                            "view.node_memory_swapfree_bytes as node_memory_swapfree_bytes",
                            "view.node_memory_swaptotal_bytes as node_memory_swaptotal_bytes",
                            "view.node_memory_unevictable_bytes as node_memory_unevictable_bytes",
                            "view.node_memory_vmallocchunk_bytes as node_memory_vmallocchunk_bytes",
                            "view.node_memory_vmalloctotal_bytes as node_memory_vmalloctotal_bytes",
                            "view.node_memory_vmallocused_bytes as node_memory_vmallocused_bytes",
                            "view.node_memory_writeback_bytes as node_memory_writeback_bytes",
                            "view.node_memory_writebacktmp_bytes as node_memory_writebacktmp_bytes",
                            "view.metrics_node_exporter_node_id_id as metrics_node_exporter_node_id_id"
                        ],
                        "filters": [
                        ],
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def node_exporter_device_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "node exporter device metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_node_exporter_device.timestamp) as timestamp",
                                    "metrics_node_exporter_device_id.device as metrics_node_exporter_device_id_device",
                                    "(metrics_node_exporter_device.node_arp_entries) as node_arp_entries",
                                    "(metrics_node_exporter_device.node_disk_io_now) as node_disk_io_now",
                                    "(metrics_node_exporter_device.node_disk_io_time_weighted_seconds_total) as \
                                        node_disk_io_time_weighted_seconds_total",
                                    "(metrics_node_exporter_device.node_disk_read_bytes_total) as node_disk_read_bytes_total",
                                    "(metrics_node_exporter_device.node_disk_read_time_seconds_total) as \
                                        node_disk_read_time_seconds_total",
                                    "(metrics_node_exporter_device.node_disk_reads_completed_total) as \
                                        node_disk_reads_completed_total",
                                    "(metrics_node_exporter_device.node_disk_reads_merged_total) as node_disk_reads_merged_total",
                                    "(metrics_node_exporter_device.node_disk_write_time_seconds_total) as \
                                        node_disk_write_time_seconds_total",
                                    "(metrics_node_exporter_device.node_disk_writes_completed_total) as \
                                        node_disk_writes_completed_total",
                                    "(metrics_node_exporter_device.node_disk_writes_merged_total) as \
                                        node_disk_writes_merged_total",
                                    "(metrics_node_exporter_device.node_disk_written_bytes_total) as \
                                        node_disk_written_bytes_total",
                                    "metrics_node_exporter_node_id.instance as metrics_node_exporter_node_id_instance",
                                    "metrics_node_exporter_node_id.id as metrics_node_exporter_node_id_id"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_node_exporter_device_id_device as metrics_node_exporter_device_id_device",
                            "view.node_arp_entries as node_arp_entries",
                            "view.node_disk_io_now as node_disk_io_now",
                            "view.node_disk_io_time_weighted_seconds_total as node_disk_io_time_weighted_seconds_total",
                            "view.node_disk_read_bytes_total as node_disk_read_bytes_total",
                            "view.node_disk_read_time_seconds_total as node_disk_read_time_seconds_total",
                            "view.node_disk_reads_completed_total as node_disk_reads_completed_total",
                            "view.node_disk_reads_merged_total as node_disk_reads_merged_total",
                            "view.node_disk_write_time_seconds_total as node_disk_write_time_seconds_total",
                            "view.node_disk_writes_completed_total as node_disk_writes_completed_total",
                            "view.node_disk_writes_merged_total as node_disk_writes_merged_total",
                            "view.node_disk_written_bytes_total as node_disk_written_bytes_total",
                            "view.metrics_node_exporter_node_id_instance as metrics_node_exporter_node_id_instance",
                            "view.metrics_node_exporter_node_id_id as metrics_node_exporter_node_id_id"
                        ],
                        "filters": [
                        ],
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def node_exporter_filesystem_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "node exporter filesystem metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_node_exporter_filesystem.timestamp) as timestamp",
                                    "metrics_node_exporter_filesystem_id.device as metrics_node_exporter_filesystem_id_device",
                                    "metrics_node_exporter_filesystem_id.fstype as metrics_node_exporter_filesystem_id_fstype",
                                    "metrics_node_exporter_filesystem_id.mountpoint as \
                                        metrics_node_exporter_filesystem_id_mountpoint",
                                    "(metrics_node_exporter_filesystem.node_filesystem_avail_bytes) as \
                                        node_filesystem_avail_bytes",
                                    "(metrics_node_exporter_filesystem.node_filesystem_device_error) as \
                                        node_filesystem_device_error",
                                    "(metrics_node_exporter_filesystem.node_filesystem_files) as node_filesystem_files",
                                    "(metrics_node_exporter_filesystem.node_filesystem_files_free) as node_filesystem_files_free",
                                    "(metrics_node_exporter_filesystem.node_filesystem_free_bytes) as node_filesystem_free_bytes",
                                    "(metrics_node_exporter_filesystem.node_filesystem_readonly) as node_filesystem_readonly",
                                    "(metrics_node_exporter_filesystem.node_filesystem_size_bytes) as node_filesystem_size_bytes",
                                    "metrics_node_exporter_node_id.instance as metrics_node_exporter_node_id_instance",
                                    "metrics_node_exporter_node_id.id as metrics_node_exporter_node_id_id"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_node_exporter_filesystem_id_device as metrics_node_exporter_filesystem_id_device",
                            "view.metrics_node_exporter_filesystem_id_fstype as metrics_node_exporter_filesystem_id_fstype",
                            "view.metrics_node_exporter_filesystem_id_mountpoint as \
                                metrics_node_exporter_filesystem_id_mountpoint",
                            "view.node_filesystem_avail_bytes as node_filesystem_avail_bytes",
                            "view.node_filesystem_device_error as node_filesystem_device_error",
                            "view.node_filesystem_files as node_filesystem_files",
                            "view.node_filesystem_files_free as node_filesystem_files_free",
                            "view.node_filesystem_free_bytes as node_filesystem_free_bytes",
                            "view.node_filesystem_readonly as node_filesystem_readonly",
                            "view.node_filesystem_size_bytes as node_filesystem_size_bytes",
                            "view.metrics_node_exporter_node_id_instance as metrics_node_exporter_node_id_instance",
                            "view.metrics_node_exporter_node_id_id as metrics_node_exporter_node_id_id"
                        ],
                        "filters": [
                        ],
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def node_exporter_network_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "node exporter network metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_node_exporter_network.timestamp) as timestamp",
                                    "metrics_node_exporter_device_id.device as metrics_node_exporter_device_id_device",
                                    "(metrics_node_exporter_network.node_network_receive_bytes_total) \
                                        as node_network_receive_bytes_total",
                                    "(metrics_node_exporter_network.node_network_receive_compressed_total) \
                                        as node_network_receive_compressed_total",
                                    "(metrics_node_exporter_network.node_network_receive_drop_total) as \
                                        node_network_receive_drop_total",
                                    "(metrics_node_exporter_network.node_network_receive_errs_total) as \
                                        node_network_receive_errs_total",
                                    "(metrics_node_exporter_network.node_network_receive_fifo_total) as \
                                        node_network_receive_fifo_total",
                                    "(metrics_node_exporter_network.node_network_receive_frame_total) as \
                                        node_network_receive_frame_total",
                                    "(metrics_node_exporter_network.node_network_receive_multicast_total) as \
                                        node_network_receive_multicast_total",
                                    "(metrics_node_exporter_network.node_network_receive_packets_total) as \
                                        node_network_receive_packets_total",
                                    "(metrics_node_exporter_network.node_network_transmit_bytes_total) as \
                                        node_network_transmit_bytes_total",
                                    "(metrics_node_exporter_network.node_network_transmit_carrier_total) as \
                                        node_network_transmit_carrier_total",
                                    "(metrics_node_exporter_network.node_network_transmit_colls_total) as \
                                        node_network_transmit_colls_total",
                                    "(metrics_node_exporter_network.node_network_transmit_compressed_total) as \
                                        node_network_transmit_compressed_total",
                                    "metrics_node_exporter_node_id.id as metrics_node_exporter_node_id_id",
                                    "metrics_node_exporter_node_id.instance as metrics_node_exporter_node_id_instance"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_node_exporter_device_id_device as metrics_node_exporter_device_id_device",
                            "view.node_network_receive_bytes_total as node_network_receive_bytes_total",
                            "view.node_network_receive_compressed_total as node_network_receive_compressed_total",
                            "view.node_network_receive_drop_total as node_network_receive_drop_total",
                            "view.node_network_receive_errs_total as node_network_receive_errs_total",
                            "view.node_network_receive_fifo_total as node_network_receive_fifo_total",
                            "view.node_network_receive_frame_total as node_network_receive_frame_total",
                            "view.node_network_receive_multicast_total as node_network_receive_multicast_total",
                            "view.node_network_receive_packets_total as node_network_receive_packets_total",
                            "view.node_network_transmit_bytes_total as node_network_transmit_bytes_total",
                            "view.node_network_transmit_carrier_total as node_network_transmit_carrier_total",
                            "view.node_network_transmit_colls_total as node_network_transmit_colls_total",
                            "view.node_network_transmit_compressed_total as node_network_transmit_compressed_total",
                            "view.metrics_node_exporter_node_id_id as metrics_node_exporter_node_id_id",
                            "view.metrics_node_exporter_node_id_instance as metrics_node_exporter_node_id_instance"
                        ],
                        "filters": [
                        ],
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def node_exporter_uname_metrics(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "node exporter uname metrics" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "(metrics_node_exporter_uname.timestamp) as timestamp",
                                    "metrics_node_exporter_node_id.instance as metrics_node_exporter_node_id_instance",
                                    "(metrics_node_exporter_uname.node_boot_time_seconds) as node_boot_time_seconds",
                                    "metrics_node_exporter_uname_id.nodename as metrics_node_exporter_uname_id_nodename",
                                    "metrics_node_exporter_uname_id.sysname as metrics_node_exporter_uname_id_sysname",
                                    "metrics_node_exporter_node_id.id as metrics_node_exporter_node_id_id"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.metrics_node_exporter_node_id_instance as metrics_node_exporter_node_id_instance",
                            "view.node_boot_time_seconds as node_boot_time_seconds",
                            "view.metrics_node_exporter_uname_id_nodename as metrics_node_exporter_uname_id_nodename",
                            "view.metrics_node_exporter_uname_id_sysname as metrics_node_exporter_uname_id_sysname",
                            "view.metrics_node_exporter_node_id_id as metrics_node_exporter_node_id_id"
                        ],
                        "filters": [
                        ],
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False
