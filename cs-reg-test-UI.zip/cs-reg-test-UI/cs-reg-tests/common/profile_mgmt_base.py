import json

import requests


def check_access_token_cs_url(access_token: str, cs_params: dict):
    """
    This method is used to check cloudsure url and access_token is not empty
    """
    cs_url = cs_params.get("cs_url", "")

    if not cs_url:
        raise ValueError("Cloudsure URL not found")
    if not access_token:
        raise ValueError("Access Token is missing")
    return access_token, cs_url


def create_profile(access_token: str, profile_data: dict, cs_params: dict):
    """
    This method is use to create the profile by providing profile data
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {"Content-Type": "application/json", 'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/profiles'
    response = requests.post(api_url, data=json.dumps(profile_data), headers=headers)
    return response


def get_profile_by_name(access_token: str, profile_name: str, cs_params: dict):
    """
    This method is use to get the details of profile by providing profile name
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/profiles'
    response = requests.get(api_url, headers=headers)

    profiles = response.json()['items']
    for profile in profiles:
        if profile['name'] == profile_name:
            return {"profile": profile, "status_code": response.status_code}
    else:
        return None


def get_profile_by_id(access_token: str, profile_id: str, cs_params: dict):
    """
    This method is use to get the details of profile by providing profile id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/profiles/{profile_id}'
    response = requests.get(api_url, headers=headers)
    return response


def update_profile(access_token: str, profile_id: str, profile_data_update: str, cs_params: dict):
    """
    This method is use to update the profile by providing profile id and data
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {"Content-Type": "application/json", 'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/profiles/{profile_id}'
    response = requests.put(api_url, data=json.dumps(profile_data_update), headers=headers)
    return response


def delete_profile_by_id(access_token: str, profile_id: str, cs_params: dict):
    """
    This method is use to delete the profile by providing profile id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/profiles/{profile_id}'
    response = requests.delete(api_url, headers=headers)
    return response
