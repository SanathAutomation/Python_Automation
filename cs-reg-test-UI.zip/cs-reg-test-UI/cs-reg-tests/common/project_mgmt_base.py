import requests


def check_access_token_cs_url(access_token: str, cs_params: dict):
    """
    This method is used to check cloudsure url and access_token is not empty
    """
    cs_url = cs_params.get("cs_url", "")

    if not cs_url:
        raise ValueError("Cloudsure URL not found")
    if not access_token:
        raise ValueError("Access Token is missing")
    return access_token, cs_url


def check_access_token(access_token: str, cs_params: dict):
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}
    api_url = f'{cs_url}/api/auth/token'
    response = requests.get(api_url, headers=headers)
    return response


def get_project_with_id(access_token: str, proj_id: str, cs_params: dict):
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)

    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/projects/{proj_id}'
    response = requests.get(api_url, headers=headers)
    return response


def get_project_id(cs_url: str, headers: dict, proj_name: str):
    proj_id = None
    url = f'{cs_url}/api/projects'
    resp = requests.get(url, headers=headers)
    projects = resp.json()['items']
    for project in projects:
        if project['name'] == proj_name:
            proj_id = project['id']
    return proj_id


def get_project_with_name(access_token: str, proj_name: str, cs_params: dict):
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)

    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    proj_id = get_project_id(cs_url, headers, proj_name)
    if proj_id:
        return True
    else:
        return False


def create_project(access_token: str, proj_name: str, cs_params: dict):
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    proj_data = {
        "name": proj_name,
        "description": "",
        "testcases": [
        ]
    }

    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}
    api_url = f'{cs_url}/api/projects'
    response = requests.post(api_url, data=proj_data, headers=headers)
    return response


def modify_project_name(access_token: str, proj_old_name: str, cs_params: dict, proj_new_name: str):
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)

    headers = {'Authorization': f'Bearer {access_token}'}
    proj_id = get_project_id(cs_url, headers, proj_old_name)

    proj_data = {
        "id": proj_id,
        "name": proj_new_name
    }
    api_url = f'{cs_url}/api/projects/{proj_id}'
    response = requests.put(api_url, data=proj_data, headers=headers)
    return response


def delete_project(access_token: str, proj_name: str, cs_params: dict):
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)

    headers = {'Authorization': f'Bearer {access_token}'}
    proj_id = get_project_id(cs_url, headers, proj_name)

    api_url = f'{cs_url}/api/projects/{proj_id}?delete_testcases=true'
    response = requests.delete(api_url, headers=headers)
    return response
