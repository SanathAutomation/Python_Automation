import os

import requests

from common import project_mgmt_base as pmb


def check_access_token_cs_url(access_token: str, cs_params: dict):
    """
    This method is used to check cloudsure url and access_token is not empty
    """
    cs_url = cs_params.get("cs_url", "")

    if not cs_url:
        raise ValueError("Cloudsure URL not found")
    if not access_token:
        raise ValueError("Access Token is missing")
    return access_token, cs_url


def import_testcase(access_token: str, project_name, testcase_name, cs_params: dict):
    """
    This method is use to import the testcase by providing project name and testcase name
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)

    headers = {'Authorization': f'Bearer {access_token}'}

    relative_path = "common/input/landslide_pod_delete.tar"
    file_path = os.path.join(os.getcwd(), relative_path)

    # Create your multipart/form-data payload
    files = {'file': ('landslide_pod_delete.tar', open(file_path, 'rb'))}

    project_id = pmb.get_project_id(cs_url, headers, project_name)
    if project_id:
        pmb.delete_project(access_token, project_name, cs_params)
    response = pmb.create_project(access_token, project_name, cs_params)
    project_id = response.json()['id']

    data = {"project_id": project_id,
            "project_name": project_name,
            "test_name": testcase_name}

    api_url = f'{cs_url}/api/testcases/x/import'
    response = requests.post(api_url, files=files, data=data, headers=headers)
    return response


def export_testcase(access_token: str, testcase_id: str, cs_params: dict):
    """
    This method is use to export the testcase by providing testcase id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/testcases/{testcase_id}/export'
    response = requests.post(api_url, headers=headers)
    return response
