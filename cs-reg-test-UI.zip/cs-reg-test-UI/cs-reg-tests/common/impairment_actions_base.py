import json

import pytest
import requests


def get_result(data):
    """
    This function is used to get the data of table through post request
    """
    if not pytest.cs_base_url:
        pytest.skip("skipping test, cloudsure url not found")
    base_url = pytest.cs_base_url
    headers = {"Content-Type": "application/json"}
    url = f"{base_url}/tciq/queries"

    resp = requests.post(url, headers=headers, data=json.dumps(data))
    assert resp.status_code == 200
    response = json.loads(resp.content)
    return response["result"]["rows"]


def compare_strings(str1, str2, operation):
    if operation == 'in':
        return str1 in str2
    elif operation == '==':
        return str1 == str2
    else:
        raise ValueError("Unsupported operation")


def pod_del_test_validate_time_to_recover(result_id, value_match, row=1, query=None):
    """
    In this function we will get the data for "Pod-Delete Workflow Results" table from Results
    Section and we will fetch the time to recover
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "single_result": {
                "filters": [],
                "groups": [],
                "orders": ["pd_delete_collection_results.timestamp ASC", "test.key ASC"],
                "projections": [
                    "pd_delete_collection_results.timestamp as timestamp",
                    "pd_delete_collection_results.first_deletion_time as first_deletion_time",
                    "pd_delete_collection_results.last_ready_time as last_ready_time",
                    "pd_delete_collection_results.time_to_recover_s as time_to_recover_s",
                    "test.key as iteration",
                ],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)
    if int(values[row-1][3]) >= value_match:
        return True
    else:
        return False


def pod_del_test_validate_pod_name(result_id, value_match, row=1, op="==", query=None):
    """
    In this function we will get the data for "Pod Delete Collection Impaired Input Objects"
    table from Results Section and we will validate pod-name
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "single_result": {
                "filters": [],
                "groups": [],
                "orders": ["pd_collection_impaired_in_obj.timestamp ASC", "pod_input_object.name ASC"],
                "projections": [
                    "pd_collection_impaired_in_obj.timestamp as timestamp",
                    "pod_input_object.name as pod_name",
                    "pod_input_object.node_name as node_name",
                    "pd_collection_impaired_in_obj.is_impaired as is_impaired",
                ],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)
    if (bool(values[row-1][3]) is True) and compare_strings(value_match, values[row - 1][1], op):
        return True
    else:
        return False


def cpu_hog_test_validate_cpu_resources(result_id, values_match, query=None):
    """
    In this function we will get the data for "CPU-HOG Workflow Results" table from Results
    and we will validate cpu resources
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "multi_result": {
                "filters": [],
                "groups": [],
                "orders": [
                    "view.snapshot_name ASC",
                    "view.timestamp ASC",
                    "view.node_name ASC",
                    "view.namespace ASC",
                    "view.pod_name ASC",
                    "view.name ASC",
                ],
                "projections": [
                    "view.node_name as node_name",
                    "view.namespace as namespace",
                    "view.pod_name as pod_name",
                    "view.name as name",
                    "view.cpu_actual_limit as cpu_actual_limit",
                    "view.cpu_target_limit as cpu_target_limit",
                    "view.snapshot_name as snapshot_name",
                    "view.timestamp as timestamp",
                ],
                "subqueries": [
                    {
                        "alias": "view",
                        "filters": [],
                        "groups": [],
                        "orders": [],
                        "projections": [
                            "container_input_object.node_name as node_name",
                            "container_input_object.namespace as namespace",
                            "container_input_object.pod_name as pod_name",
                            "container_input_object.name as name",
                            "container_cpu_resources.cpu_actual_limit as cpu_actual_limit",
                            "container_cpu_resources.cpu_target_limit as cpu_target_limit",
                            "test.snapshot_name as snapshot_name",
                            "container_cpu_resources.timestamp as timestamp",
                        ],
                    }
                ],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)
    actual_values = values[0][1:6]
    print(actual_values)
    is_ok = True
    if len(actual_values) != len(values_match):
        is_ok = False
    else:
        for actual, expected in zip(actual_values, values_match):
            actual = str(actual)
            expected = str(expected)
            if expected not in actual:
                is_ok = False
                break

    if is_ok:
        return True
    else:
        print(f"cpu resource {actual_values} does not match expected value {values_match}")
        return False


def container_kill_test_validate_workflow_results(result_id, values_match, time_to_recover, query=None):
    """
    In this function we will get the data for "Container-Kill Workflow Results" table from Results
    Section and we will fetch the time to recover
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "single_result": {
                "filters": [],
                "groups": [],
                "orders": [
                    "workflow_container_kill_summary.timestamp ASC",
                    "container_input_object.key ASC",
                    "container_input_object.node_name ASC",
                    "container_input_object.pod_name ASC",
                    "container_input_object.name ASC",
                ],
                "projections": [
                    "workflow_container_kill_summary.timestamp as timestamp",
                    "container_input_object.node_name as node_name",
                    "container_input_object.pod_name as pod_name",
                    "container_input_object.name as name",
                    "workflow_container_kill_summary.time_to_recover_s as time_to_recover_s",
                    "workflow_container_kill_summary.killed_at as killed_at",
                    "workflow_container_kill_summary.started_at as started_at",
                    "container_input_object.key as iteration",
                ],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)
    is_ok = True
    if int(values[0][4]) < time_to_recover:
        is_ok = False

    actual_values = values[0][2:4]

    if len(actual_values) != len(values_match):
        is_ok = False
    else:
        for actual, expected in zip(actual_values, values_match):
            actual = str(actual)
            expected = str(expected)
            if expected not in actual:
                is_ok = False
                break
    if is_ok:
        return True
    else:
        print(f"container kill {actual_values} does not match expected value {values_match, time_to_recover}")
        return False


def container_impaired_test_validate_container_name(result_id, values_match, query=None):
    """
    In this function we will get the data for "Container Impaired Input Objects"
    table from Results Section and we will validate all the results of container impaired input
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "multi_result": {
                "filters": [],
                "groups": [],
                "orders": [
                    "view.snapshot_name ASC",
                    "view.timestamp ASC",
                    "view.node_name ASC",
                    "view.namespace ASC",
                    "view.pod_name ASC",
                    "view.name ASC",
                ],
                "projections": [
                    "view.node_name as node_name",
                    "view.namespace as namespace",
                    "view.pod_name as pod_name",
                    "view.name as name",
                    "view.is_impaired as is_impaired",
                    "view.snapshot_name as snapshot_name",
                    "view.timestamp as timestamp",
                ],
                "subqueries": [
                    {
                        "alias": "view",
                        "filters": [],
                        "groups": [],
                        "orders": [],
                        "projections": [
                            "container_input_object.node_name as node_name",
                            "container_input_object.namespace as namespace",
                            "container_input_object.pod_name as pod_name",
                            "container_input_object.name as name",
                            "container_impaired_input_objects.is_impaired as is_impaired",
                            "test.snapshot_name as snapshot_name",
                            "container_impaired_input_objects.timestamp as timestamp",
                        ],
                    }
                ],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)
    actual_values = values[0][1:5]
    is_ok = True
    if len(actual_values) != len(values_match):
        is_ok = False
    else:
        for actual, expected in zip(actual_values, values_match):
            actual = str(actual)
            expected = str(expected)
            if expected not in actual:
                is_ok = False
                break

    if is_ok:
        return True
    else:
        print(f"container impaired {actual_values} does not match expected value {values_match}")
        return False


def mem_hog_test_validate_mem_resources(result_id, values_match, query=None):
    """
    In this function we will get the data for "MEMORY-HOG Workflow Results" table from Results
    and we will validate memory resources
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "multi_result": {
                "filters": [],
                "groups": [],
                "orders": [
                    "view.snapshot_name ASC",
                    "view.timestamp ASC",
                    "view.node_name ASC",
                    "view.namespace ASC",
                    "view.pod_name ASC",
                    "view.name ASC",
                ],
                "projections": [
                    "view.node_name as node_name",
                    "view.namespace as namespace",
                    "view.pod_name as pod_name",
                    "view.name as name",
                    "view.memory_actual_limit as memory_actual_limit",
                    "view.memory_target_limit as memory_target_limit",
                    "view.snapshot_name as snapshot_name",
                    "view.timestamp as timestamp",
                ],
                "subqueries": [
                    {
                        "alias": "view",
                        "filters": [],
                        "groups": [],
                        "orders": [],
                        "projections": [
                            "container_input_object.node_name as node_name",
                            "container_input_object.namespace as namespace",
                            "container_input_object.pod_name as pod_name",
                            "container_input_object.name as name",
                            "container_memory_resources.memory_actual_limit as memory_actual_limit",
                            "container_memory_resources.memory_target_limit as memory_target_limit",
                            "test.snapshot_name as snapshot_name",
                            "container_memory_resources.timestamp as timestamp"
                        ],
                    }
                ],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)
    actual_values = values[0][1:6]
    is_ok = True
    if len(actual_values) != len(values_match):
        is_ok = False
    else:
        for actual, expected in zip(actual_values, values_match):
            actual = str(actual)
            expected = str(expected)
            if expected not in actual:
                is_ok = False
                break

    if is_ok:
        return True
    else:
        print(f"memory resource {actual_values} does not match expected value {values_match}")
        return False


def container_storage_resources_table_validate_storage(result_id, values_match, target_storage_limit, query=None):
    """
    In this function we will get the data for "Container Storage Resources" table from Results
    and we will validate storage resources
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {

            "multi_result": {
                "filters": [],
                "groups": [],
                "orders": [

                    "view.snapshot_name ASC",
                    "view.timestamp ASC",
                    "view.node_name ASC",
                    "view.pod_name ASC",
                    "view.name ASC"
                ],
                "projections": [
                    "view.node_name as node_name",
                    "view.pod_name as pod_name",
                    "view.name as name",
                    "view.storage_actual_limit as storage_actual_limit",
                    "view.storage_target_limit as storage_target_limit",
                    "view.snapshot_name as snapshot_name",
                    "view.timestamp as timestamp"
                ],
                "subqueries": [
                    {
                        "alias": "view",
                        "filters": [],
                        "groups": [],
                        "orders": [],
                        "projections": [
                            "container_input_object.node_name as node_name",
                            "container_input_object.pod_name as pod_name",
                            "container_input_object.name as name",
                            "container_storage_resources.storage_actual_limit as storage_actual_limit",
                            "container_storage_resources.storage_target_limit as storage_target_limit",
                            "test.snapshot_name as snapshot_name",
                            "container_storage_resources.timestamp as timestamp"
                        ]
                    }
                ]
            }
        },
    }
    if query:
        data = query
    values = get_result(data)
    actual_values = values[0][1:3]
    is_ok = True
    if int(values[0][4]) != target_storage_limit:
        is_ok = False

    if len(actual_values) != len(values_match):
        is_ok = False
    else:
        for actual, expected in zip(actual_values, values_match):
            actual = str(actual)
            expected = str(expected)
            if expected not in actual:
                is_ok = False
                break

    if is_ok:
        return True
    else:

        print(f"storage resource {actual_values} does not match expected value {values_match}")
        return False


def workflow_execution_table_validate_action_state(result_id, values_match, row: int = 3, column_start: int = 4, query=None):
    """
    In this function we will get the data for "Workflow Execution" table from Results
    and we will validate action state
    row and column start from 1, not 0, the 1st row is not the column titles
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "multi_result": {
                "filters": [],
                "groups": [],
                "orders": [
                    "view.timestamp ASC",
                    "view.order ASC",
                    "view.wf_index ASC",
                    "view.exec_tag ASC",
                    "view.state ASC",
                    "view.message ASC"
                ],
                "projections": [
                    "view.timestamp as timestamp",
                    "view.name as name",
                    "view.description as description",
                    "view.action_urn as action_urn",
                    "view.state as state",
                    "view.message as message",
                    "view.run_when as run_when",
                    "view.wf_index as wf_index",
                    "view.wf_run_index as wf_run_index",
                    "view.wf_parent_index as wf_parent_index",
                    "view.exec_tag as exec_tag",
                    "view.order as order"
                ],
                "subqueries": [
                    {
                        "alias": "view",
                        "filters": [],
                        "groups": [],
                        "orders": [],
                        "projections": [
                            "res_workflow_action.timestamp as timestamp",
                            "workflow_action.name as name",
                            "workflow_action.description as description",
                            "workflow_action.action_urn as action_urn",
                            "res_workflow_action.state as state",
                            "res_workflow_action.message as message",
                            "workflow_action.run_when as run_when",
                            "workflow_action.wf_index as wf_index",
                            "workflow_action.wf_run_index as wf_run_index",
                            "workflow_action.wf_parent_index as wf_parent_index",
                            "workflow_action.exec_tag as exec_tag",
                            "res_workflow_action.order as order"
                        ]
                    }
                ]
            }
        },
    }
    if query:
        data = query
    values = get_result(data)
    actual_values = values[row-1][column_start-1:column_start+len(values_match)-1]
    is_ok = True

    if len(actual_values) != len(values_match):
        is_ok = False
    else:
        for actual, expected in zip(actual_values, values_match):
            actual = str(actual)
            expected = str(expected)
            if expected not in actual:
                is_ok = False
                break

    if is_ok:
        return True
    else:
        print(f"workflow action state {actual_values} does not match expected value {values_match}")
        return False


def node_test_validate_node_impaired_input_objects(result_id, values_match, query=None):
    """
    In this function we will get the data for "Node Impaired Input Objects" table from Results
    and we will validate impaired node information
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition":
        {
            "multi_result": {
                "filters": [],
                "groups": [],
                "orders": [
                    "view.name ASC",
                    "view.timestamp ASC"
                ],
                "projections": [
                    "view.name as name",
                    "view.is_impaired as is_impaired",
                    "view.timestamp as timestamp"
                ],
                "subqueries": [
                    {
                        "alias": "view",
                        "filters": [],
                        "groups": [],
                        "orders": [],
                        "projections": [
                            "node_input_object.name as name",
                            "node_impaired_input_objects.is_impaired as is_impaired",
                            "node_impaired_input_objects.timestamp as timestamp"
                        ]
                    }
                ]
            }
        },
    }

    if query:
        data = query
    values = get_result(data)
    actual_values = values[0][0:2]
    is_ok = True
    if len(actual_values) != len(values_match):
        is_ok = False
    else:
        for actual, expected in zip(actual_values, values_match):
            actual = str(actual)
            expected = str(expected)
            if expected not in actual:
                is_ok = False
                break

    if is_ok:
        return True
    else:
        print(f"impaired node info {actual_values} does not match expected value {values_match}")
        return False


def node_test_validate_node_reboot_recovery(result_id, values_match, query=None):
    """
    In this function we will get the data for "Node Reboot Recovery Results" table from Results
    and we will validate node reboot recovery information
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition":
        {
            "multi_result": {
                "filters": [],
                "groups": [],
                "orders": [
                    "view.timestamp ASC",
                    "view.name ASC"
                ],
                "projections": [
                    "view.name as name",
                    "view.timestamp as timestamp",
                    "view.last_reboot_time as last_reboot_time",
                    "view.last_ready_time as last_ready_time",
                    "view.time_to_recover_s as time_to_recover_s"
                ],
                "subqueries": [
                    {
                        "alias": "view",
                        "filters": [],
                        "groups": [],
                        "orders": [],
                        "projections": [
                            "node_input_object.name as name",
                            "node_reboot_recovery_results.timestamp as timestamp",
                            "node_reboot_recovery_results.last_reboot_time as last_reboot_time",
                            "node_reboot_recovery_results.last_ready_time as last_ready_time",
                            "node_reboot_recovery_results.time_to_recover_s as time_to_recover_s"
                        ]
                    }
                ]
            }
        },
    }

    if query:
        data = query
    values = get_result(data)
    actual_values = values[0][0:5]
    print("Results: [Node Name, Timestamp, Last Reboot Time, Last Ready Time,Time to Recover(sec)]")
    print(actual_values)
    is_ok = True

    if actual_values[0] != values_match[0]:
        is_ok = False
        print(f"FAIL! Node name from result: {actual_values[0]} does not match expected value: {values_match[0]}")
    if actual_values[2] > actual_values[3]:
        is_ok = False
        print(f"FAIL! Last Reboot Time: {actual_values[2]} is later than Last Ready Time: {actual_values[3]}")
    if actual_values[4] > values_match[1]:
        is_ok = False
        print(f"FAIL! Time to Recover(sec): {actual_values[4]} is bigger than user configured timeout: "
              f"{values_match[1]}")

    if is_ok:
        return True
    else:
        print("Node Reboot recovery info verification failed")
        return False
