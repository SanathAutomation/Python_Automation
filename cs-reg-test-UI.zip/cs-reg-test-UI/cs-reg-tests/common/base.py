import base64
import json
import os
import os.path

import pytest
import requests


def encode_file_with_base64(file_path):
    with open(file_path, 'rb') as file:
        encoded_content = base64.b64encode(file.read())
    return encoded_content


def get_result(data):
    """
    This function is used to get the data of table through post request
    """
    if not pytest.cs_base_url:
        pytest.skip("skipping test, cloudsure url not found")
    base_url = pytest.cs_base_url
    headers = {"Content-Type": "application/json"}
    url = f"{base_url}/tciq/queries"

    resp = requests.post(url, headers=headers, data=json.dumps(data))
    assert resp.status_code == 200
    response = json.loads(resp.content)
    return response["result"]["rows"]


def landslide_test_measurement_count(result_id, value_match, query=None):
    """
    In this function we will get the data for "Landslide Test Measurements" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [],
                        "projections": [
                            "test_measurements.tab as tab",
                            "test_measurements.measurement as measurement",
                            "test_measurements.value as value",
                            "test_measurements.is_favorite as is_favorite",
                        ],
                    }
                ],
                "projections": ["count(source_subquery.tab) as total"],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(values)
        return False


def landslide_test_reports_count(result_id, value_match, query=None):
    """
    In this function we will get the data for "Landslide Test Reports" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [],
                                "projections": [
                                    "landslide_measurement.group as group",
                                    "landslide_measurement.name as name",
                                    "landslide_test_case.index as tc_index",
                                    "landslide_test_server.name as server_name",
                                    "landslide_report.is_summary as is_summary",
                                    "landslide_report.iteration as iteration",
                                    "landslide_report.interval as interval",
                                    "landslide_report.elapsed_time as elapsed_time",
                                    "landslide_report.value as value",
                                ],
                            }
                        ],
                        "projections": [
                            "view.group as group",
                            "view.name as name",
                            "view.tc_index as tc_index",
                            "view.server_name as server_name",
                            "view.is_summary as is_summary",
                            "view.iteration as iteration",
                            "view.interval as interval",
                            "view.elapsed_time as elapsed_time",
                            "view.value as value",
                        ],
                    }
                ],
                "projections": ["count(source_subquery.group) as total"],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) >= value_match:
        return True
    else:
        print(f"measurement: landslide report value count {int(values[0][0])} less than expected {value_match}")
        return False


def landslide_test_measurement(result_id, dict_check, value_match, range_match, query=None):
    """
    In this function we will get the data for "Landslide Test Measurements" table from Results Section
    and we will check the data based on some condition.
    """
    list_filter = []

    if dict_check:
        for key, value in dict_check.items():
            list_filter.append(f"test_measurements.{key} = {value}")

    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "single_result": {
                "projections": [
                    "test_measurements.tab as tab",
                    "test_measurements.measurement as measurement",
                    "test_measurements.is_favorite as is_favorite",
                    "test_measurements.value as value",
                ],
                "orders": ["test_measurements.tab ASC", "test_measurements.measurement ASC"],
                "filters": list_filter,
            }
        },
    }

    if query:
        data = query
    values = get_result(data)

    min_value = value_match - range_match
    max_value = value_match + range_match
    if min_value <= int(values[0][-1]) <= max_value:
        return True
    else:
        print(f"measurement:{dict_check}, value={int(values[0][-1])},  out of range min={min_value}, max={max_value}")
        return False


def landslide_test_report(result_id, dict_check, value_match, range_match, query=None):
    """
    In this function we will get the data for "Landslide Test Reports" table from Results Section
    and we will check the data based on some condition.
    """
    list_filter = []

    if dict_check:
        for key, value in dict_check.items():
            list_filter.append(f"view.{key} = {value}")

    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "view",
                        "subqueries": [],
                        "projections": [
                            "landslide_measurement.group as group",
                            "landslide_measurement.name as name",
                            "landslide_test_case.index as tc_index",
                            "landslide_test_server.name as server_name",
                            "landslide_report.is_summary as is_summary",
                            "landslide_report.iteration as iteration",
                            "landslide_report.interval as interval",
                            "landslide_report.elapsed_time as elapsed_time",
                            "landslide_report.value as value",
                        ],
                    }
                ],
                "projections": [
                    "view.group as group",
                    "view.name as name",
                    "view.tc_index as tc_index",
                    "view.server_name as server_name",
                    "view.is_summary as is_summary",
                    "view.iteration as iteration",
                    "view.interval as interval",
                    "view.elapsed_time as elapsed_time",
                    "view.value as value",
                ],
                "orders": [
                    "view.group ASC",
                    "view.name ASC",
                    "view.tc_index ASC",
                    "view.server_name ASC",
                    "view.iteration ASC",
                    "view.interval ASC",
                    "view.is_summary ASC",
                ],
                "filters": list_filter,
            }
        },
    }

    if query:
        data = query
    values = get_result(data)

    if (value_match - range_match) <= int(values[0][-1]) <= (value_match + range_match):
        return True
    else:
        print(values)
        return False


def check_landslide_result(full_name, result_id, min_value, max_value, op="max"):
    """
    Check landslide_result stats
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "single_result": {
                "projections": [
                    f"{op}(landslide_result.value) as value",
                ],
                "filters": [full_name, "landslide_result.is_summary"],
            },
        },
    }
    values = get_result(data)
    if min_value <= int(values[0][0]) <= max_value:
        return True
    else:
        print(f"session {full_name} count out of range value={int(values[0][0])},  out of range min={min_value}, max={max_value}")
        return False


def landslide_test_Session_chart_count(full_name, result_id, value_match, range_match=20, query=None):
    """
    In this function we will get the data for "Landslide Test Session chart" table from Results Section
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "leaf",
                        "subqueries": [],
                        "projections": [
                            "avg(landslide_result.value) as value",
                            "interval(landslide_result.timestamp, 'PT1S') as interval",
                        ],
                        "filters": [full_name, "landslide_result.is_summary"],
                        "groups": ["interval(landslide_result.timestamp, 'PT1S')", "landslide_result.value"],
                        "orders": [],
                        "timestamp_range": {"absolute": {}},
                    }
                ],
                "projections": ["count(leaf.value) as total"],
                "filters": [],
                "groups": [],
                "orders": [],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)
    if (value_match - range_match) <= int(values[0][0]) <= (value_match + range_match):
        return True
    else:
        print(values)
        return False


def landslide_test_Session_chart_range_count(full_name, result_id, value_match, range_match, filter_value, op=">", query=None):
    """
    In this function we will get the data for "Landslide Test Session chart" table from Results Section
    and fetch the data based on some condition
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "leaf",
                        "subqueries": [],
                        "projections": [
                            "avg(landslide_result.value) as value",
                            "interval(landslide_result.timestamp, 'PT1S') as interval",
                        ],
                        "filters": [full_name, "landslide_result.is_summary"],
                        "groups": ["interval(landslide_result.timestamp, 'PT1S')", "landslide_result.value"],
                        "orders": [],
                        "timestamp_range": {"absolute": {}},
                    }
                ],
                "projections": ["count(leaf.value) as total"],
                "filters": [f"leaf.value {op} {filter_value}"],
                "groups": [],
                "orders": [],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)

    min_value = value_match - range_match
    max_value = value_match + range_match
    if min_value <= int(values[0][0]) <= max_value:
        return True
    else:
        print(f"session {full_name} count out of range value={int(values[0][0])},  out of range min={min_value}, max={max_value}")
        return False


def landslide_L3_Client_Server_chart_count(full_name, result_id, value_match, range_match=10, query=None):
    """
    In this function we will get the data for "Landslide L3 client/server chart" table from Results Section
    and filter data for no. of rows.
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "leaf",
                        "subqueries": [],
                        "projections": [
                            "avg(landslide_result.value) as value",
                            "interval(landslide_result.timestamp, 'PT1S') as interval",
                        ],
                        "filters": [full_name, "landslide_result.is_summary"],
                        "groups": ["interval(landslide_result.timestamp, 'PT1S')", "landslide_result.value"],
                        "orders": [],
                        "timestamp_range": {"absolute": {}},
                    }
                ],
                "projections": ["count(leaf.value) as total"],
                "filters": [],
                "groups": [],
                "orders": [],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)

    if (value_match - range_match) <= int(values[0][0]) <= (value_match + range_match):
        return True
    else:
        print(values)
        return False


def landslide_L3_Client_Server_chart_range_count(full_name, result_id, value_match, range_match, filter_value, op=">",
                                                 query=None):
    """
    In this function we will get the data for "Landslide L3 client/server chart" table from Results Section
    and filter data based on some condition.
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "leaf",
                        "subqueries": [],
                        "projections": [
                            "avg(landslide_result.value) as value",
                            "interval(landslide_result.timestamp, 'PT1S') as interval",
                        ],
                        "filters": [full_name, "landslide_result.is_summary"],
                        "groups": ["interval(landslide_result.timestamp, 'PT1S')", "landslide_result.value"],
                        "orders": [],
                        "timestamp_range": {"absolute": {}},
                    }
                ],
                "projections": ["count(leaf.value) as total"],
                "filters": [f"leaf.value {op} {filter_value}"],
                "groups": [],
                "orders": [],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)

    if (value_match - range_match) <= int(values[0][0]) <= (value_match + range_match):
        return True
    else:
        print(values)
        return False


def get_table_details(result_id):
    """
    In this function we will make get request to get details of table from tciq/database
    """
    if not pytest.cs_base_url:
        pytest.skip("skipping test, cloudsure url not found")
    base_url = pytest.cs_base_url
    url = f"{base_url}/tciq/databases/{result_id}"

    resp = requests.get(url)
    assert resp.status_code == 200
    response = json.loads(resp.content)
    return response["result_sets"]


def landslide_tables_details(result_id, table_name):
    """
    In this function we will get details of tables from result sets
    """
    result_sets = get_table_details(result_id)
    for result in result_sets:
        if result["name"] == table_name:
            column_list = []
            for column in result["facts"]:
                column_list.append(column["name"])
            return column_list


def get_column_position(data, column_name):
    """
    This function is used to get the index of column through post request
    """
    if not pytest.cs_base_url:
        pytest.skip("skipping test, cloudsure url not found")
    base_url = pytest.cs_base_url
    headers = {"Content-Type": "application/json"}
    url = f"{base_url}/tciq/queries"

    column__index_list = []
    resp = requests.post(url, headers=headers, data=json.dumps(data))
    assert resp.status_code == 200
    response = json.loads(resp.content)["result"]["columns"]
    for column in column_name:
        if column in response:
            column__index_list.append(response.index(column))
        else:
            raise ValueError("column name is not in table")
    return column__index_list


def landslide_test_measurement_column_null_check(result_id, column_name, query=None):
    """
    In this function we will give column name as input and will check that column
    contains null value or not
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "single_result": {
                "projections": [
                    "test_measurements.tab as tab",
                    "test_measurements.measurement as measurement",
                    "test_measurements.value as value",
                    "test_measurements.is_favorite as is_favorite",
                ],
                "orders": ["test_measurements.tab ASC", "test_measurements.measurement ASC"],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)

    try:
        column_position = get_column_position(data, column_name)
    except ValueError:
        exit("Test failed due to table name not found")
    for rows in values:
        for column in column_position:
            if rows[column] is None:
                print(f"column index {column} in {rows} contain null values")
                return False
    return True


def landslide_test_report_column_null_check(result_id, column_name, query=None):
    """
    In this function we will give column name as input and will check that column
    contains null value or not
    """
    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "view",
                        "subqueries": [],
                        "projections": [
                            "landslide_measurement.group as group",
                            "landslide_measurement.name as name",
                            "landslide_test_case.index as tc_index",
                            "landslide_test_server.name as server_name",
                            "landslide_report.is_summary as is_summary",
                            "landslide_report.iteration as iteration",
                            "landslide_report.interval as interval",
                            "landslide_report.elapsed_time as elapsed_time",
                            "landslide_report.value as value",
                        ],
                    }
                ],
                "projections": [
                    "view.group as group",
                    "view.name as name",
                    "view.tc_index as tc_index",
                    "view.server_name as server_name",
                    "view.is_summary as is_summary",
                    "view.iteration as iteration",
                    "view.interval as interval",
                    "view.elapsed_time as elapsed_time",
                    "view.value as value",
                ],
                "orders": [
                    "view.group ASC",
                    "view.name ASC",
                    "view.tc_index ASC",
                    "view.server_name ASC",
                    "view.iteration ASC",
                    "view.interval ASC",
                    "view.is_summary ASC",
                ],
            }
        },
    }

    if query:
        data = query
    values = get_result(data)
    try:
        column_position = get_column_position(data, column_name)
    except ValueError:
        exit("Test failed due to table name not found")
    for rows in values:
        for column in column_position:
            if rows[column] is None:
                print(f"column index {column} in {rows} contain null values")
                return False
    return True


def landslide_test_measurement_table_symmetric_diff(result_id, record, query=None):
    """
    In this function we will get the complete table list and then check the symmetric difference
    with already having list.
    """

    # Assuming the file is in the same directory as your script or notebook
    relative_path = "common/input/landslide_test_measurement.json"

    # Get the absolute path by joining the current working directory with the relative path
    file_path = os.path.join(os.getcwd(), relative_path)

    # Open the JSON file
    with open(file_path, "r") as f:
        # Load the JSON data
        fetched_data = json.load(f)

    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "single_result": {
                "projections": [
                    "test_measurements.tab as tab",
                    "test_measurements.measurement as measurement",
                    "test_measurements.value as value",
                    "test_measurements.is_favorite as is_favorite",
                ],
                "orders": ["test_measurements.tab ASC", "test_measurements.measurement ASC"],
                "limit": record,
            }
        },
    }

    if query:
        data = query
    values = get_result(data)

    result_set = set(map(tuple, values))
    set_check = set(map(tuple, fetched_data["result"]["rows"]))
    if result_set.symmetric_difference(set_check):
        return False
    else:
        return True


def landslide_test_report_table_symmetric_diff(result_id, record, query=None):
    """
    In this function we will get the complete table list and then check the symmetric difference
    with already having list.
    """

    # Assuming the file is in the same directory as your script or notebook
    relative_path = "common/input/landslide_test_report.json"

    # Get the absolute path by joining the current working directory with the relative path
    file_path = os.path.join(os.getcwd(), relative_path)

    # Open the JSON file
    with open(file_path, "r") as f:
        # Load the JSON data
        fetched_data = json.load(f)

    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "view",
                        "subqueries": [],
                        "projections": [
                            "landslide_measurement.group as group",
                            "landslide_measurement.name as name",
                            "landslide_test_case.index as tc_index",
                            "landslide_test_server.name as server_name",
                            "landslide_report.is_summary as is_summary",
                            "landslide_report.iteration as iteration",
                            "landslide_report.interval as interval",
                            "landslide_report.elapsed_time as elapsed_time",
                            "landslide_report.value as value",
                        ],
                    }
                ],
                "projections": [
                    "view.group as group",
                    "view.name as name",
                    "view.tc_index as tc_index",
                    "view.server_name as server_name",
                    "view.is_summary as is_summary",
                    "view.iteration as iteration",
                    "view.interval as interval",
                    "view.elapsed_time as elapsed_time",
                    "view.value as value",
                ],
                "orders": [
                    "view.group ASC",
                    "view.name ASC",
                    "view.tc_index ASC",
                    "view.server_name ASC",
                    "view.iteration ASC",
                    "view.interval ASC",
                    "view.is_summary ASC",
                ],
                "limit": record,
            }
        },
    }

    if query:
        data = query
    values = get_result(data)

    result_set = set(map(tuple, values))
    set_check = set(map(tuple, fetched_data["result"]["rows"]))
    if result_set.symmetric_difference(set_check):
        return False
    else:
        return True


def landslide_states_table_symmetric_diff(result_id, record, query=None):
    """
    In this function we will get the complete table list and then check the symmetric difference
    with already having list.
    """

    # Assuming the file is in the same directory as your script or notebook
    relative_path = "common/input/landslide_states.json"

    # Get the absolute path by joining the current working directory with the relative path
    file_path = os.path.join(os.getcwd(), relative_path)

    # Open the JSON file
    with open(file_path, "r") as f:
        # Load the JSON data
        fetched_data = json.load(f)

    data = {
        "id": "",
        "database": {"id": result_id, "name": ""},
        "datastore": {"id": ""},
        "mode": "once",
        "definition": {
            "single_result": {
                "projections": [
                    "landslide_state.name as name",
                    "landslide_state.state as state",
                    "landslide_state.iteration as iteration",
                ],
                "filters": [],
                "groups": [],
                "orders": ["landslide_state.iteration ASC", "landslide_state.name ASC", "landslide_state.state ASC"],
                "limit": record,
            }
        },
    }

    if query:
        data = query
    values = get_result(data)

    result_set = set(map(tuple, values))
    set_check = set(map(tuple, fetched_data["result"]["rows"]))
    if result_set.symmetric_difference(set_check):
        return False
    else:
        return True


def analysis_baseline_comparison_summary_result(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "Baseline comparison summary result" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "base_comp_data_summary.kpi_type as kpi_type",
                                    "base_comp_data_summary.kpi_disp as kpi_disp",
                                    "base_comp_data_summary.alert as alert",
                                    "base_comp_data_summary.improve as improve",
                                    "base_comp_data_summary.acceptable as acceptable",
                                    "base_comp_data_summary.alert + base_comp_data_summary.improve + \
                                    base_comp_data_summary.acceptable as total",
                                    "base_comp_data_summary.timestamp as timestamp",
                                    "base_comp_data_summary.kpi as kpi"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.kpi_type as kpi_type",
                            "view.kpi_disp as kpi_disp",
                            "view.alert as alert",
                            "view.improve as improve",
                            "view.acceptable as acceptable",
                            "view.total as total",
                            "view.timestamp as timestamp",
                            "view.kpi as kpi"
                        ],
                        "filters": filter,
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.kpi_type) as total"
                ],
                "filters": [

                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) == value_match:
        return True
    else:
        print(values)
        return False


def analysis_baseline_comparison_test_result_sets(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "Baseline comparison test result sets" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "base_comp_test_result_sets.timestamp as timestamp",
                                    "base_comp_test_result_sets.name as name",
                                    "base_comp_test_result_sets.template_id as template_id",
                                    "base_comp_test_result_sets.db_id as db_id",
                                    "base_comp_test_result_sets.role as role"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.timestamp as timestamp",
                            "view.name as name",
                            "view.template_id as template_id",
                            "view.db_id as db_id",
                            "view.role as role"
                        ],
                        "filters": filter,
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.timestamp) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) == value_match:
        return True
    else:
        print(values)
        return False


def analysis_baseline_comparison_detailed_results(result_id, value_match, filter, query=None):
    """
    In this function we will get the data for "Baseline comparison detailed result" table from Results Section
    and we will fetch the number of rows
    """
    data = {
        "id": "",
        "database": {
            "id": result_id,
            "name": ""
        },
        "datastore": {
            "id": ""
        },
        "mode": "once",
        "definition": {
            "multi_result": {
                "subqueries": [
                    {
                        "alias": "source_subquery",
                        "subqueries": [
                            {
                                "alias": "view",
                                "subqueries": [
                                ],
                                "projections": [
                                    "base_comp_data.kpi_tab_name as kpi_tab_name",
                                    "base_comp_data.kpi_name as kpi_name",
                                    "base_comp_data.prof_name as prof_name",
                                    "base_comp_data.kpi_type as kpi_type",
                                    "base_comp_data.base as base",
                                    "base_comp_data.comp as comp",
                                    "base_comp_data.diff as diff",
                                    "base_comp_data.pct_diff as pct_diff",
                                    "base_comp_data.comp_res as comp_res",
                                    "base_comp_data.agg_method as agg_method",
                                    "base_comp_data.improvement_direction as improvement_direction",
                                    "base_comp_data.units as units",
                                    "base_comp_data.pod_filter as pod_filter",
                                    "base_comp_data.cont_filter as cont_filter",
                                    "base_comp_data.node_filter as node_filter",
                                    "base_comp_data.kpi_disp_name as kpi_disp_name",
                                    "base_comp_data.kpi_key as kpi_key"
                                ],
                                "filters": [
                                ],
                                "groups": [
                                ],
                                "orders": [
                                ]
                            }
                        ],
                        "projections": [
                            "view.kpi_tab_name as kpi_tab_name",
                            "view.kpi_name as kpi_name",
                            "view.prof_name as prof_name",
                            "view.kpi_type as kpi_type",
                            "view.base as base",
                            "view.comp as comp",
                            "view.diff as diff",
                            "view.pct_diff as pct_diff",
                            "view.comp_res as comp_res",
                            "view.agg_method as agg_method",
                            "view.improvement_direction as improvement_direction",
                            "view.units as units",
                            "view.pod_filter as pod_filter",
                            "view.cont_filter as cont_filter",
                            "view.node_filter as node_filter",
                            "view.kpi_disp_name as kpi_disp_name",
                            "view.kpi_key as kpi_key"
                        ],
                        "filters": filter,
                        "groups": [
                        ],
                        "orders": [
                        ]
                    }
                ],
                "projections": [
                    "count(source_subquery.kpi_tab_name) as total"
                ],
                "filters": [
                ],
                "groups": [
                ],
                "orders": [
                ]
            }
        }
    }

    if query:
        data = query
    values = get_result(data)

    if int(values[0][0]) == value_match:
        return True
    else:
        print(values)
        return False
