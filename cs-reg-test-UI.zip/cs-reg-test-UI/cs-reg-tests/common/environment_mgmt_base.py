import json

import requests


def check_access_token_cs_url(access_token: str, cs_params: dict):
    """
    This method is used to check cloudsure url and access_token is not empty
    """
    cs_url = cs_params.get("cs_url", "")

    if not cs_url:
        raise ValueError("Cloudsure URL not found")
    if not access_token:
        raise ValueError("Access Token is missing")
    return access_token, cs_url


def create_environment_credentials(
    access_token: str, credential_name: str, category_name: str, content: str, content_filename: str, cs_params: dict
):
    """
    This method is use to create the credential id by providing config file details
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    data = {
        "id": "",
        "name": credential_name,
        "category": category_name,
        "content": content,
        "content_filename": content_filename,
        "created_timestamp": "2023-12-19T10:47:16.824Z",
        "modified_timestamp": "2023-12-19T10:47:16.824Z",
    }

    api_url = f'{cs_url}/api/v1/credentials'
    response = requests.post(api_url, data=json.dumps(data), headers=headers)
    return response


def create_environment_profile(
    access_token: str, credential_name: str, profile_name: str, profile_template_id: str, credential_id: str, cs_params: dict
):
    """
    This method is use to create the profile by providing credential id and name
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {"Content-Type": "application/json", 'Authorization': f'Bearer {access_token}'}

    env_data = {
        "id": "",
        "name": profile_name,
        "version": "1.0.0",
        "input": {
            "cluster_id": "",
            "credential_id": credential_id,
            "description": "",
            "name": credential_name
        },
        "profile_template_id": profile_template_id
    }

    api_url = f'{cs_url}/api/profiles'
    response = requests.post(api_url, data=json.dumps(env_data), headers=headers)
    return response


def get_credential_by_name(access_token: str, credential_name: str, cs_params: dict):
    """
    This method is use to get the details of credentials by providing credential name
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/v1/credentials'
    response = requests.get(api_url, headers=headers)

    credentials = response.json()
    for credential in credentials:
        if credential['name'] == credential_name:
            return {"credentials": credential, "status_code": response.status_code}
    else:
        return None


def get_credential_by_id(access_token: str, credential_id: str, cs_params: dict):
    """
    This method is use to get the details of credential by providing credential id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/v1/credentials/{credential_id}'
    response = requests.get(api_url, headers=headers)
    return response


def get_profile_by_name(access_token: str, profile_name: str, cs_params: dict):
    """
    This method is use to get the details of profile by providing profile name
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/profiles'
    response = requests.get(api_url, headers=headers)

    profiles = response.json()['items']
    for profile in profiles:
        if profile['name'] == profile_name:
            return {"profile": profile, "status_code": response.status_code}
    else:
        return None


def get_profile_by_id(access_token: str, profile_id: str, cs_params: dict):
    """
    This method is use to get the details of profile by providing profile id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/profiles/{profile_id}'
    response = requests.get(api_url, headers=headers)
    return response


def get_environment(access_token: str, env_name: str, cs_params: dict):
    """
    This method is use to get the details of profile by providing profile id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/v1/environments/{env_name}'
    response = requests.get(api_url, headers=headers)
    return response


def get_environment_pods(access_token: str, env_name: str, cs_params: dict):
    """
    This method is use to get the details of profile by providing profile id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/v1/environments/{env_name}/pods'
    response = requests.get(api_url, headers=headers)
    return response


def get_environment_workloads(access_token: str, env_name: str, cs_params: dict):
    """
    This method is use to get the details of profile by providing profile id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/v1/environments/{env_name}/workloads'
    response = requests.get(api_url, headers=headers)
    return response


def get_environment_namespaces(access_token: str, env_name: str, cs_params: dict):
    """
    This method is use to get the details of profile by providing profile id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/v1/environments/{env_name}/namespaces'
    response = requests.get(api_url, headers=headers)
    return response


def update_environment_credentials(access_token: str, credential_id: str, credential_name: str,
                                   category_name: str, content: str, content_filename: str, cs_params: dict):
    """
    This method is use to create the credential id by providing config file details
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    data = {
        "id": credential_id,
        "name": credential_name,
        "category": category_name,
        "content": content,
        "content_filename": content_filename,
        "created_timestamp": "2023-12-19T10:47:16.824Z",
        "modified_timestamp": "2023-12-19T10:47:16.824Z",
    }

    api_url = f'{cs_url}/api/v1/credentials'
    response = requests.put(api_url, data=json.dumps(data), headers=headers)
    return response


def update_environment_profile(access_token: str, credential_name: str, profile_id: str,
                               profile_name: str, profile_template_id: str, credential_id: str, cs_params: dict):
    """
    This method is use to create the profile by providing credential id and name
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {"Content-Type": "application/json", 'Authorization': f'Bearer {access_token}'}

    env_data = {
        "id": profile_id,
        "name": profile_name,
        "version": "1.0.0",
        "input": {
            "cluster_id": "",
            "credential_id": credential_id,
            "description": "",
            "name": credential_name
        },
        "profile_template_id": profile_template_id
    }

    api_url = f'{cs_url}/api/profiles/{profile_id}'
    response = requests.put(api_url, data=json.dumps(env_data), headers=headers)
    return response


def delete_credential_by_id(access_token: str, credential_id: str, cs_params: dict):
    """
    This method is use to delete the credential by providing credential id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/v1/credentials/{credential_id}'
    response = requests.delete(api_url, headers=headers)
    return response


def delete_profile_by_id(access_token: str, profile_id: str, cs_params: dict):
    """
    This method is use to delete the credential by providing profile id
    """
    access_token, cs_url = check_access_token_cs_url(access_token, cs_params)
    # Make a request using the access token, for example:
    headers = {'Authorization': f'Bearer {access_token}'}

    api_url = f'{cs_url}/api/profiles/{profile_id}'
    response = requests.delete(api_url, headers=headers)
    return response
