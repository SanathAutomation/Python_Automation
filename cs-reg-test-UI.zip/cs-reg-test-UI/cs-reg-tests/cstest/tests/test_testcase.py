import mock
import pytest

import cstest.testcase as testcase


def test_testcase_execution():
    mock_execution = mock.Mock()

    # test success
    mock_execution.ex1.results_id = "ut_id1"
    mock_execution.ex1.results_url = "http://ut_url"
    mock_execution.executions = [mock_execution.ex1]
    ex = testcase.Execution(mock_execution)
    assert ex.results_id == "ut_id1"
    assert ex.results_url == "http://ut_url"

    # test invalid result_id
    mock_execution.ex1.results_id = ""
    with pytest.raises(Exception) as ex_info:
        ex = testcase.Execution(mock_execution)
    assert "execution result_id should be valid." in str(ex_info.value)

    # test invalid result_url
    mock_execution.ex1.results_id = "ut_id1"
    mock_execution.ex1.results_url = ""
    with pytest.raises(Exception) as ex_info:
        ex = testcase.Execution(mock_execution)
    assert "execution result_url should be valid." in str(ex_info.value)


def test_run_testcase():
    mock_client = mock.Mock()
    tc = testcase.RunTestcase(mock_client, "ut_proj")
    # test connect
    tc._connect()
    mock_client.connect.assert_called_once()

    # test project doesn't exist
    mock_client.reset_mock()
    mock_client.api.projects.list_projects.proj_paged.items = []
    mock_client.api.projects.list_projects.return_value = mock_client.api.projects.list_projects.proj_paged
    proj = tc._create_project("ut_proj")
    assert proj
    mock_client.api.projects.list_projects.assert_called_once_with(name="ut_proj")
    mock_client.api.projects.create_project.assert_called_once()

    # test project exist
    mock_client.reset_mock()
    mock_client.api.projects.list_projects.proj_paged.project = "ut_proj"
    mock_client.api.projects.list_projects.proj_paged.items = [mock_client.api.projects.list_projects.proj_paged.project]
    mock_client.api.projects.list_projects.return_value = mock_client.api.projects.list_projects.proj_paged
    proj = tc._create_project("ut_proj")
    assert mock_client.api.projects.list_projects.proj_paged.project == proj
    mock_client.api.projects.list_projects.assert_called_once_with(name="ut_proj")
