import cloudsure
import mock
import pytest

import cstest.client as client

PKG = "cstest.client"


@mock.patch("requests.get")
@mock.patch(PKG + ".Temeva")
def test_client(mock_temeva, mock_get):
    mock_temeva.instance.refresh_token.return_value = "ut_refresh_token"
    mock_temeva.instance.access_token.return_value = "ut_access_token"

    mock_get.resp.status_code = 200
    mock_get.return_value = mock_get.resp

    c = client.Client(
        cs_url="http://ut_cs_url", aion_url="http://ut_aion_url", email="ut_user.ut_host.com", password="ut_password"
    )
    # test getting api before connect
    with pytest.raises(Exception, match="call connect before using client api"):
        assert c.api is None  # should raise if none

    # test getting auth headers before connect
    with pytest.raises(Exception, match="connect must be called before getting auth_headers"):
        assert c.auth_headers is None  # should raise if none

    # test connect exception
    mock_temeva.side_effect = Exception("ut exception")
    with pytest.raises(Exception, match="ut exception"):
        c.connect()  # should raise exception
    mock_temeva.assert_called_once_with("ut_user.ut_host.com", "ut_password", "spirent", base_url="http://ut_aion_url")

    # test successful connect
    mock_temeva.reset_mock()
    mock_get.reset_mock()
    mock_temeva.side_effect = None
    mock_temeva.return_value = mock_temeva.instance
    c.connect()
    mock_temeva.assert_called_once_with("ut_user.ut_host.com", "ut_password", "spirent", base_url="http://ut_aion_url")
    mock_temeva.instance.refresh_token.assert_called_once()
    assert mock_temeva.instance.access_token.call_count == 2
    assert c.api

    # test connect noop
    mock_temeva.reset_mock()
    mock_get.reset_mock()
    c.connect()
    assert not mock_temeva.called
    assert not mock_temeva.instance.refresh_token.called
    assert not mock_temeva.instance.access_token.called
    assert c.api

    # test getting auth header
    mock_temeva.reset_mock()
    mock_get.reset_mock()
    assert c.auth_headers == {
        "Content-Type": "application/json",
        "ACCEPT": "application/json",
        "AUTHORIZATION": "Bearer ut_access_token",
    }
    mock_temeva.instance.access_token.assert_called_once()

    # test cs_url
    assert c.cs_url == "http://ut_cs_url"

    # verify api property returns correct instance types
    assert isinstance(api_datafiles := c.api.datafiles, cloudsure.DataFilesApi)
    assert isinstance(api_executions := c.api.executions, cloudsure.ExecutionsApi)
    assert isinstance(api_profiles := c.api.profiles, cloudsure.ProfilesApi)
    assert isinstance(api_projects := c.api.projects, cloudsure.ProjectsApi)
    assert isinstance(api_testcases := c.api.testcases, cloudsure.TestcasesApi)

    # verify api property called 2nd time returns same object
    assert api_datafiles == c.api.datafiles
    assert api_executions == c.api.executions
    assert api_profiles == c.api.profiles
    assert api_projects == c.api.projects
    assert api_testcases == c.api.testcases
