#
# Copyright (c) 2023 by Spirent Communications Plc.
# All Rights Reserved.
#
# This software is confidential and proprietary to Spirent Communications Inc.
# No part of this software may be reproduced, transmitted, disclosed or used
# in violation of the Software License Agreement without the expressed
# written consent of Spirent Communications Inc.
#

import argparse
import json
import os
import re
from pathlib import Path
from typing import Tuple

import cloudsure

import cstest.utils.overrides as overrides
from cstest.client import Client
from cstest.utils.path import find_dirs, find_files
from cstest.utils.utils import wait_for_execution


class Execution:
    def __init__(self, ex: cloudsure.Execution):
        self._ex: cloudsure.Execution = ex
        if not self.results_id:
            raise Exception(f"execution result_id should be valid. execution {self}")
        if not self.results_url:
            raise Exception(f"execution result_url should be valid. execution {self}")

    def __repr__(self):
        return json.dumps(
            {
                "results_id": self.results_id,
                "results_url": self.results_url,
            }
        )

    @property
    def results_id(self) -> str:
        """
        Gets the execution TCIQ results ID.

        :return: The TCIQ result ID.
        """
        return self._ex.executions[0].results_id

    @property
    def results_url(self) -> str:
        """
        Gets the execution TCIQ result URL

        :return: The TCIQ result URL.
        """
        return self._ex.executions[0].results_url

    @property
    def execution_id(self) -> str:
        """
        Gets the execution ID

        :return: execution id.
        """
        return self._ex.executions[0].id

    # @property
    # def execution(self) -> cloudsure.Execution:
    #     return self._ex


class RunTestcase:
    def __init__(self, client: Client, project_name: str, lib_prefix: str = "", tc_ls_overrides="", tc_id="",
                 kubeconfig_env: str = ""):
        self._client = client
        self._project_name = project_name
        self._ls_template_name = "landslide-template"
        self._lib_prefix = lib_prefix
        self._kubeconfig_env = kubeconfig_env
        self._tc_ls_overrides = tc_ls_overrides
        self._ls_overrides = overrides.parse(self._tc_ls_overrides)
        self._tc_id = tc_id

    def _connect(self) -> None:
        self._client.connect()

    def _create_project(self, project_name) -> cloudsure.Project:
        # Get/create project
        projects = self._client.api.projects.list_projects(name=project_name).items
        if not projects:
            # Project doesn't exist, create it
            print(f"Creating project {project_name}")
            project = cloudsure.EmptyProject(name=project_name)
            project = self._client.api.projects.create_project(project)
        else:
            print(f"Using existing project {project_name}")
            project = projects[0]
        return project

    def _update_tc_input(self, config_file: str) -> Tuple[str, str, dict, dict]:
        tc_name = Path(config_file).stem
        with open(config_file, "r") as fd:
            data = json.load(fd)

        tc_input = data["tc_input"]
        template_id = data["template_id"]
        ls_template_name = data.get("ls_template_name", self._ls_template_name)
        ui_metadata = data.get("ui_metadata", {})

        if template_id == "spirent_resiliency.RESILIENCY_WORKFLOW":
            # Look up environment name
            if self._kubeconfig_env:
                env_name = self._lib_prefix + self._kubeconfig_env
            else:
                env_name = self._lib_prefix + tc_input["environment"]["name"]

            profiles = self._client.api.profiles.get_profile_list(name=env_name)
            if not profiles.items:
                raise Exception(f"failed to find environment profile {env_name}")
            profile = profiles.items[0]
            tc_input["environment"]["name"] = env_name
            tc_input["environment"]["credential_id"] = profile.input["credential_id"]
            tc_input["environment"]["cluster_id"] = profile.input["cluster_id"]

            # Look up load generator name
            load_gen_name = tc_input["load_generator"]["name"]
            if load_gen_name:
                load_gen_name = self._lib_prefix + load_gen_name
                profiles = self._client.api.profiles.get_profile_list(name=load_gen_name)
                if not profiles.items:
                    raise Exception(f"failed to find load generator profile {load_gen_name}")
                profile = profiles.items[0]
                tc_input["load_generator"]["name"] = load_gen_name
                tc_input["load_generator"]["credential_id"] = profile.input["credential_id"]

            # There is no name field in the test case landslide template
            # We may need to figure out a way to better look it up
            df_ls_list = self._client.api.datafiles.get_data_file_list(file_type="ls_session_config")

            regex_start_ls = re.compile(r"^start\.\d*\.*landslide.spirent.com$")
            actions = []
            for action in tc_input["scenario"]["actions"]:
                if regex_start_ls.match(action["urn"]):
                    if action["config"]["template_type"] == "CUSTOM":
                        action["config"]["template_file_name"] = self._lib_prefix + ls_template_name
                        action["config"]["template_id"] = self._get_landslide_template(
                            df_ls_list=df_ls_list,
                            name=self._lib_prefix + ls_template_name,
                        ).id
                    action["config"]["template_override_param"] = overrides.update_tc_ls_override_param(
                        action["config"]["template_override_param"], self._ls_overrides
                    )
                actions.append(action)
            tc_input["scenario"]["actions"] = actions

        return tc_name, template_id, tc_input, ui_metadata

    def _update_tc_input_analytics(self, config_file) -> Tuple[str, str, dict, dict]:
        data = config_file
        tc_name = data["tc_name"]
        tc_input = data["tc_input"]
        template_id = data["template_id"]
        ui_metadata = data.get("ui_metadata", {})

        return tc_name, template_id, tc_input, ui_metadata

    def _get_landslide_template(self, df_ls_list: cloudsure.PaginatedDataFileList, name: str) -> cloudsure.DataFile:
        df_ls_template: cloudsure.Datafile
        for df in df_ls_list.items:
            if df.name == name:
                df_ls_template = df
        if not df_ls_template:
            raise Exception(f"Failed to find a landslide template named {name} in AION storage")
        return df_ls_template

    def _update_tc(
        self, project: cloudsure.Project, tc_name: str, template_id: str, tc_input: dict, ui_metadata: dict
    ) -> cloudsure.Testcase:
        # Get/create/update testcase
        testcases = self._client.api.testcases.list_testcases(name=tc_name, project_id=project.id).items
        tc = cloudsure.Testcase()
        tc.name = tc_name
        tc.project_id = project.id
        tc.testcase_template_id = template_id
        tc.enabled = True
        tc.input = tc_input
        tc.ui_metadata = ui_metadata
        if testcases:
            tc.id = testcases[0].id
            tc = self._client.api.testcases.update_testcase(tc.id, tc)
        else:
            tc = self._client.api.testcases.create_testcase(tc)
        return tc

    def _execute_tc(self, tc: cloudsure.Testcase, poll_sec: int = 5, timeout: int = 0):
        print(f"Running test {tc.name}...")
        print(f"Running test with id {tc.id}...")
        self._tc_id = tc.id
        execution = self._client.api.testcases.start_testcase(tc.id, config=cloudsure.ExecutionOptions(step_mode=False))
        execution = wait_for_execution(
            cc_execution=self._client.api.executions,
            execution_id=execution.id,
            poll_interval_sec=poll_sec,
            timeout_after_intervals=timeout,
        )
        if not _verify_execution_values(execution):
            raise Exception(f"Test {tc.name} execution failed!")

        return execution

    def _execute_tc_existing(self, tc_id: str, poll_sec: int = 5, timeout: int = 0):
        print(f"Running test with id {tc_id}...")
        execution = self._client.api.testcases.start_testcase(tc_id, config=cloudsure.ExecutionOptions(step_mode=False))
        execution = wait_for_execution(
            cc_execution=self._client.api.executions,
            execution_id=execution.id,
            poll_interval_sec=poll_sec,
            timeout_after_intervals=timeout,
        )
        if not _verify_execution_values(execution):
            raise Exception(f"Test {tc_id} execution failed!")

        return execution

    def load(self, config_file: str) -> cloudsure.Testcase:
        """
        Load testcase input file into CloudSure.  If a testcase with the same name exists in the project it will be updated.

        :param config_file: Path to a testcase input file.
            The tc_input field in the file matches code view in the GUI.
            The template_id in the file is the testcase template ID for the test case.
        :return: _desc
        """
        self._connect()
        proj = self._create_project(self._project_name)
        if type(config_file) is str:
            tc_name, template_id, tc_input, ui_metadata = self._update_tc_input(config_file)
        else:
            tc_name, template_id, tc_input, ui_metadata = self._update_tc_input_analytics(config_file)
        return self._update_tc(proj, tc_name, template_id, tc_input, ui_metadata)

    def execute(self, config_file: str) -> Execution:
        tc = self.load(config_file)
        return Execution(self._execute_tc(tc))

    def execute_existing_tc(self, tc_id: str) -> Execution:
        return Execution(self._execute_tc_existing(tc_id))

    @property
    def tc_id(self) -> str:
        """
        Get the test case id
        """
        return self._tc_id

    @property
    def client(self) -> Client:
        """
        Gets the CloudSure client instance.

        :raises Exception: connect should be called before trying to use the client.
        :return: Returns the client instance.
        """
        if not self._client:
            raise Exception("call connect before trying to use client")
        return self._client

    @property
    def landslide_template_name(self) -> str:
        """
        Gets the landslide datafile template name.  The default name is landslide-template.

        :return: _description_
        """
        return self._ls_template_name

    @landslide_template_name.setter
    def landslide_template_name(self, value: str):
        """
        Sets the landslide datafile template name.

        :param value:  Value of the landslide tempalte name.
        """
        self._ls_template_name = value


def _get_tc_input_files(config_path: str) -> list[str]:
    config_files = []
    if os.path.isfile(config_path):
        config_files.append(config_path)
    elif os.path.isdir(config_path):
        cs_dirs: list[str] = []
        if Path(config_path).root == "tc_input":
            cs_dirs += config_path
        else:
            cs_dirs += find_dirs(config_path, "tc_input")
        print(f"cs_dirs = {cs_dirs}")
        for cs_dir in cs_dirs:
            config_files += find_files(cs_dir, ".*json$")
    if not config_files:
        raise Exception(f"No tc_input files specified or found in {config_path}")
    return config_files


def _verify_execution_values(execution):
    if execution.status != "DONE":
        print("Fail! Execution did not finish with DONE status")
        return False
    tc_execution = execution.executions[0]
    if tc_execution.status not in ["PASS", "IMPROVEMENT", "ACCEPTABLE", "ALERT"]:
        print("Fail! Testcase execution did not finish with PASS status")
        print("Testcase execution status is " + tc_execution.status)
        print(tc_execution.testcase_results["error_info"])
        return False
    if tc_execution.status_message != "No errors":
        print("Fail! Testcase execution did not finish with No errors " "status_message")
        return False
    if not tc_execution.testcase_results:
        print("Fail! Testcase execution has empty or no testcase_results")
        return False
    else:
        # print("=== testcase_results in tc_execution ===")
        # print(json.dumps(tc_execution.testcase_results, indent=2))
        overall_status = tc_execution.testcase_results["overall_status"]
        print("overall_status under testcase_results is " + overall_status)
        if overall_status != "PASSED":
            print("Fail! overall_status is " + overall_status)
            return False
    return True


class RunMultipleTestcases:
    def __init__(self, client: Client, project_name: str, lib_prefix: str = "", tc_ls_overrides: str = ""):
        self._client = client
        self._project_name = project_name
        self._lib_prefix = lib_prefix
        self._tc_ls_overrides = tc_ls_overrides

    def _connect(self) -> None:
        self._client.connect()

    def execute(self, config_paths: list[str]) -> list[Execution]:
        self._connect()
        exec_list: list[Execution] = []
        rtc = RunTestcase(self._client, self._project_name, lib_prefix=self._lib_prefix, tc_ls_overrides=self._tc_ls_overrides)
        for config_path in config_paths:
            for config_file in _get_tc_input_files(config_path):
                exec = rtc.execute(config_file)
                exec_list.append(exec)
        return exec_list

    @property
    def client(self) -> Client:
        if not self._client:
            raise Exception("call connect before using client")
        return self._client


def main(args) -> None:
    if not args.aion_url:
        raise Exception("--aion_url is required")
    if not args.cs_url:
        raise Exception("--cs_url is required")
    if not args.config_path:
        raise Exception("--config_path is required")

    client = Client(
        cs_url=args.cs_url,
        aion_url=args.aion_url,
        email=args.email,
        password=args.password,
        subdomain=args.subdomain,
    )
    if os.path.isdir(args.config_path):
        rmtc = RunMultipleTestcases(
            client=client, project_name=args.project_name, lib_prefix=args.lib_prefix, tc_ls_overrides=args.tc_ls_overrides
        )
        ex_list = rmtc.execute([args.config_path])
        print(f"execution: {ex_list}")
    else:
        rtc = RunTestcase(
            client=client, project_name=args.project_name, lib_prefix=args.lib_prefix, tc_ls_overrides=args.tc_ls_overrides
        )
        ex = rtc.execute(args.config_path)
        print(f"execution: {ex}")
        print(f"cs_url:{rtc.client.cs_url} results_id:{ex.results_id}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Tests the execution of a project")
    parser.add_argument("--cs_url", help="CloudSure application URL")
    parser.add_argument("--aion_url", help="AION URL", default="")
    parser.add_argument("--email", help="Email address of AION user", default="temeva-dev@spirent.com")
    parser.add_argument("--password", help="Password of AION user", default="spirent1234")
    parser.add_argument("--subdomain", help="AION subdomain", default="spirent")
    parser.add_argument("--project_name", help="Project name", default="regression1")
    parser.add_argument("--config_path", help="Config path", default="")
    parser.add_argument("--lib_prefix", help="Library prefix name", default="")
    parser.add_argument("--tc_ls_overrides", help="Testcase template landslide overrides", default="")
    args = parser.parse_args()
    main(args)
