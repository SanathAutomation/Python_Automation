# Copyright 2017-2019 Spirent Communications, All Rights Reserved
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License

import json
from threading import Event, Lock, Thread
from weakref import ref

import requests

# CloudSure application ID
APP_ID = "e363f6c9c3a0467eae31f24a99ff2044"


class Refresh(Thread):
    """Thread to refresh access token"""

    def __init__(self, temeva):
        super().__init__(name="token_refresh")
        self._stop_event = Event()
        self._temeva = ref(temeva)
        self._interval = temeva.expires_in() * 0.90

    def run(self):
        t = self._temeva()
        self._stop_event.wait(self._interval)
        if t is not None:
            t.refresh()
            del t

    def stop(self):
        self._stop_event.set()


class Temeva:
    """Temeva applications require a bearer token from the
    Temeva IAM API. This class provides that functionality to obtain
    the token and refresh the token.
    """

    def __init__(self, username, password, subdomain=None, base_url=None, workspace_id=None):
        if not subdomain and not base_url:
            raise RuntimeError("No subdomain and base Temeva URL specified.")

        if "{}" in base_url:
            base_url = "https://{}.temeva.com".format(subdomain)
            self.base_url = base_url
        elif base_url and not subdomain:
            self.base_url = base_url
            subdomain = self._get_subdomain()
        else:
            self.base_url = base_url

        # Login and get the token information
        scope = self._get_org_id()
        self._oauth_info = self._get_oauth_info(username, password, scope)

        self.user_id = None
        self._lock = Lock()

        # Change the user workspace if specified
        # This determines what licenses will be used when running tests
        # as license entitlements are assigned to a workspace.
        if workspace_id:
            self._oauth_info = self._set_user_workspace(workspace_id)

        self._refresh = Refresh(self)
        self._refresh.daemon = True
        self._refresh.start()

    def __del__(self):
        if hasattr(self, "_refresh"):
            self._refresh.stop()
            self._refresh.join()

    def _get_oauth_info(self, username, password, scope):
        data = {
            "grant_type": "password",
            "username": username,
            "password": password,
            "scope": scope,
        }
        headers = {"ACCEPT": "application/json"}
        token_url = self.base_url + "/api/iam/oauth2/token"
        resp = requests.post(token_url, headers=headers, data=data)
        if resp.status_code != 200:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))
        return resp.json()

    def _set_user_workspace(self, workspace_id):
        data = {
            "subject_token": self.access_token(),
            "subject_token_type": "urn:ietf:params:oauth:token-type:access_token",
            "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
            "resource": "urn:" + self._get_org_id() + ":workspace:" + workspace_id,
        }
        headers = {"ACCEPT": "application/json"}
        token_url = self.base_url + "/api/iam/oauth2/token"
        resp = requests.post(token_url, headers=headers, data=data)
        if resp.status_code != 200:
            raise RuntimeError("Unexpected response while setting workspace {}: {}".format(resp.status_code, resp.content))

        return resp.json()

    def refresh(self):
        data = {"grant_type": "refresh_token", "refresh_token": self.refresh_token()}
        headers = {"ACCEPT": "application/json"}
        token_url = self.base_url + "/api/iam/oauth2/token"
        with self._lock:
            resp = requests.post(token_url, headers=headers, data=data)
            if resp.status_code != 200:
                # Todo add retry logic.
                print("Unable to refresh token: response: {}, {}".format(resp.status_code, resp.content))
                return
            self._oauth_info = resp.json()

    def _get_org_id(self):
        url = self.base_url + "/api/iam/organizations/default"
        headers = {"ACCEPT": "application/json"}
        resp = requests.get(url, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))

        org = resp.json()
        return org.get("id", "")

    def _get_subdomain(self):
        url = self.base_url + "/api/iam/organizations/default"
        headers = {"ACCEPT": "application/json"}
        resp = requests.get(url, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))

        org = resp.json()
        return org.get("subdomain", "")

    def get_user_id(self):
        if self.user_id:
            return self.user_id
        url = self.base_url + "/api/iam/users/my"
        headers = {
            "ACCEPT": "application/json",
            "AUTHORIZATION": "Bearer {}".format(self.access_token()),
        }
        resp = requests.get(url, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))

        user = resp.json()
        self.user_id = user["id"]
        return self.user_id

    def get_entitlements(self, lic_id=None, lic_version=None, workspace_id=None):
        url = self.base_url + "/api/lic/entitlements?application_id=" + APP_ID
        if lic_id:
            url += "&license_id=" + lic_id
        if lic_version:
            url += "&license_version=" + lic_version
        if workspace_id:
            url += "&workspace_id=" + workspace_id
        headers = {"AUTHORIZATION": "Bearer {}".format(self.access_token())}
        resp = requests.get(url, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))

        return resp.json()

    # Apollo functions
    def cluster_list_products(self):
        url = self.base_url + "/api/cluster/temeva-proxy/api/inv/products"
        headers = {"AUTHORIZATION": "Bearer {}".format(self.access_token())}
        resp = requests.get(url, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))
        return resp.json()

    def list_applications(self):
        url = self.base_url + "/api/inv/applications"
        headers = {"AUTHORIZATION": "Bearer {}".format(self.access_token())}
        resp = requests.get(url, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))
        return resp.json()

    def list_products(self):
        url = self.base_url + "/api/inv/products"
        headers = {"AUTHORIZATION": "Bearer {}".format(self.access_token())}
        resp = requests.get(url, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))
        return resp.json()

    def list_product_instances(self):
        url = self.base_url + "/api/inv/product-instances"
        headers = {"AUTHORIZATION": "Bearer {}".format(self.access_token())}
        resp = requests.get(url, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))
        return resp.json()

    def get_product_instance(self, inst_id):
        url = self.base_url + "/api/inv/product-instances/" + inst_id
        headers = {"AUTHORIZATION": "Bearer {}".format(self.access_token())}
        resp = requests.get(url, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))
        return resp.json()

    def delete_product_instance(self, inst_id):
        url = self.base_url + "/api/local/product-instances/" + inst_id
        headers = {"AUTHORIZATION": "Bearer {}".format(self.access_token())}
        resp = requests.delete(url, headers=headers)
        if resp.status_code != 204:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))
        return True

    def list_product_instance_metadata(self):
        url = self.base_url + "/api/inv/product-instance-metadata"
        headers = {"AUTHORIZATION": "Bearer {}".format(self.access_token())}
        resp = requests.get(url, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))

        return resp.json()

    def list_product_versions(self):
        url = self.base_url + "/api/inv/product-versions"
        headers = {"AUTHORIZATION": "Bearer {}".format(self.access_token())}
        resp = requests.get(url, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))

        return resp.json()

    def product_version_download(self, version_id):
        data = {"type": "product", "product": {"product_version_id": version_id}}
        headers = {
            "Content-Type": "application/json",
            "AUTHORIZATION": "Bearer {}".format(self.access_token()),
        }
        token_url = self.base_url + "/api/cluster/updates/x/start-sync"
        with self._lock:
            resp = requests.post(token_url, headers=headers, data=json.dumps(data))
            if resp.status_code != 200:
                print("Unexpected response {}, {}".format(resp.status_code, resp.content))
            return resp.json()

    def delete_product_version(self, ver_id):
        url = self.base_url + "/api/inv/product-versions/" + ver_id
        headers = {"AUTHORIZATION": "Bearer {}".format(self.access_token())}
        resp = requests.delete(url, headers=headers)
        if resp.status_code != 204:
            raise RuntimeError("Unexpected response {}: {}".format(resp.status_code, resp.content))
        return True

    def create_product_inst(self, version_id, location):
        data = {
            "product_version": {"artifacts": [], "id": version_id},
            "initial_location_name": location,
        }
        headers = {
            "Content-Type": "application/json",
            "AUTHORIZATION": "Bearer {}".format(self.access_token()),
        }
        token_url = self.base_url + "/api/local/product-instances"
        with self._lock:
            resp = requests.post(token_url, headers=headers, data=json.dumps(data))
            if resp.status_code != 201:
                print("Unexpected response {}, {}".format(resp.status_code, resp.content))
            return resp.json()

    def access_token(self):
        with self._lock:
            return self._oauth_info["access_token"]

    def refresh_token(self):
        with self._lock:
            return self._oauth_info["refresh_token"]

    def expires_in(self):
        with self._lock:
            return self._oauth_info["expires_in"]

    def token_type(self):
        with self._lock:
            return self._oauth_info["token_type"]
