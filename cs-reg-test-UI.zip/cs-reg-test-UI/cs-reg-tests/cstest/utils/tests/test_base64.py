import cstest.utils.base64 as base64


def test_base64():
    x = "abc1234"
    y = base64.encode(x)
    assert x != y
    z = base64.decode(y)
    assert x == z
