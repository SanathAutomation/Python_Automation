import cstest.utils.overrides as overrides


def test_parse():
    # test success
    data = overrides.parse("key1=val1,key2=val2")
    assert data == {
        "key1": "val1",
        "key2": "val2",
    }

    # test spaces
    data = overrides.parse("key1=val1, key2=val2")
    assert data == {
        "key1": "val1",
        "key2": "val2",
    }

    # test empty
    data = overrides.parse("")
    assert not data

    # test ending with a comma
    data = overrides.parse(",")
    assert not data


def test_update():
    x = {
        "key1": "val1",
        "key2": "val2",
    }

    # test update key1
    assert overrides.update_dict(x, {"key1": "new_val1"}) == {
        "key1": "new_val1",
        "key2": "val2",
    }

    # test update key2
    assert overrides.update_dict(x, {"key2": "new_val2"}) == {
        "key1": "val1",
        "key2": "new_val2",
    }

    # test no change
    assert overrides.update_dict(x, {}) == x


def test_update_tc_ls_override_param():
    x = [{"name": "key1", "value": "val1"}, {"name": "key2", "value": "val2"}]

    # test update key1
    assert overrides.update_tc_ls_override_param(x, {"key1": "new_val1"}) == [
        {"name": "key1", "value": "new_val1"},
        {"name": "key2", "value": "val2"},
    ]

    # test update key2
    assert overrides.update_tc_ls_override_param(x, {"key2": "2"}) == [
        {"name": "key1", "value": "val1"},
        {"name": "key2", "value": "2"},
    ]

    # test no change
    assert overrides.update_tc_ls_override_param(x, {}) == x
