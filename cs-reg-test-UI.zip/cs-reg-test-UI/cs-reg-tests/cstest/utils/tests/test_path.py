import mock

import cstest.utils.path as path


@mock.patch("os.walk")
def test_find_dirs(mock_walk):
    ut_path = "/some/fake/path"
    ut_pattern = "ut_dir1"

    mock_walk.return_value = [
        ("/some/fake/path/subdir1", ["ut_dir1", "ut_dir2", "ut_dir3"], ["ut_file1"]),
        ("/some/fake/path/subdir2", ["ut_dir0", "ut_dir1", "ut_dir2"], []),
    ]

    dirs = path.find_dirs(ut_path, ut_pattern)
    assert dirs == [
        "/some/fake/path/subdir1/ut_dir1",
        "/some/fake/path/subdir2/ut_dir1",
    ]


@mock.patch("os.walk")
def test_find_files(mock_walk):
    ut_path = "/some/fake/path"
    ut_pattern = ".*\\.json$"

    mock_walk.return_value = [
        ("/some/fake/path/subdir1", ["ut_dir1", "ut_dir2", "ut_dir3"], ["ut_file1.json", "ut_file2.json", "ut_file3.yaml"]),
        ("/some/fake/path/subdir2", ["ut_dir0", "ut_dir1", "ut_dir2"], []),
    ]

    files = path.find_files(ut_path, ut_pattern)
    assert files == ["/some/fake/path/subdir1/ut_file1.json", "/some/fake/path/subdir1/ut_file2.json"]
