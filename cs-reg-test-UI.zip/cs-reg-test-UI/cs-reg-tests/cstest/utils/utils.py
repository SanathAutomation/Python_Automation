# Copyright 2017-2019 Spirent Communications, All Rights Reserved
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License

import argparse
import logging
import sys
import time
from datetime import datetime

import requests
from cloudsure import EmptyProject, Testcase, configuration
from cloudsure.rest import ApiException

from cstest.utils.temeva import Temeva

# Create the logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def log_info(msg):
    logger.info(str(datetime.today()) + " " + msg)


def log_err(msg):
    logger.error(str(datetime.today()) + " " + msg)


def log_failure(msg):
    logger.error(str(datetime.today()) + " TEST FAILURE: " + msg)


def test_complete(verdict):
    if verdict:
        log_info("Test PASSED")
        sys.exit(0)
    else:
        log_info("Test FAILED")
        sys.exit(1)


def parse_test_args(testDescription, defaultTimeout=40):
    parser = argparse.ArgumentParser(description=testDescription)
    parser.add_argument("app_ip", help="CloudSure application VM IP address")
    parser.add_argument("email", help="Email address of Temeva user")
    parser.add_argument("password", help="Password of Temeva user")
    parser.add_argument(
        "--poll_interval_sec",
        help="Interval, in seconds, at which to poll " "for a test execution status",
        default=1,
    )
    parser.add_argument(
        "--timeout_after_intervals",
        help="Number of poll intervals to wait " "before timing out while waiting for an execution status",
        default=defaultTimeout,
    )
    parser.add_argument("--subdomain", help="Temeva subdomain", default="spirent")
    parser.add_argument(
        "--temeva_url",
        help="URL of Temeva backend. In order to insert "
        "the subdomain automatically, you can specify the url as follows: "
        "https://{}.oriontest.net.",
        default="https://{}.oriontest.net",
    )
    parser.add_argument(
        "--workspace_id",
        help="The ID of the Temeva Workspace the user " "should login under.",
        default=None,
    )
    args = parser.parse_args()
    if "{}" in args.temeva_url:
        args.temeva_url = args.temeva_url.format(args.subdomain)

    try:
        # Get OAuth2 bearer token based on provided credentials
        temeva = Temeva(
            args.email,
            args.password,
            args.subdomain,
            base_url=args.temeva_url,
            workspace_id=args.workspace_id,
        )
    except Exception as e:
        log_err("Caught exception while getting Temeva OAuth2 token: " + repr(e))
        sys.exit()

    configuration.host = "http://{}/api".format(args.app_ip)
    configuration.access_token = temeva.access_token()

    return args, temeva


def create_project_testcases(
    p,
    tc,
    template_id,
    tc_input,
    num_testcases,
    proj_name="Regression Project",
    tc_name="Regression Testcase",
):
    # Delete the project if it already exists
    project_name = proj_name + " " + str(datetime.today())
    projects = p.list_projects(name=project_name).items
    if projects:
        log_info("Project " + project_name + " already exists, deleting it")
        p.delete_project(projects[0].id, delete_testcases=True)

    # Create the project
    log_info("Creating project")
    project_body = EmptyProject(name=project_name)
    project = p.create_project(project_body)

    # Create testcases
    tc_id_list = []
    for i in range(num_testcases):
        testcase_name = tc_name + " " + str(i)
        log_info("Creating testcase " + testcase_name)
        testcase_body = Testcase(
            name=testcase_name,
            project_id=project.id,
            testcase_template_id=template_id,
            input=tc_input,
            enabled=True,
        )
        testcase = tc.create_testcase(testcase_body)
        tc_id_list.append(testcase.id)

    return project.id, tc_id_list


def delete_execution(ex, execution):
    ex_id = execution.id
    tc_ex_id_list = []
    # Get list of testcase execution ID's
    for i in range(len(execution.executions)):
        tc_ex = execution.executions[i]
        tc_ex_id_list.append(tc_ex.id)

    # Try to stop the execution if it's still active
    if execution.status != "DONE":
        log_info("Deleting execution with status " + execution.status)
        log_info("Attempt to stop it first...")
        ex.stop_execution(ex_id)
        time.sleep(5)
        execution = ex.get_execution(ex_id)
        if execution.status != "DONE":
            log_err("After 5sec execution wasn't stopped; status: " + execution.status)
        else:
            log_info("Execution successfully stopped")

    # Delete the execution object
    executions_delete(ex_id)

    # Verify execution object doesn't exist
    found = True
    try:
        ex.get_execution(ex_id)
    except ApiException:
        found = False
    if found:
        log_failure("Execution with ID " + ex_id + " was found. Should be deleted.")
        return False

    # Verify testcase execution objects don't exist
    for tc_ex_id in tc_ex_id_list:
        found = True
        try:
            ex.get_testcase_execution(tc_ex_id)
        except ApiException:
            found = False
        if found:
            log_failure("Testcase execution with ID " + tc_ex_id + " was found. Should be deleted.")
            return False

    return True


def executions_delete(execution_id):
    """Deletes an execution. Exection delete is an internal API and not exposed to the customer.

    Args:
      execution_id: ID of the execution to delete.
    Raises:
      RuntimeError: If execution ID is not found or other Orion repo error.
    """
    token = "Bearer {}".format(configuration.access_token)
    execution_url = configuration.host + "/executions/" + execution_id
    r = requests.delete(
        execution_url,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": token,
        },
    )
    if r.status_code != 204:
        raise RuntimeError("Unexpected response {}: {}".format(r.status_code, r.content))
    return


def wait_for_execution(
    cc_execution,
    execution_id,
    poll_interval_sec=1,
    timeout_after_intervals=0,
    wait_for_status=["DONE", "PAUSED"],
    step_index_to_wait=0,
):
    """Waits for the specified status in the running testcase of an execution.

    Args:
      cc_execution: An instance of the Executions object.
      execution_id: ID of the execution to wait for.
      poll_interval_sec: Number of seconds to wait for between polls in the loop.
      timeout_after_intervals: Number of polling intervals to wait before timing out.
                               If 0 (by default), the wait will never timeout.
      wait_for_status: Wait for a specific status.
      step_index_to_wait: Wait for step index to be reached. Step indexes start at 1.
    Raises:
      RuntimeError: If execution ID is not found or other Orion repo error.
                    If the execution status is not valid.
                    If the timeout interval has been reached.
    Returns:
      The CC execution as a dict.
    """
    VALID_STATUS = ["RUNNING", "DONE", "PAUSED"]
    intervals = 0

    while True:
        # Get execution and status value
        execution = cc_execution.get_execution(execution_id)
        status = execution.status
        if status not in VALID_STATUS:
            raise RuntimeError("Invalid execution status: {}.".format(status))

        # Determine if we reached the status we're looking for
        if status in wait_for_status:
            # If specified, get the current step index of the running tc execution
            # and determine if we reached the step we're looking for
            if step_index_to_wait:
                current_step = get_current_step_running_tc_exec(execution)
                if current_step:
                    if current_step.index == step_index_to_wait:
                        return execution
            else:
                return execution

        # If non-zero, timeout after we reached the number of intervals
        if timeout_after_intervals and intervals >= timeout_after_intervals:
            if step_index_to_wait:
                current_step = get_current_step_running_tc_exec(execution)
                current_step_index = current_step.index if current_step else None
                msg = "Timed out waiting for step index {} and status {}. Current index: {}, status: {}.".format(
                    step_index_to_wait, wait_for_status, current_step_index, status
                )
            else:
                msg = "Timed out waiting for execution status {}. Current status: {}.".format(wait_for_status, status)
            raise RuntimeError(msg)

        time.sleep(poll_interval_sec)
        intervals += 1


def get_running_tc_exec(execution):
    """Get the running testcase of an execution.

    Args:
      execution: Execution dict returned from the CC API.
    Returns:
      The running testcase execution dict or None if no running testcase execution.
    """
    VALID_RUNNING_STATUS = ["RUNNING", "PAUSED"]
    executions = execution.executions
    if not executions:
        return None

    # Go through all tc executions and find the running one
    # It would be nice if the execution object had the index
    for ex in executions:
        tc_status = ex.status
        if tc_status in VALID_RUNNING_STATUS:
            return ex

    # No running execution found
    return None


def get_current_step_running_tc_exec(execution):
    """Get the current step of the running testcase in an execution.

    Args:
      execution: Execution dict returned from the CC API.
    Returns:
      The current step dict of the running testcase.
      None it no running testcase or no current step.
    """
    tc_exec = get_running_tc_exec(execution)
    if not tc_exec:
        return None
    return tc_exec.current_step


def app_info():
    """Gets information about the CloudSure application.

    Raises:
      RuntimeError: If unable to retrieve application info.
    """
    token = "Bearer {}".format(configuration.access_token)
    url = configuration.host + "/appinfo"
    r = requests.get(url, headers={"Content-Type": "application/json", "Authorization": token})
    if r.status_code != 200:
        raise RuntimeError("Unexpected response {}: {}".format(r.status_code, r.content))

    return r.json()


def get_active_executions(cc_execution):
    """Returns a list of executions on the application instance that are either running or paused.

    Raises:
      RuntimeError: If unable to retrieve application info.
    """
    info = app_info()
    app_inst_id = info.get("app_inst_id")
    if not app_inst_id:
        raise RuntimeError("Cannot find application instance ID")

    return cc_execution.get_execution_list(app_inst_id=app_inst_id, status=["RUNNING", "PAUSED"]).items
