#
# Copyright (c) 2023 by Spirent Communications Plc.
# All Rights Reserved.
#
# This software is confidential and proprietary to Spirent Communications Inc.
# No part of this software may be reproduced, transmitted, disclosed or used
# in violation of the Software License Agreement without the expressed
# written consent of Spirent Communications Inc.
#

import os
import re


def find_dirs(base_dir: str, pattern: str) -> list[str]:
    reg_compile = re.compile(pattern)
    result = []
    for root, directories, files in os.walk(base_dir):
        for name in directories:
            if reg_compile.match(name):
                result.append(os.path.join(root, name))
    return result


def find_files(base_dir: str, pattern: str) -> list[str]:
    reg_compile = re.compile(pattern)
    result = []
    for root, directories, files in os.walk(base_dir):
        for name in files:
            if reg_compile.match(name):
                result.append(os.path.join(root, name))
    return result
