# Copyright 2017-2019 Spirent Communications, All Rights Reserved
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License


def parse(data: str) -> dict:
    """
    Parse a string in format "key1=val1,key2=val2" into a dictionary

    :param data: String containing formatted key values
    :return: Dictionary of converted string
    """
    res = {}
    for item in data.split(","):
        try:
            k, v = item.split("=")
        except Exception:
            continue
        k = k.strip()
        v = v.strip()
        if k and v:
            res[k] = v
    return res


def update_dict(data: dict, new_data: dict) -> dict:
    """
    Return updated dict data with overrides from new_data

    :param data: Dictionary of data
    :param new_data: Dictionary of updates
    :return: New dictionary
    """
    return {**data, **new_data}


def update_tc_ls_override_param(data: list[dict], new_data: dict) -> list[dict]:
    """
    Return updated list data with overrides from new_data

    :param data: Testcase "template_override_param" data where list is in format [{"name":"name1", "value":"value1"}]
    :param new_data: Dictionary of updates
    :return: New list of data
    """
    res = []
    for item in data:
        if item["name"] in new_data:
            item = item.copy()
            item["value"] = str(new_data[item["name"]])
        res.append(item)
    return res
