#
# Copyright (c) 2023 by Spirent Communications Plc.
# All Rights Reserved.
#
# This software is confidential and proprietary to Spirent Communications Inc.
# No part of this software may be reproduced, transmitted, disclosed or used
# in violation of the Software License Agreement without the expressed
# written consent of Spirent Communications Inc.
#

import argparse
import json
import os
from enum import Enum
from pathlib import Path
from typing import Any

import cloudsure
import requests

import cstest.utils.base64 as base64
import cstest.utils.overrides as overrides
from cstest.client import Client
from cstest.utils.path import find_dirs, find_files


class UpdatePolicy(Enum):
    IF_NOT_PRESENT = "ifnotpresent"
    ALWAYS = "always"
    VERIFY_EXISTS = "verifyexists"


class ShouldNotUpdate(Exception):
    ...
    pass


def _should_update(name_desc: str, obj: Any, update_policy: UpdatePolicy):
    if update_policy == UpdatePolicy.VERIFY_EXISTS:
        if not obj:
            print(f"Warning: failed to verify {name_desc} exists")
        else:
            print(f"Verified {name_desc} exists")
        raise ShouldNotUpdate()

    elif update_policy == UpdatePolicy.IF_NOT_PRESENT:
        if obj:
            print(f"Using existing {name_desc}")
            raise ShouldNotUpdate()

    print(f"Updating library {name_desc}....")


def _update_cred(base_url: str, auth_headers: dict, cred_data: dict, update_policy: UpdatePolicy) -> dict:
    # find cred by name
    url = base_url + f"/v1/credentials?name={cred_data['name']}"
    r = requests.get(url, headers=auth_headers, data=json.dumps(cred_data))
    creds = []
    if r.status_code == 200:
        creds = r.json()

    _should_update(f"credential {cred_data['name']}", creds, update_policy)

    if not creds:
        # create credentials
        url = base_url + "/v1/credentials"
        r = requests.post(url, headers=auth_headers, data=json.dumps(cred_data))
        if r.status_code != 200:
            raise RuntimeError("Unexpected response {}: {!r}".format(r.status_code, r.content))
    else:
        # update credentials
        url = base_url + "/v1/credentials"
        cred_data["id"] = creds[0]["id"]
        r = requests.put(url, headers=auth_headers, data=json.dumps(cred_data))
        if r.status_code != 200:
            raise RuntimeError("Unexpected response {}: {!r}".format(r.status_code, r.content))
    return r.json()


class Library:
    def __init__(self, client: Client):
        self._client = client

    def _connect(self) -> None:
        self._client.connect()

    def _update_profile(self, profile: cloudsure.Profile, update_policy: UpdatePolicy) -> cloudsure.Profile:
        profiles = self._client.api.profiles.get_profile_list(name=profile.name)
        profile: cloudsure.Profile

        _should_update(f"profile {profile.name}", profiles.items, update_policy)

        if not profiles.items:
            profile = self._client.api.profiles.create_profile(profile)
        else:
            profile.id = profiles.items[0].id
            profile = self._client.api.profiles.update_profile(profile.id, profile_input_body=profile)
        return profile

    def _update_datafile(
        self, file_path: str, file_type: str, update_policy: UpdatePolicy, lib_prefix: str
    ) -> cloudsure.DataFile:
        if not os.path.exists(file_path):
            raise Exception(f"file {file_path} doesn't exist")

        # name = os.path.basename(file_path)
        name = lib_prefix + Path(file_path).stem
        df_list = self._client.api.datafiles.get_data_file_list(file_type=file_type)
        datafile = None
        for df in df_list.items:
            if df.name == name:
                datafile = df
                break

        _should_update(f"datafile {name}", datafile, update_policy)

        if not datafile:
            datafile = self._client.api.datafiles.upload_data_file(file=file_path, file_type=file_type, name=name)
        else:
            datafile = self._client.api.datafiles.upload_data_file(file=file_path, file_type=file_type, name=name, id=df.id)
        return datafile

    def _update_cred(self, cred_data: dict, update_policy: UpdatePolicy) -> dict:
        return _update_cred(cloudsure.configuration.host, self._client.auth_headers, cred_data, update_policy)

    def _update_datafiles(self, cs_dir: str, update_policy: UpdatePolicy, lib_prefix: str) -> None:
        # datafiles
        files = find_files(os.path.join(cs_dir, "datafiles", "landslide_session_config"), ".*json$")
        for fn in files:
            print(f"Checking datafile {lib_prefix + Path(fn).stem} [{fn}]...")
            try:
                self._update_datafile(
                    file_path=fn, file_type="ls_session_config", update_policy=update_policy, lib_prefix=lib_prefix
                )
            except ShouldNotUpdate:
                continue

    def _update_env_profile(self, name: str, fn: str, update_policy: UpdatePolicy) -> None:
        print(f"Checking environment profile {name}  [{fn}]...")
        data = ""
        with open(fn, "r") as fd:
            data = fd.read()
        data_b64 = base64.encode(data)

        cred_data = {
            "id": "",
            "name": name,
            "category": "environment",
            "content_filename": f"{name}.yaml",
            "content": data_b64,
        }

        profiles = self._client.api.profiles.get_profile_list(name=name)
        if profiles.items:
            if id := profiles.items[0].input["credential_id"]:
                cred_data["id"] = id
        # print("env profile: " + json.dumps(cred_data))

        try:
            cred_data = self._update_cred(cred_data, update_policy)
        except ShouldNotUpdate:
            pass

        profile = cloudsure.Profile()
        profile.profile_template_id = "environments"
        profile.name = cred_data["name"]
        profile.input = {
            "cluster_id": "",
            "credential_id": cred_data["id"],
            "description": "",
            "name": profile.name,
        }
        try:
            profile = self._update_profile(profile, update_policy)
        except ShouldNotUpdate:
            pass

    def _update_landslide_profile(self, name: str, fn: str, update_policy: UpdatePolicy, ls_overrides: dict) -> None:
        print(f"Checking landslide profile {name} [{fn}]...")
        data = ""
        with open(fn, "r") as fd:
            prof = json.load(fd)
            prof = overrides.update_dict(prof, ls_overrides)
            data = json.dumps(prof)
        data_b64 = base64.encode(data)

        cred_data = {
            "id": "",
            "name": name,
            "category": "landslide",
            "content": data_b64,
        }

        profiles = self._client.api.profiles.get_profile_list(name=name)
        if profiles.items:
            if id := profiles.items[0].input["credential_id"]:
                cred_data["id"] = id
        # print("landslide profile: " + json.dumps(cred_data))

        try:
            cred_data = self._update_cred(cred_data, update_policy)
        except ShouldNotUpdate:
            pass

        profile = cloudsure.Profile()
        profile.profile_template_id = "load_generators"
        profile.name = cred_data["name"]
        profile.input = {
            "credential_id": cred_data["id"],
            "description": "",
            "name": profile.name,
        }
        try:
            profile = self._update_profile(profile, update_policy)
        except ShouldNotUpdate:
            pass

    def _update_profiles(self, cs_dir: str, update_policy: UpdatePolicy, lib_prefix: str = "", ls_overrides: dict = {}) -> None:
        # environment profiles
        files = find_files(os.path.join(cs_dir, "profiles", "environment"), ".*yaml$")
        for fn in files:
            name = lib_prefix + Path(fn).stem
            self._update_env_profile(name, fn, update_policy=update_policy)

        # landslide profiles
        files = find_files(os.path.join(cs_dir, "profiles", "landslide"), ".*json$")
        for fn in files:
            name = lib_prefix + Path(fn).stem
            self._update_landslide_profile(name, fn, update_policy=update_policy, ls_overrides=ls_overrides)

    def update(
        self,
        config_path: str,
        update_policy: UpdatePolicy = UpdatePolicy.IF_NOT_PRESENT,
        lib_prefix: str = "",
        kubeconfig="",
        kubeconfig_env="",
        profile_ls_overrides="",
    ) -> None:
        self._connect()

        ls_overrides = overrides.parse(profile_ls_overrides)

        cs_dirs = find_dirs(config_path, "cs")
        for cs_dir in cs_dirs:
            self._update_datafiles(cs_dir, update_policy, lib_prefix)
            self._update_profiles(cs_dir, update_policy, lib_prefix, ls_overrides=ls_overrides)

        if kubeconfig and kubeconfig_env:
            self._update_env_profile(lib_prefix + kubeconfig_env, kubeconfig, update_policy=update_policy)


def main(args):
    if not args.aion_url:
        raise Exception("--aion_url is required")
    if not args.cs_url:
        raise Exception("--cs_url is required")
    if not args.config_path:
        raise Exception("--config_path is required")

    try:
        update_policy = UpdatePolicy(args.update_policy.lower())
    except Exception:
        raise Exception(f"--update_policy {args.update_policy} should be IfNotPresent|Always|VerifyExists")

    client = Client(
        cs_url=args.cs_url,
        aion_url=args.aion_url,
        email=args.email,
        password=args.password,
        subdomain=args.subdomain,
    )
    lib = Library(client)
    lib.update(
        args.config_path,
        update_policy=update_policy,
        lib_prefix=args.lib_prefix,
        kubeconfig=args.kubeconfig,
        kubeconfig_env=args.kubeconfig_env,
        profile_ls_overrides=args.profile_ls_overrides,
    )
    print("Finished!")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Tests the execution of a project")
    parser.add_argument("--cs_url", help="CloudSure application URL")
    parser.add_argument("--aion_url", help="AION URL", default="")
    parser.add_argument("--email", help="Email address of AION user", default="temeva-dev@spirent.com")
    parser.add_argument("--password", help="Password of AION user", default="spirent1234")
    parser.add_argument("--subdomain", help="AION subdomain", default="spirent")
    parser.add_argument("--config_path", help="Config path", default="")
    parser.add_argument("--update_policy", help="Update policy IfNotPresent|Always|VerifyExists", default="IfNotPresent")
    parser.add_argument("--lib_prefix", help="Library prefix name", default="")
    parser.add_argument("--kubeconfig", help="Kuberentes kubeconfig", default="")
    parser.add_argument("--kubeconfig_env", help="Kuberentes kubeconfig env name", default="k8s-config")
    parser.add_argument("--profile_ls_overrides", help="Landslide profile overrides", default="")
    args = parser.parse_args()
    main(args)
