#
# Copyright (c) 2023 by Spirent Communications Plc.
# All Rights Reserved.
#
# This software is confidential and proprietary to Spirent Communications Inc.
# No part of this software may be reproduced, transmitted, disclosed or used
# in violation of the Software License Agreement without the expressed
# written consent of Spirent Communications Inc.
#

from typing import Optional

import cloudsure
import requests

from cstest.utils.temeva import Temeva


class ClientApi:
    def __init__(self):
        self._projects: Optional[cloudsure.ProjectsApi] = None
        self._testcases: Optional[cloudsure.TestcasesApi] = None
        self._executions: Optional[cloudsure.ExecutionsApi] = None
        self._profiles: Optional[cloudsure.ProfilesApi] = None
        self._datafiles: Optional[cloudsure.DataFilesApi] = None

    @property
    def projects(self) -> cloudsure.ProjectsApi:
        if not self._projects:
            self._projects = cloudsure.ProjectsApi()
        return self._projects

    @property
    def testcases(self) -> cloudsure.TestcasesApi:
        if not self._testcases:
            self._testcases = cloudsure.TestcasesApi()
        return self._testcases

    @property
    def executions(self) -> cloudsure.ExecutionsApi:
        if not self._executions:
            self._executions = cloudsure.ExecutionsApi()
        return self._executions

    @property
    def profiles(self) -> cloudsure.ProfilesApi:
        if not self._profiles:
            self._profiles = cloudsure.ProfilesApi()
        return self._profiles

    @property
    def datafiles(self) -> cloudsure.DataFilesApi:
        if not self._datafiles:
            self._datafiles = cloudsure.DataFilesApi()
        return self._datafiles


class Client:
    def __init__(self, cs_url: str, aion_url: str, email: str, password: str, subdomain: str = "spirent"):
        self._cs_url = cs_url
        self._aion_url = aion_url
        self._email = email
        self._password = password
        self._subdomain = subdomain
        self._temeva: Optional[Temeva] = None
        self._api_client: Optional[cloudsure.ApiClient] = None
        self._api: Optional[ClientApi] = None

    def connect(self) -> None:
        if not self._api_client:
            temeva: Temeva
            try:
                # Get OAuth2 bearer token based on provided credentials
                temeva = Temeva(self._email, self._password, self._subdomain, base_url=self._aion_url)
            except Exception as e:
                print("Caught exception while getting Temeva OAuth2 token: " + repr(e))
                raise (e)

            cloudsure.configuration.host = f"{self._cs_url}/api"
            cloudsure.configuration.access_token = temeva.access_token()

            # send message with access and refresh token
            # url = cloudsure.configuration.host +
            #   f"/sessions?refresh_token={temeva.refresh_token()}&access_token={temeva.access_token()}"
            url = (
                cloudsure.configuration.host
                + f"/auth/token?refresh_token={temeva.refresh_token()}&access_token={temeva.access_token()}"
            )
            r = requests.get(url, headers={"Content-Type": "application/json"})
            if r.status_code != 200:
                raise RuntimeError("Unexpected response {}: {!r}".format(r.status_code, r.content))

            api_client = cloudsure.ApiClient()
            cloudsure.configuration.api_client = api_client

            self._temeva = temeva
            self._api = ClientApi()
            self._api_client = api_client

    @property
    def auth_headers(self) -> dict:
        if not self._temeva:
            raise Exception("connect must be called before getting auth_headers")
        return {
            "Content-Type": "application/json",
            "ACCEPT": "application/json",
            "AUTHORIZATION": "Bearer {}".format(self._temeva.access_token()),
        }

    @property
    def cs_url(self) -> str:
        return self._cs_url

    @property
    def api(self) -> ClientApi:
        if not self._api:
            raise Exception("call connect before using client api")
        return self._api
