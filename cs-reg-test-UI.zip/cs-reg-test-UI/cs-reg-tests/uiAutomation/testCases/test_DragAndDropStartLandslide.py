import time
import pytest
from selenium import webdriver
import os
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pageObjects.LoginPage import LoginPageClass
from pageObjects.LandingPage import LandingPageClass
from pageObjects.DashboardPage import DashboardPageClass
from pageObjects.ProfileBuilderPage import ProfileBuilderPageClass
from pageObjects.TestBuilderPage import TestBuilderPageClass
from pageObjects.WorkflowPage import WorkFlowPageClass
from pageObjects.ScenarioBuilder import ScenarioBuilderPageClass
from selenium.webdriver.common.action_chains import ActionChains
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select

# Set up Chrome options for headless mode
chrome_options = Options()
chrome_options.add_argument("--headless")  # Enable headless mode
chrome_options.add_argument("--disable-gpu")
driver = webdriver.Chrome(options=chrome_options)

base_url = ReadConfig.getApplicationURL()
username= ReadConfig.getusername()
password = ReadConfig.getpassword()
landslideServerIP = ReadConfig.getLandslideServerIP()
landslideUsername = ReadConfig.getLandslideUsername()
landslidePassword = ReadConfig.getLandslidePassword()
logger = LogGen.loggen()

def test_dragAndDropStartLandslide(setup):
    logger.info("*********Test Case 01 started************")
    driver = setup
    driver.get(base_url)
    driver.implicitly_wait(20)
    time.sleep(2)
    lp = LoginPageClass(driver)
    lp.provide_username(username)
    lp.provide_password(password)
    driver.maximize_window()
    lp.signedInCheckbox()
    lp.signInButton()
    logger.info("*********Signed In to cloudSure in AION************")
    time.sleep(2)
    act_title = driver.title
    # print(act_title)
    logger.warning("******Ttile is being verified in AION**********")
    if act_title == "Landing | AION":
        assert True
        # self.driver.close()
    else:
        driver.save_screenshot(".\\Screenshots\\" + "test_loginTitle.png")
        assert False
        # self.driver.close()

    logger.info("*********Title is verified in login page************")
    landpg = LandingPageClass(driver)
    time.sleep(5)
    logger.info("**********Moved to Landing Page********")
    landpg.aion_products_cloudsure()
    time.sleep(2)
    landpg.product_instance_cloudsure()
    landpg.launch_product_cloudsure()
    time.sleep(20)
    logger.info("*****Launched product is clicked from Landing Page*****")
    print("Launched cloudsure and moved to Dashboard page")
    driver.switch_to.window(driver.window_handles[1])
    time.sleep(20)
    print("Switched to new window")
    logger.info("*****New Window****")
    new_title1 = driver.title
    print(new_title1)
    dashbdpg = DashboardPageClass(driver)
    dashbdpg.profileBuilderAction()
    print("Profile Builder is clicked")
    time.sleep(2)
    profileBuilder = ProfileBuilderPageClass(driver)
    profileBuilder.createLoadGenAction()
    logger.info("*****Load Gen Created*****")
    profileBuilder.landslide_loadGen()
    logger.info("*****Landslide Clicked*****")

    import string
    import random  # define the random module
    S = 4  # number of characters in the string.
    # call random.choices() string module to find the string in Uppercase + numeric data.
    randomLoadGen_name = "LoadGen" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
    print("The randomly generated string is : " + str(randomLoadGen_name))  # print the random data
    profileBuilder.environment_name(str(randomLoadGen_name))
    print("LoadGen Name is given")
    profileBuilder.landslide_managerServer(landslideServerIP)
    time.sleep(2)
    profileBuilder.landslide_managerUsername(landslideUsername)
    profileBuilder.landslide_managerPassword(landslidePassword)
    profileBuilder.save_button()
    print("Load Generator profile is saved")
    time.sleep(4)
    # Create Blank Test Case
    dashbdpg = DashboardPageClass(driver)
    dashbdpg.testBuilderAction()
    print("Test Builder is clicked")
    logger.info("*****Test Builder is navigated to Build Test case from Scratch****")
    time.sleep(2)
    tbPage = TestBuilderPageClass(driver)
    tbPage.testBuilderBlankTestFromScratch()
    logger.info("*****Test bulder for Blank Test case is getting created*****")
    print("Blank Test case is ready to be created")
    tbPage.testBuilderProjectName("sanath_automation")
    tbPage.testBuilderProjectDropdown()
    # generate random string
    import string
    import random  # define the random module
    S = 10  # number of characters in the string.
    # call random.choices() string module to find the string in Uppercase + numeric data.
    testCaseranName = "TestCase" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
    print("The randomly generated string is : " + str(testCaseranName))  # print the random data
    tbPage.testBuilderTestName(str(testCaseranName))
    logger.info("***random data is feeded***")
    tbPage.testBuilderBlankTestSave()
    print("Moved to Workflow page")
    time.sleep(2)
    # Workflow actions
    wfPage = WorkFlowPageClass(driver)

    try:
        # Attempt to find the button element
        profile_button = driver.find_element(By.XPATH, "//div[contains(text(),'Profiles')]")

        # If the button is found, the assertion will pass
        assert profile_button.is_displayed(), "Button is present and displayed"
        print("Button is present on the page.")

    except NoSuchElementException:
        # If the button is not found, the assertion will fail
        print("Button is not present on the page.")

    # perform drag and drop for load gen
    lg_name = str(randomLoadGen_name)
    copied_lgname = lg_name
    print(copied_lgname)
    loadGen_Xpath = f"//div[contains(text(),'{copied_lgname}')]/../.."
    print("LG xpath is ", loadGen_Xpath)
    logger.info("*****Drag and drop of env starts****")
    time.sleep(10)
    # static wait to load the page
    source_LoadGen = driver.find_element(By.XPATH, loadGen_Xpath)
    target_LoadGen = driver.find_element(By.XPATH,"(//div[starts-with(@class,'drag-and-drop-util_droppable')])[2]")
    actions = ActionChains(driver)
    time.sleep(10)
    actions.click_and_hold(source_LoadGen)
    # Calculate the number of steps for a slow drag-and-drop
    steps = 10

    for _ in range(steps):
        # Calculate small offsets for each step
        offset_x = (target_LoadGen.location['x'] - source_LoadGen.location['x']) / steps
        offset_y = (target_LoadGen.location['y'] - source_LoadGen.location['y']) / steps
        # Move by offset
        actions.move_by_offset(offset_x, offset_y)
        # Add a small delay to make it slow
        actions.pause(0.1)
    # Release the mouse button to complete the drag-and-drop
    actions.release().perform()
    logger.info("*****LG dropped*****")
    time.sleep(20)
    print("Created Load Gen is dragged and dropped to right hand side")
    #Scroll to Blank Scenario
    element_to_scroll = driver.find_element(By.XPATH,"//div[contains(text(),'Blank Scenario')]")
    # Use JavaScript to scroll to the element
    driver.execute_script("arguments[0].scrollIntoView(true);", element_to_scroll)
    element_to_scroll.click()
    wfPage.actions_Menubar()
    #Reach to start landslide and drag and drop
    actions1 = ActionChains(driver)
    start_Actions = driver.find_element(By.XPATH, "//div[contains(text(),'Start')]")
    # Use JavaScript to scroll to the element
    driver.execute_script("arguments[0].scrollIntoView(true);", start_Actions)
    #start_Actions.click()
    target_BlankScenario = driver.find_element(By.XPATH,"//span[contains(text(),'Drag Available Actions from the left and drop them here!')]")
    driver.execute_script("arguments[0].scrollIntoView(true);", target_BlankScenario)
    actions1.click_and_hold(start_Actions)
    stepss = 10

    for _ in range(stepss):
        # Calculate small offsets for each step
        offset_x = (target_BlankScenario.location['x'] - start_Actions.location['x']) / steps
        offset_y = (target_BlankScenario.location['y'] - start_Actions.location['y']) / steps
        # Move by offset
        actions1.move_by_offset(offset_x, offset_y)
        # Add a small delay to make it slow
        actions1.pause(0.1)

    # Release the mouse button to complete the drag-and-drop
    actions1.release().perform()
    # actions1.drag_and_drop(start_Actions, target_BlankScenario).release().perform()
    time.sleep(20)
    print("Start Landslide is dragged and dropped to right hand side")
    basic_startLandslide = driver.find_element(By.XPATH,"//div[contains(text(),'Basic')]")
    driver.execute_script("arguments[0].scrollIntoView(true);", basic_startLandslide)
    basic_startLandslide.click()
    time.sleep(5)
    element_to_hover_over = driver.find_element(By.XPATH,"//*[starts-with(@class,'Styles.pillsWrapperContent')]/i")
    # Use ActionChains to perform the mouse hover
    action = ActionChains(driver)
    action.move_to_element(element_to_hover_over).perform()
    print("Start Landslide error message" , element_to_hover_over.text)
    logger.info("Collecting the list of Library ID")
    wfPage.libraryId_startLandslide_Dropdown()
    wfPage.libraryId_sms_Dropdown()
    print("SMS Dropdown selected")
    testServerID = driver.find_element(By.XPATH,"//label[contains(text(),'Test Server ID')]")
    driver.execute_script("arguments[0].scrollIntoView(true);", testServerID)
    time.sleep(10)
    wfPage.testSessionName_Dropdown()
    wfPage.testSessionName_Value()
    time.sleep(10)
    print("Test session name selected")
    print("Printing all the dropdown list for duration")
    duration_dropdown_element = driver.find_element(By.XPATH, "(//div[contains(text(),'Set Duration')])[1]")
    wfPage.startLandslide_Duration(10)  
    time.sleep(2)
    wfPage.testServerID()
    wfPage.testServerID_dropdown()
    time.sleep(10)
    print("Basic start landslide values are provided")
    logger.info("*****Start Landslide Basic operations performed*****")
    print("Advanced start landslide is in progress")
    #Performing Advance start landslide option
    sBuilder = ScenarioBuilderPageClass(driver)
    sBuilder.advanced_startLandslide()
    time.sleep(2)
    #move to Library id
    element_to_scroll_to = driver.find_element(By.XPATH, "//label[contains(text(),'Library ID')]/../following-sibling::button")
    # Use JavaScript to scroll to the element
    driver.execute_script("arguments[0].scrollIntoView(true);", element_to_scroll_to)
    wfPage.libraryId_startLandslide_Dropdown()
    wfPage.libraryId_sms_Dropdown()
    print("SMS Dropdown selected for Advanced")
    time.sleep(10)
    wfPage.testSessionName_Dropdown()
    wfPage.testSessionName_Value()
    time.sleep(10)
    print("Test session name selected")
    print("Printing all the dropdown list for duration")
    wfPage.startLandslide_Duration(10)  
    time.sleep(2)
    sBuilder.iteration_values(5)
    sBuilder.initialIntervalPeriodDropdown()
    sBuilder.initialIntervalPeriodValue()
    time.sleep(2)
    sBuilder.testServerID()
    sBuilder.testServerIDValues()
    time.sleep(10)
    print("Advanced values added")
    logger.info("*****Advanced start landslide values added*****")
    sBuilder.custom_startLandslide()
    sBuilder.custom_selectFile()
    sBuilder.custom_TestSessionOverrideConfigFile()
    sBuilder.update_TestSessionOverrideConfigFile()
    print("Template is added for custom start Landslide")
    #Custom changes
    element_to_scroll_to = driver.find_element(By.XPATH, "//label[contains(text(),'Library ID')]/../following-sibling::button")
    # Use JavaScript to scroll to the element
    driver.execute_script("arguments[0].scrollIntoView(true);", element_to_scroll_to)
    wfPage.libraryId_startLandslide_Dropdown()
    wfPage.libraryId_sms_Dropdown()
    print("SMS Dropdown selected for Custom")
    time.sleep(10)
    wfPage.testSessionName_Dropdown()
    wfPage.testSessionName_Value()
    time.sleep(10)
    print("Test session name selected for custom")
    wfPage.startLandslide_Duration(10)  
    time.sleep(2)
    sBuilder.iteration_values(5)
    sBuilder.formatDropdown()
    sBuilder.formatDropdownValues()
    sBuilder.initialIntervalPeriodDropdown()
    sBuilder.initialIntervalPeriodValue()
    time.sleep(2)
    sBuilder.testServerID()
    sBuilder.testServerIDValues()
    time.sleep(10)
    print("Custom values provided")
