import time

import pytest
from selenium import webdriver
import os

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from pageObjects.LoginPage import LoginPageClass
from pageObjects.LandingPage import LandingPageClass
from pageObjects.DashboardPage import DashboardPageClass
from pageObjects.ProfileBuilderPage import ProfileBuilderPageClass
from pageObjects.TestBuilderPage import TestBuilderPageClass
from pageObjects.WorkflowPage import WorkFlowPageClass
from pageObjects.ScenarioBuilder import ScenarioBuilderPageClass
from selenium.webdriver.common.action_chains import ActionChains
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options

# Set up Chrome options for headless mode
chrome_options = Options()
chrome_options.add_argument("--headless")  # Enable headless mode
chrome_options.add_argument("--disable-gpu")


#class Test_00xxx_DragAndDropEnvValidation:
base_url = ReadConfig.getApplicationURL()
username= ReadConfig.getusername()
password = ReadConfig.getpassword()
namespace = ReadConfig.getNamespace()



logger = LogGen.loggen()


def test_impairment_RateLimit(setup):
    logger.info("*********Test Case 01 started************")
    driver = setup
    driver.get(base_url)
    time.sleep(2)
    lp = LoginPageClass(driver)
    lp.provide_username(username)
    lp.provide_password(password)
    driver.maximize_window()
    driver.implicitly_wait(10)
    lp.signedInCheckbox()
    lp.signInButton()
    logger.info("*********Signed In to cloudSure in AION************")
    time.sleep(2)

    act_title=driver.title
    #print(act_title)
    logger.warning("******Ttile is being verified in AION**********")
    if act_title == "Landing | AION" :
        assert True
        #self.driver.close()
    else:
        driver.save_screenshot(".\\Screenshots\\"+"test_loginTitle.png")
        assert False
        #self.driver.close()

    logger.info("*********Title is verified in login page************")
    landpg = LandingPageClass(driver)
    time.sleep(5)
    logger.info("**********Moved to Landing Page********")
    landpg.aion_products_cloudsure()
    time.sleep(2)
    landpg.product_instance_cloudsure()
    landpg.launch_product_cloudsure()
    time.sleep(10)
    logger.info("*****Launched product is clicked from Landing Page*****")
    print("Launched cloudsure and moved to Dashboard page")
    driver.switch_to.window(driver.window_handles[1])
    time.sleep(8)
    print("Switched to new window")
    logger.info("*****New Window****")
    new_title1 = driver.title
    print(new_title1)
    dashbdpg = DashboardPageClass(driver)
    dashbdpg.profileBuilderAction()
    print("Profile Builder is clicked")
    profileBuilder = ProfileBuilderPageClass(driver)
    profileBuilder.createEnvAction()
    profileBuilder.kubernetes_env()

    import string
    import random  # define the random module
    S = 4  # number of characters in the string.
    # call random.choices() string module to find the string in Uppercase + numeric data.
    randomEnv_name = "Env_Auto" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
    print("The randomly generated string is : " + str(randomEnv_name))  # print the random data
    profileBuilder.environment_name(str(randomEnv_name))
    print("Env name is given randomly while creating Profiles for Environment")
    time.sleep(8)
    absolute_path = os.path.abspath("C:/Users/SChakrabor/cs-reg-test-UI/cs-reg-tests/uiAutomation/TestData/ocp01.yaml")
    # upload_file = os.path.join(os.getcwd(), relative_path)
    logger.info("****File upload starts for Environment")
    file_input = driver.find_element(By.CSS_SELECTOR,"input[type='file']")
    file_input.send_keys(absolute_path)
    logger.info("****File uploaded for Environment")


    time.sleep(5)
    print("KubeConfig file uploaded ")
    time.sleep(2)
    #Assertions
    savebutton = driver.find_element(By.XPATH, "//div[contains(text(),'Save')]")

    # Use WebDriverWait to wait for the button to be clickable
    try:
        # Wait for a maximum of 10 seconds for the button to be clickable
        savebutton = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//div[contains(text(),'Save')]"))
        )

        # If the execution reaches here, the button is clickable
        print("Button is clickable. Proceed with interaction.")

        # Perform any actions on the button (e.g., click)
        #savebutton.click()
        print("Save button is clickable")

    except Exception as e:
        # If an exception occurs, the button is not clickable within the specified time
        print(f"Save Button is not clickable. Exception: {e}")

    profileBuilder.save_button()
    logger.info("******Save Button is clicked******")
    print("Env is saved and created")
    time.sleep(20)

    #Create Blank Test Case
    dashbdpg = DashboardPageClass(driver)
    dashbdpg.testBuilderAction()
    print("Test Builder is clicked")
    logger.info("*****Test Builder is navigated to Build Test case from Scratch****")
    time.sleep(2)
    tbPage = TestBuilderPageClass(driver)
    tbPage.testBuilderBlankTestFromScratch()
    logger.info("*****Test bulder for Blank Test case is getting created*****")
    print("Blank Test case is ready to be created")
    tbPage.testBuilderProjectName("sanath_automation")
    tbPage.testBuilderProjectDropdown()
    #generate random string
    import string
    import random  # define the random module
    S = 10  # number of characters in the string.
    # call random.choices() string module to find the string in Uppercase + numeric data.
    testCaseranName = "TestCase" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
    print("The randomly generated string is : " + str(testCaseranName))  # print the random data
    tbPage.testBuilderTestName(str(testCaseranName))
    logger.info("***random data is feeded***")
    tbPage.testBuilderBlankTestSave()
    print("Moved to Workflow page")
    time.sleep(2)

    #Workflow actions
    wfPage = WorkFlowPageClass(driver)
    try:
        # Attempt to find the button element
        profile_button = driver.find_element(By.XPATH,"//div[contains(text(),'Profiles')]")

        # If the button is found, the assertion will pass
        assert profile_button.is_displayed(), "Button is present and displayed"
        print("Button is present on the page.")

    except NoSuchElementException:
        # If the button is not found, the assertion will fail
        print("Button is not present on the page.")

    #perform drag and drop for env
    env_name = str(randomEnv_name)
    copied_envname = env_name
    print(copied_envname)
    env_Xpath = f"//div[contains(text(),'{copied_envname}')]/../.."
    print("Env xpath is " ,env_Xpath)
    logger.info("*****Drag and drop of env starts****")
    time.sleep(10)
    #static wait to load the page
    source_env = driver.find_element(By.XPATH,env_Xpath)
    target_env = driver.find_element(By.XPATH,"(//div[starts-with(@class,'drag-and-drop-util_droppable')])[1]")
    # Perform the drag-and-drop operation
    actions = ActionChains(driver)
    # 29 Jan --> actions.drag_and_drop(source_env, target_env).release().perform()
    #actions.click_and_hold(source_env).drag_and_drop(source_env, target_env).release().pause(20).perform()
    time.sleep(10)
    #Changes from here
    actions.click_and_hold(source_env)
    # Calculate the number of steps for a slow drag-and-drop
    steps = 10
    for _ in range(steps):
        # Calculate small offsets for each step
        offset_x = (target_env.location['x'] - source_env.location['x']) / steps
        offset_y = (target_env.location['y'] - source_env.location['y']) / steps

        # Move by offset
        actions.move_by_offset(offset_x, offset_y)

        # Add a small delay to make it slow
        actions.pause(0.1)

    # Release the mouse button to complete the drag-and-drop
    actions.release().perform()
    time.sleep(25)
    print("Created Env is dragged and dropped to right hand side")
    ns_env = driver.find_element(By.XPATH,"//div[contains(text(),'Namespace')]/../div[starts-with(@class,'button')]")
    assert ns_env.is_displayed(), "Namespace"


    # POD delete test cases
    #Scroll to Blank Scenario
    element_to_scroll = driver.find_element(By.XPATH,"//div[contains(text(),'Blank Scenario')]")
    # Use JavaScript to scroll to the element
    driver.execute_script("arguments[0].scrollIntoView(true);", element_to_scroll)
    element_to_scroll.click()
    wfPage.actions_Menubar()
    #Reach to start landslide and drag and drop
    actions1 = ActionChains(driver)
    rateLimit_Actions = driver.find_element(By.XPATH, "//div[contains(text(),'Rate Limit')]")
    # Use JavaScript to scroll to the element
    driver.execute_script("arguments[0].scrollIntoView(true);", rateLimit_Actions)
    #start_Actions.click()
    target_BlankScenario = driver.find_element(By.XPATH,"//span[contains(text(),'Drag Available Actions from the left and drop them here!')]")
    driver.execute_script("arguments[0].scrollIntoView(true);", target_BlankScenario)
    actions1.click_and_hold(rateLimit_Actions)
    stepss = 10

    for _ in range(stepss):
        # Calculate small offsets for each step
        offset_x = (target_BlankScenario.location['x'] - rateLimit_Actions.location['x']) / steps
        offset_y = (target_BlankScenario.location['y'] - rateLimit_Actions.location['y']) / steps
        # Move by offset
        actions1.move_by_offset(offset_x, offset_y)
        # Add a small delay to make it slow
        actions1.pause(0.1)

    # Release the mouse button to complete the drag-and-drop
    actions1.release().perform()
    # actions1.drag_and_drop(start_Actions, target_BlankScenario).release().perform()
    time.sleep(20)
    print("Rate limit is dragged and dropped to right hand side")
    logger.info("*****Drag and drop of Rate limit Impairment is completed****")

    element_to_scroll_BlankScenario = driver.find_element(By.XPATH,"//span[contains(text(),'Blank Scenario')]")
    # Use JavaScript to scroll to the element
    driver.execute_script("arguments[0].scrollIntoView(true);", element_to_scroll_BlankScenario)
    time.sleep(5)
    logger.info("*****Blank Scenario is reached******")
    sBuilder = ScenarioBuilderPageClass(driver)
    sBuilder.namespace_value(namespace)
    sBuilder.namespace_list()
    sBuilder.podSelectionDropdown()
    sBuilder.podSelectionName()
    sBuilder.selectPodNameDropdown()
    sBuilder.selectFirstPodName()
    print("Pod Selected")
    logger.info("******POD selected for Rate limit*****")
    time.sleep(2)
    sBuilder.containerSelectionDropdown()
    sBuilder.podSelectionName()
    sBuilder.selectContainerNameDropdown()
    sBuilder.selectFirstPodName()
    time.sleep(5)


    sBuilder.addTarget()
    time.sleep(10)
    # scroll_to_affectedPod = driver.find_element(By.XPATH,"//*[contains(text(),'Affected Pods')]/../div/div/div/div")
    # driver.execute_script("arguments[0].scrollIntoView(true);", scroll_to_affectedPod)
    #sBuilder.affectedPod("1")
    sBuilder.networkDevice("eth0")
    sBuilder.RateLimit_mbits("1")
    sBuilder.Duration_sec("50")
    time.sleep(5)
    scroll_to_playButton = driver.find_element(By.XPATH,"//*[starts-with(@class,'run-button-module_icon')]")
    driver.execute_script("arguments[0].scrollIntoView(true);", scroll_to_playButton)
    if scroll_to_playButton.is_enabled() :
        scroll_to_playButton.click()
        print("Test Case execution started")
    else:
        print("Run button is disabled")
    time.sleep(60)


    








    
    
