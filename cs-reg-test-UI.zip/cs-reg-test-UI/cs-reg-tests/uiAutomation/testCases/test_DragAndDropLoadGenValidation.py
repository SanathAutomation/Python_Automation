import time
import pytest
from selenium import webdriver
import os
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pageObjects.LoginPage import LoginPageClass
from pageObjects.LandingPage import LandingPageClass
from pageObjects.DashboardPage import DashboardPageClass
from pageObjects.ProfileBuilderPage import ProfileBuilderPageClass
from pageObjects.TestBuilderPage import TestBuilderPageClass
from pageObjects.WorkflowPage import WorkFlowPageClass
from selenium.webdriver.common.action_chains import ActionChains
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select

# Set up Chrome options for headless mode
chrome_options = Options()
chrome_options.add_argument("--headless")  # Enable headless mode
chrome_options.add_argument("--disable-gpu")

base_url = ReadConfig.getApplicationURL()
username= ReadConfig.getusername()
password = ReadConfig.getpassword()
landslideServerIP = ReadConfig.getLandslideServerIP()
landslideUsername = ReadConfig.getLandslideUsername()
landslidePassword = ReadConfig.getLandslidePassword()
logger = LogGen.loggen()

def test_ProfileBuilder_CreateLoadGenerator(setup):
    logger.info("*********Test Case 01 started************")
    driver = setup
    driver.get(base_url)
    time.sleep(2)
    lp = LoginPageClass(driver)
    lp.provide_username(username)
    lp.provide_password(password)
    driver.maximize_window()
    lp.signedInCheckbox()
    lp.signInButton()
    logger.info("*********Signed In to cloudSure in AION************")
    time.sleep(2)
    act_title=driver.title
    #print(act_title)
    logger.warning("******Ttile is being verified in AION**********")
    if act_title == "Landing | AION" :
        assert True
        #driver.close()
    else:
        driver.save_screenshot(".\\Screenshots\\"+"test_loginTitle.png")
        assert False
        #driver.close()

    logger.info("*********Title is verified in login page************")
    landpg = LandingPageClass(driver)
    time.sleep(5)
    logger.info("**********Moved to Landing Page********")
    landpg.aion_products_cloudsure()
    time.sleep(2)
    landpg.product_instance_cloudsure()
    landpg.launch_product_cloudsure()
    time.sleep(20)
    logger.info("*****Launched product is clicked from Landing Page*****")
    print("Launched cloudsure and moved to Dashboard page")
    driver.switch_to.window(driver.window_handles[1])
    time.sleep(10)
    print("Switched to new window")
    logger.info("*****New Window****")
    new_title1 = driver.title
    print(new_title1)
    dashbdpg = DashboardPageClass(driver)
    dashbdpg.profileBuilderAction()
    print("Profile Builder is clicked")
    time.sleep(2)
    profileBuilder = ProfileBuilderPageClass(driver)
    profileBuilder.createLoadGenAction()
    profileBuilder.landslide_loadGen()
    import string
    import random  # define the random module
    S = 4  # number of characters in the string.
    # call random.choices() string module to find the string in Uppercase + numeric data.
    randomLoadGen_name = "LoadGen" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
    print("The randomly generated string is : " + str(randomLoadGen_name))  # print the random data
    profileBuilder.environment_name(str(randomLoadGen_name))
    print("LoadGen Name is given")
    profileBuilder.landslide_managerServer(landslideServerIP)
    time.sleep(2)
    profileBuilder.landslide_managerUsername(landslideUsername)
    profileBuilder.landslide_managerPassword(landslidePassword)
    profileBuilder.save_button()
    print("Load Generator profile is saved")
    time.sleep(4)
    #Create Blank Test Case
    dashbdpg = DashboardPageClass(driver)
    dashbdpg.testBuilderAction()
    print("Test Builder is clicked")
    logger.info("*****Test Builder is navigated to Build Test case from Scratch****")
    time.sleep(2)
    tbPage = TestBuilderPageClass(driver)
    tbPage.testBuilderBlankTestFromScratch()
    logger.info("*****Test bulder for Blank Test case is getting created*****")
    print("Blank Test case is ready to be created")
    tbPage.testBuilderProjectName("sanath_automation")
    tbPage.testBuilderProjectDropdown()
    #generate random string
    import string
    import random  # define the random module
    S = 10  # number of characters in the string.
    # call random.choices() string module to find the string in Uppercase + numeric data.
    testCaseranName = "TestCase" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
    print("The randomly generated string is : " + str(testCaseranName))  # print the random data

    tbPage.testBuilderTestName(str(testCaseranName))
    logger.info("***random data is feeded***")
    tbPage.testBuilderBlankTestSave()
    print("Moved to Workflow page")
    time.sleep(2)
    #Workflow actions
    wfPage = WorkFlowPageClass(driver)
    try:
        # Attempt to find the button element
        profile_button = driver.find_element(By.XPATH,"//div[contains(text(),'Profiles')]")

        # If the button is found, the assertion will pass
        assert profile_button.is_displayed(), "Button is present and displayed"
        print("Button is present on the page.")

    except NoSuchElementException:
        # If the button is not found, the assertion will fail
        print("Button is not present on the page.")

    #perform drag and drop for load gen
    lg_name = str(randomLoadGen_name)
    copied_lgname = lg_name
    print(copied_lgname)
    loadGen_Xpath = f"//div[contains(text(),'{copied_lgname}')]/../.."
    print("LG xpath is " ,loadGen_Xpath)
    logger.info("*****Drag and drop of env starts****")
    time.sleep(10)
    #static wait to load the page
    source_LoadGen = driver.find_element(By.XPATH,loadGen_Xpath)
    target_LoadGen = driver.find_element(By.XPATH,"(//div[starts-with(@class,'drag-and-drop-util_droppable')])[2]")
    actions = ActionChains(driver)
    # 29 Jan --> actions.drag_and_drop(source_env, target_env).release().perform()
    #actions.click_and_hold(source_env).drag_and_drop(source_env, target_env).release().pause(20).perform()
    time.sleep(10)
    #Changes from here
    actions.click_and_hold(source_LoadGen)
    # Calculate the number of steps for a slow drag-and-drop
    steps = 10

    for _ in range(steps):
        # Calculate small offsets for each step
        offset_x = (target_LoadGen.location['x'] - source_LoadGen.location['x']) / steps
        offset_y = (target_LoadGen.location['y'] - source_LoadGen.location['y']) / steps

        # Move by offset
        actions.move_by_offset(offset_x, offset_y)

        # Add a small delay to make it slow
        actions.pause(0.1)

    # Release the mouse button to complete the drag-and-drop
    actions.release().perform()
    time.sleep(20)
    print("Created Load Gen is dragged and dropped to right hand side")
    #Assertions for Server IP
    assert driver.find_element(By.XPATH,"(//span[starts-with(@class,'load-generator-block_value')])[1]").is_displayed()
    assert driver.find_element(By.XPATH,"(//span[starts-with(@class,'load-generator-block_value')])[1]").text =="10.109.187.197"
    # Assertions for Port Number
    assert driver.find_element(By.XPATH,"(//span[starts-with(@class,'load-generator-block_value')])[2]").is_displayed()
    assert driver.find_element(By.XPATH,"(//span[starts-with(@class,'load-generator-block_value')])[2]").text == "8080"
    # Assertions for Username
    assert driver.find_element(By.XPATH,"(//span[starts-with(@class,'load-generator-block_value')])[3]").is_displayed()
    assert driver.find_element(By.XPATH,"(//span[starts-with(@class,'load-generator-block_value')])[3]").text == "sms"
    assert "Available" in driver.find_element(By.XPATH,"//div[starts-with(@class,'available-status_container')]").text
    logger.info("*****Assertions passed****")
    print("Assertions passed")
    wfPage.lgViewConfigurations()
    time.sleep(5)
    logger.info("*****Configurations****")
    # Selecting sms from Library dropdown
    wfPage.lgLibraryDropdown()
    time.sleep(2)
    logger.info("*****Library dropdown****")
    wfPage.smsLibraryDropdown()
    time.sleep(1)
    logger.info("*****sms****")
    wfPage.lgTestSessionDropdown()
    time.sleep(2)
    logger.info("*****Test session dropdown****")
    wfPage.firstTestSessionDropdown()
    time.sleep(2)
    logger.info("*****First test session****")
    wfPage.testSessionPreviewFile()
    time.sleep(4)
    logger.info("*****Preview file****")
    wfPage.testSessionCancel()
    wfPage.lgHamburger()
    wfPage.removeLG()
    time.sleep(3)
    wfPage.remove_env_warning()
    time.sleep(5)
    print("LG is removed from the workflow page")
