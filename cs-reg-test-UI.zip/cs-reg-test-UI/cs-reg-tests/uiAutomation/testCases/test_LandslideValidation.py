import time
import pytest
from selenium import webdriver
import os
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pageObjects.LoginPage import LoginPageClass
from pageObjects.LandingPage import LandingPageClass
from pageObjects.DashboardPage import DashboardPageClass
from pageObjects.ProfileBuilderPage import ProfileBuilderPageClass
from pageObjects.TestBuilderPage import TestBuilderPageClass
from pageObjects.WorkflowPage import WorkFlowPageClass
from selenium.webdriver.common.action_chains import ActionChains
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options

# Set up Chrome options for headless mode
chrome_options = Options()
chrome_options.add_argument("--headless")  # Enable headless mode
chrome_options.add_argument("--disable-gpu")

base_url = ReadConfig.getApplicationURL()
username= ReadConfig.getusername()
password = ReadConfig.getpassword()
logger = LogGen.loggen()

def test_ProfileBuilder_CreateEnvironment(setup):
    logger.info("*********Test Case 01 started************")
    driver = setup
    driver.get(base_url)
    time.sleep(2)
    lp = LoginPageClass(driver)
    lp.provide_username(username)
    lp.provide_password(password)
    driver.maximize_window()
    lp.signedInCheckbox()
    lp.signInButton()
    logger.info("*********Signed In to cloudSure in AION************")
    time.sleep(2)
    act_title=driver.title
    #print(act_title)
    logger.warning("******Ttile is being verified in AION**********")
    if act_title == "Landing | AION" :
        assert True
        #driver.close()
    else:
        driver.save_screenshot(".\\Screenshots\\"+"test_loginTitle.png")
        assert False
        #driver.close()

    logger.info("*********Title is verified in login page************")
    landpg = LandingPageClass(driver)
    time.sleep(5)
    logger.info("**********Moved to Landing Page********")
    landpg.aion_products_cloudsure()
    time.sleep(2)
    landpg.product_instance_cloudsure()
    landpg.launch_product_cloudsure()
    time.sleep(20)
    logger.info("*****Launched product is clicked from Landing Page*****")
    print("Launched cloudsure and moved to Dashboard page")
    driver.switch_to.window(driver.window_handles[1])
    time.sleep(10)
    print("Switched to new window")
    logger.info("*****New Window****")
    new_title1 = driver.title
    print(new_title1)
    dashbdpg = DashboardPageClass(driver)
    dashbdpg.profileBuilderAction()
    print("Profile Builder is clicked")
    profileBuilder = ProfileBuilderPageClass(driver)
    profileBuilder.createEnvAction()
    profileBuilder.kubernetes_env()
    import string
    import random  # define the random module
    S = 4  # number of characters in the string.
    # call random.choices() string module to find the string in Uppercase + numeric data.
    randomEnv_name = "Env_Auto" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
    print("The randomly generated string is : " + str(randomEnv_name))  # print the random data
    profileBuilder.environment_name(str(randomEnv_name))
    print("Env name is given randomly while creating Profiles for Environment")
    time.sleep(5)
    upload_file = os.path.abspath(
        os.path.join(os.path.dirname("C:/Users/SChakrabor/keyAutomation/TestData/"), "",
                        "Kubeconf.yaml"))

    file_input = driver.find_element(By.CSS_SELECTOR, "input[type='file']")
    file_input.send_keys(upload_file)
    time.sleep(5)
    print("KubeConfig file uploaded ")
    time.sleep(2)
    #Assertions
    savebutton = driver.find_element(By.XPATH, "//div[contains(text(),'Save')]")
    # Use WebDriverWait to wait for the button to be clickable
    try:
        # Wait for a maximum of 10 seconds for the button to be clickable
        savebutton = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//div[contains(text(),'Save')]"))
        )

        # If the execution reaches here, the button is clickable
        print("Button is clickable. Proceed with interaction.")

        # Perform any actions on the button (e.g., click)
        #savebutton.click()
        print("Save button is clickable")

    except Exception as e:
        # If an exception occurs, the button is not clickable within the specified time
        print(f"Save Button is not clickable. Exception: {e}")

    profileBuilder.save_button()
    print("Env is saved and created")
    time.sleep(5)
    # Create LOad Gen
    dashbdpg = DashboardPageClass(driver)
    dashbdpg.profileBuilderAction()
    print("Profile Builder is clicked")
    #profileBuilder = ProfileBuilderPageClass(driver)
    profileBuilder.createLoadGenAction()
    profileBuilder.landslide_loadGen()
    import string
    import random  # define the random module
    S = 4  # number of characters in the string.
    # call random.choices() string module to find the string in Uppercase + numeric data.
    randomLoadGen_name = "LoadGen" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
    print("The randomly generated string is : " + str(randomLoadGen_name))  # print the random data
    profileBuilder.environment_name(str(randomLoadGen_name))
    print("LoadGen Name is given")
    profileBuilder.landslide_managerServer("10.109.187.197")
    time.sleep(2)
    profileBuilder.landslide_managerUsername("sms")
    profileBuilder.landslide_managerPassword("a1b2c3d4")
    profileBuilder.save_button()
    print("Load Generator profile is saved")
    time.sleep(5)
    #Create Blank Test Case
    dashbdpg = DashboardPageClass(driver)
    dashbdpg.testBuilderAction()
    print("Test Builder is clicked")
    logger.info("*****Test Builder is navigated to Build Test case from Scratch****")
    time.sleep(2)
    tbPage = TestBuilderPageClass(driver)
    tbPage.testBuilderBlankTestFromScratch()
    logger.info("*****Test bulder for Blank Test case is getting created*****")
    print("Blank Test case is ready to be created")
    tbPage.testBuilderProjectName("sanath_automation")
    tbPage.testBuilderProjectDropdown()
    #generate random string
    import string
    import random  # define the random module
    S = 10  # number of characters in the string.
    # call random.choices() string module to find the string in Uppercase + numeric data.
    testCaseranName = "TestCase" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
    print("The randomly generated string is : " + str(testCaseranName))  # print the random data
    tbPage.testBuilderTestName(str(testCaseranName))
    logger.info("***random data is feeded***")
    tbPage.testBuilderBlankTestSave()
    print("Moved to Workflow page")
    time.sleep(2)
    #Workflow actions
    wfPage = WorkFlowPageClass(driver)
    try:
        # Attempt to find the button element
        profile_button = driver.find_element(By.XPATH,"//div[contains(text(),'Profiles')]")

        # If the button is found, the assertion will pass
        assert profile_button.is_displayed(), "Button is present and displayed"
        print("Button is present on the page.")

    except NoSuchElementException:
        # If the button is not found, the assertion will fail
        print("Button is not present on the page.")

    #perform drag and drop for env
    env_name = str(randomEnv_name)
    copied_envname = env_name
    print(copied_envname)
    env_Xpath = f"//div[contains(text(),'{copied_envname}')]"
    print("Env xpath is " ,env_Xpath)
    logger.info("*****Drag and drop of env starts****")
    time.sleep(5)
    #static wait to load the page
    source_env = driver.find_element(By.XPATH,env_Xpath)
    target_env = driver.find_element(By.XPATH,"//div[contains(text(),'Drag an Environment Profile from the left panel and drop it here!')]")
    # Perform the drag-and-drop operation
    actions = ActionChains(driver)
    actions.drag_and_drop(source_env, target_env).perform()
    time.sleep(5)
    print("Created Env is dragged and dropped to right hand side")
