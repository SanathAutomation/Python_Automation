import time
import pytest
from selenium import webdriver
import os
from pageObjects.LoginPage import LoginPageClass
from pageObjects.LandingPage import LandingPageClass
from pageObjects.DashboardPage import DashboardPageClass
from pageObjects.ProfileBuilderPage import ProfileBuilderPageClass
from pageObjects.TestBuilderPage import TestBuilderPageClass
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from selenium.webdriver.common.by import By

base_url = ReadConfig.getApplicationURL()
username= ReadConfig.getusername()
password = ReadConfig.getpassword()
logger = LogGen.loggen()

def test_ProfileBuilder_CreateLoadGenerator(setup):
    logger.info("*********Test Case 01 started************")
    driver = setup
    driver.get(base_url)
    time.sleep(2)
    lp = LoginPageClass(driver)
    lp.provide_username(username)
    lp.provide_password(password)
    driver.maximize_window()
    lp.signedInCheckbox()
    lp.signInButton()
    logger.info("*********Signed In to cloudSure in AION************")
    time.sleep(2)
    act_title=driver.title
    #print(act_title)
    logger.warning("******Ttile is being verified in AION**********")
    if act_title == "Landing | AION" :
        assert True
        #driver.close()
    else:
        driver.save_screenshot(".\\Screenshots\\"+"test_loginTitle.png")
        assert False
        #driver.close()

    logger.info("*********Title is verified in login page************")
    landpg = LandingPageClass(driver)
    time.sleep(5)
    logger.info("**********Moved to Landing Page********")
    landpg.aion_products_cloudsure()
    time.sleep(2)
    landpg.product_instance_cloudsure()
    landpg.launch_product_cloudsure()
    time.sleep(20)
    logger.info("*****Launched product is clicked from Landing Page*****")
    print("Launched cloudsure and moved to Dashboard page")
    driver.switch_to.window(driver.window_handles[1])
    time.sleep(10)
    print("Switched to new window")
    logger.info("*****New Window****")
    new_title1 = driver.title
    print(new_title1)
    dashbdpg = DashboardPageClass(driver)
    dashbdpg.profileBuilderAction()
    print("Profile Builder is clicked")
    profileBuilder = ProfileBuilderPageClass(driver)
    profileBuilder.createLoadGenAction()
    profileBuilder.landslide_loadGen()
    import string
    import random  # define the random module
    S = 4  # number of characters in the string.
    # call random.choices() string module to find the string in Uppercase + numeric data.
    randomLoadGen_name = "LoadGen" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=S))
    print("The randomly generated string is : " + str(randomLoadGen_name))  # print the random data
    profileBuilder.environment_name(str(randomLoadGen_name))
    print("LoadGen Name is given")
    profileBuilder.landslide_managerServer("10.109.187.197")
    time.sleep(2)
    profileBuilder.landslide_managerUsername("sms")
    profileBuilder.landslide_managerPassword("a1b2c3d4")
    profileBuilder.save_button()
    print("Load Generator profile is saved")
