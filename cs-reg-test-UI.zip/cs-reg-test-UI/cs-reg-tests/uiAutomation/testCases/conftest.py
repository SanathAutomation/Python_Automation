import pytest
#from selenium import Service
from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.firefox.options import Options as FirefoxOptions
#from selenium.webdriver.firefox.service import Service

# @pytest.fixture()
# def setup(browser):
#     if browser=='edge':
#         driver=webdriver.Edge()
#         print("Launching Edge browser.........")
#     elif browser=='firefox':
#         driver = webdriver.Firefox()
#         print("Launching firefox browser.........")
#     else:
#         driver = webdriver.Chrome()
#         print("Launching chrome browser.........")
#     return driver



@pytest.fixture()
def setup(browser):
    if browser == 'edge':
        # Set up Chrome options for headless mode
        edge_options = Options()
        edge_options.add_argument('--headless')  # Enable headless mode
        driver = webdriver.Edge(options=edge_options)
        print("Launching Edge browser in headless mode.........")
    elif browser == 'firefox':

        # Set up Firefox options for headless mode
        # Define options for Firefox
        firefox_options = FirefoxOptions()
        firefox_options.add_argument('--headless')  # Enable headless mode
        firefox_options.add_argument('--no-sandbox')
        #firefox_options.add_argument('--port' , '4444')
        # Create the Firefox WebDriver instance
        driver = webdriver.Firefox(options=firefox_options)
        print("Launching firefox browser in headless mode.........")
    else:
        chrome_options = Options()
        #chrome_options.add_argument('--headless' )
        chrome_options.add_argument('--headless' )  # Enable headless mode
        chrome_options.add_argument('--no-sandbox' )
        driver = webdriver.Chrome(options=chrome_options)
        print("Launching chrome browser in headless mode.........")
    return driver    

def pytest_addoption(parser):    # This will get the value from CLI /hooks
    parser.addoption("--browser")

@pytest.fixture()
def browser(request):  # This will return the Browser value to setup method
    return request.config.getoption("--browser")
     
