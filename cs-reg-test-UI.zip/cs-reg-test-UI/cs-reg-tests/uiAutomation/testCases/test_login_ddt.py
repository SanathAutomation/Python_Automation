import time
import pytest
from selenium import webdriver
from pageObjects.LoginPage import LoginPageClass
from pageObjects.LandingPage import LandingPageClass
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from utilities import XLUtils

base_url = ReadConfig.getApplicationURL()
path = ".//TestData/TestData.xlsx"
logger = LogGen.loggen()

def test_login_ddt(setup):
    logger.info("*********Test Case ddt started************")
    driver = setup
    driver.get(base_url)
    lp = LoginPageClass(driver)
    landpg = LandingPageClass(driver)
    rows = XLUtils.getRowCount(path,'Sheet1')
    print("Number of rows ", rows)
    lst_status = []
    for r in range(2,rows+1):
        username = XLUtils.readData(path,'Sheet1',r,1)
        password = XLUtils.readData(path, 'Sheet1', r, 2)
        exp = XLUtils.readData(path, 'Sheet1', r, 3)
        time.sleep(5)
        lp.provide_username(username)
        lp.provide_password(password)
        lp.signedInCheckbox()
        lp.signInButton()
        time.sleep(2)
        logger.info("*****LOGIN TO CLOUDSURE PAGE********")

        act_title = driver.title
        # print(act_title)
        logger.warning("******Title is being verified in AION**********")
        if act_title == "Landing | AION":
            assert True
            # driver.close()
        else:
            driver.save_screenshot(".\\Screenshots\\" + "test_loginTitle.png")
            assert False

        if exp == "Pass" :
            logger.info("*****Passed****")
            lst_status.append("Pass")
            landpg.goto_userAccount()
            time.sleep(2)
            landpg.signOut_Button()

        elif exp == "Fail" :
            logger.info("*****Passed Negative Scenario***")
            lst_status.append("Pass")
            landpg.goto_userAccount()
            time.sleep(2)
            landpg.signOut_Button()

        if "Fail" not in lst_status :
            logger.info("*****Login DDT Passed****")
            driver.close()
            assert True

        else:
            logger.info("****Login DDT Failed***")
            driver.close()
            assert False

    logger.info("*****End of DDT login Test****")
