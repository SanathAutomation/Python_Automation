import time

from selenium.webdriver.common.by import By
class ProfileBuilderPageClass:
    env_create_Xpath = "(//div[starts-with(@class,'select-profile-template-block_profileItemLabel')])[1]"
    loadGen_create_Xpath = "//div[contains(text(),'Load Generator')]"
    scenario_create_Xpath = "(//div[starts-with(@class,'select-profile-template-block_profileItemLabel')])[3]"
    scoringAndAnalytics_create_Xpath = "(//div[starts-with(@class,'select-profile-template-block_profileItemLabel')])[4]"
    env_Kubernetes = "//div[contains(text(),'KUBERNETES')]"
    loadGen_Landslide_Xpath = "//div[contains(text(),'LANDSLIDE')]"
    env_Name = "(//input[@type='text'])[2]"
    manager_server_Xpath = "(//input[@type='text'])[3]"
    manager_username_Xpath = "(//input[@type='text'])[4]"
    manager_password_Xpath = "//input[@type='password']"
    save_button_Xpath = "//div[contains(text(),'Save')]"



    def __init__(self,driver):
        self.driver = driver

    def createEnvAction(self):
        self.driver.find_element(By.XPATH,self.env_create_Xpath).click()

    def kubernetes_env(self):
        self.driver.find_element(By.XPATH,self.env_Kubernetes).click()

    def environment_name(self,env_name):
        self.driver.find_element(By.XPATH,self.env_Name).send_keys(env_name)

    def save_button(self):
        self.driver.find_element(By.XPATH,self.save_button_Xpath).click()

    def createLoadGenAction(self):
        self.driver.find_element(By.XPATH,self.loadGen_create_Xpath).click()

    def landslide_loadGen(self):
        self.driver.find_element(By.XPATH,self.loadGen_Landslide_Xpath).click()

    def landslide_managerServer(self,server_name):
        self.driver.find_element(By.XPATH,self.manager_server_Xpath).send_keys(server_name)

    def landslide_managerUsername(self,manager_Username):
        self.driver.find_element(By.XPATH,self.manager_username_Xpath).send_keys(manager_Username)

    def landslide_managerPassword(self,manager_Password):
        self.driver.find_element(By.XPATH,self.manager_password_Xpath).send_keys(manager_Password)

