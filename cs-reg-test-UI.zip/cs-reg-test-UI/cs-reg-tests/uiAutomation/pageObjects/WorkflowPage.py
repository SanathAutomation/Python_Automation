import time

from selenium.webdriver.common.by import By
class WorkFlowPageClass:
    test_Builder_Xpath = "//div[contains(text(),'Test Builder')]"
    profiles_MenuBar_Xpath = "//div[contains(text(),'Profiles')]"
    actions_MenuBar_Xpath = "//div[contains(text(),'Actions')]"
    environment_Namespace_Xpath = "//div[contains(text(),'Namespace')]/../div[starts-with(@class,'button')]"
    environment_Workload_Xpath = "//div[contains(text(),'Workload')]/../div[starts-with(@class,'button')]"
    environment_Pod_Xpath = "//div[contains(text(),'Pod')]/../div[starts-with(@class,'button')]"
    environment_refresh_Xpath = "//div[contains(text(),'Refresh')]/../div[starts-with(@class,'button')]"
    remove_env_hamburger_Xpath = "//div[starts-with(@class,'environment-block_menu')]"
    remove_env_action_Xpath = "//div[contains(text(),'Remove Environment')]"
    remove_env_warning_Xpath = "//div[contains(text(),'Remove')]/../div[starts-with(@class,'button')]"
    lgServerIP_Xpath = "(//span[starts-with(@class,'load-generator-block_value')])[1]"
    lgPort_Xpath = "(//span[starts-with(@class,'load-generator-block_value')])[2]"
    lgUsername_Xpath = "(//span[starts-with(@class,'load-generator-block_value')])[3]"
    lgViewConfig_Xpath = "//div[contains(text(),'View Configurations')]"
    lgLibraryDropdown_Xpath = "//label[contains(text(),'Library')]/../div"
    lgTestSessionDropdown_Xpath = "(//div[starts-with(@class,'load-gen-view-config_dropdownField')])[2]"
    testSessionConfig_Preview_Xpath = "//div[contains(text(),'Preview File')]"
    cancelTestSession_lg_Xpath = "//div[contains(text(),'Cancel')]"
    lgHamburger_Xpath = "//div[starts-with(@class,'load-generator-block_menu')]"
    removeLg_Xpath = "//div[contains(text(),'Remove Load Generator')]"
    smsLibraryDropdown_Xpath = "//div[contains(text(),'sms')]"
    firstTestSessionDropdown_Xpath = "(//div[contains(text(),'AO-T01-01_Basic_Services_MME_1000_Sessions')])[1]"
    library_id_startLandslide_Xpath = "(//*[starts-with(@class,'button_arrowIcon')])[2]"
    library_id_sms_Xpath = "//div[contains(text(),'sms')]"
    testSessionNameDropdown_Xpath = "//*[starts-with(@class,'editable-dropdown_arrowDownIcon')]"
    testSessionNameValue_Xpath = "//div[contains(text(),'AO-T01-01_Basic_Services_MME_1000_Sessions')]"
    startLandslide_duration_Xpath = "//label[contains(text(),'Duration (sec)')]/../following-sibling::div/button/following-sibling::div/div/div/input"
    testServer_ID_Xpath = "//label[contains(text(),'Test Server ID')]/../following-sibling::button"
    testServerID_Dropdown_Xpath = "(//div[starts-with(@class,'item_root')])[1]"



    def __init__(self,driver):
        self.driver = driver

    def testBuilderAction(self):
        self.driver.find_element(By.XPATH,self.test_Builder_Xpath).click()

    def profiles_Menubar(self):
        self.driver.find_element(By.XPATH,self.profiles_MenuBar_Xpath)

    def actions_Menubar(self):
        self.driver.find_element(By.XPATH,self.actions_MenuBar_Xpath).click()

    def namespace_env(self):
        self.driver.find_element(By.XPATH,self.environment_Namespace_Xpath).click()

    def workload_env(self):
        self.driver.find_element(By.XPATH,self.environment_Workload_Xpath).click()

    def pod_env(self):
        self.driver.find_element(By.XPATH,self.environment_Pod_Xpath).click()

    def refresh_env(self):
        self.driver.find_element(By.XPATH,self.environment_refresh_Xpath).click()

    def remove_env(self):
        self.driver.find_element(By.XPATH,self.remove_env_hamburger_Xpath).click()

    def remove_env_action(self):
        self.driver.find_element(By.XPATH,self.remove_env_action_Xpath).click()

    def remove_env_warning(self):
        self.driver.find_element(By.XPATH,self.remove_env_warning_Xpath).click()

    def lgServerIP(self):
        self.driver.find_element(By.XPATH,self.lgServerIP_Xpath)

    def lgPortNumber(self):
        self.driver.find_element(By.XPATH,self.lgPort_Xpath)

    def lgUsername(self):
        self.driver.find_element(By.XPATH,self.lgUsername_Xpath)

    def lgViewConfigurations(self):
        self.driver.find_element(By.XPATH,self.lgViewConfig_Xpath).click()

    def lgLibraryDropdown(self):
        self.driver.find_element(By.XPATH, self.lgLibraryDropdown_Xpath).click()

    def lgTestSessionDropdown(self):
        self.driver.find_element(By.XPATH, self.lgTestSessionDropdown_Xpath).click()

    def testSessionPreviewFile(self):
        self.driver.find_element(By.XPATH, self.testSessionConfig_Preview_Xpath).click()

    def testSessionCancel(self):
        self.driver.find_element(By.XPATH, self.cancelTestSession_lg_Xpath).click()

    def lgHamburger(self):
        self.driver.find_element(By.XPATH, self.lgHamburger_Xpath).click()

    def removeLG(self):
        self.driver.find_element(By.XPATH, self.removeLg_Xpath).click()

    def smsLibraryDropdown(self):
        self.driver.find_element(By.XPATH, self.smsLibraryDropdown_Xpath).click()

    def firstTestSessionDropdown(self):
        self.driver.find_element(By.XPATH, self.firstTestSessionDropdown_Xpath).click()

    def libraryId_startLandslide_Dropdown(self):
        self.driver.find_element(By.XPATH, self.library_id_startLandslide_Xpath).click()    

    def libraryId_sms_Dropdown(self):
        self.driver.find_element(By.XPATH, self.library_id_sms_Xpath).click()   

    def testSessionName_Dropdown(self):
        self.driver.find_element(By.XPATH, self.testSessionNameDropdown_Xpath).click()   

    def testSessionName_Value(self):
        self.driver.find_element(By.XPATH, self.testSessionNameValue_Xpath).click()

    def startLandslide_Duration(self,duration):
        self.driver.find_element(By.XPATH, self.startLandslide_duration_Xpath).send_keys(duration)   

    def testServerID(self):
        self.driver.find_element(By.XPATH, self.testServer_ID_Xpath).click()  

    def testServerID_dropdown(self):
        self.driver.find_element(By.XPATH, self.testServerID_Dropdown_Xpath).click()        
