import time

from selenium.webdriver.common.by import By
class MetricsCollectionPageClass:
    cAdvisor_toggle_Xpath = "(//div[starts-with(@class,'switch-button_root')])[2]"
    nodeExporter_toggle_Xpath = "(//div[starts-with(@class,'switch-button_root')])[3]"
    kubeState_toggle_Xpath = "(//div[starts-with(@class,'switch-button_root')])[4]"
    cAdvisor_Expand_Xpath = "//*[contains(text(),'cAdvisor')]/../../following-sibling::div"
    cAdvisor_namespace_textbox = "//input[@placeholder='Start typing to filter list or Add New']"
    cAdvisor_selectNS_Xpath = "(//div[starts-with(@class,'namespace-filter_filterItem')])[1]"
    cAdvisor_AddSelected_Xpath = "//div[contains(text(),'Add Selected')]"
    

    def __init__(self,driver):
        self.driver = driver

    def cAdvisorToggleAction(self):
        self.driver.find_element(By.XPATH,self.cAdvisor_toggle_Xpath).click()

    def cAdvisorExpandAction(self):
        self.driver.find_element(By.XPATH,self.cAdvisor_Expand_Xpath).click() 

    def cAdvisorNamespaceTextbox(self,namespace):
        self.driver.find_element(By.XPATH,self.cAdvisor_namespace_textbox).send_keys(namespace)

    def cAdvisorNamespaceSelect(self):
        self.driver.find_element(By.XPATH,self.cAdvisor_selectNS_Xpath).click()  

    def cAdvisorAddSelectedNS(self):
        self.driver.find_element(By.XPATH,self.cAdvisor_AddSelected_Xpath).click()    
