import time

from selenium.webdriver.common.by import By
class LandingPageClass:
    aionProducts_Xpath = "//div[starts-with(@class,'landing-page-block-item-module_root')]"
    settingsIcon_Xpath = "//div[@class='b-icon-actn-cog b-icon-actn-cog_main-toolbar']"
    userAccount_xpath = "//span[@class='b-user-account-label']"
    myAccount_xpath = "//div[contains(text(),'My Account')]"
    userManagement_xpath = "(//div[contains(text(),'User Management')])[2]"
    signout_xpath = "//div[contains(text(),'Sign Out')]"
    product_Instance_xpath = "//div[starts-with(@class,'instances-list-row-module_root')]"
    launch_product_button = "(//div[contains(text(),'Launch Product')])[2]"


    def __init__(self,driver):
        self.driver = driver

    def aion_products_cloudsure(self):
        self.driver.find_element(By.XPATH,self.aionProducts_Xpath).click()

    def product_instance_cloudsure(self):
        self.driver.find_element(By.XPATH,self.product_Instance_xpath).click()

    def launch_product_cloudsure(self):
        self.driver.find_element(By.XPATH,self.launch_product_button).click()

    def goto_userAccount(self):
        self.driver.find_element(By.XPATH,self.userAccount_xpath).click()

    def signOut_Button(self):
        self.driver.find_element(By.XPATH,self.signout_xpath).click()

