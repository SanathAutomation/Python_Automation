import time

from selenium.webdriver.common.by import By
class ScenarioBuilderPageClass:
    advanced_startLandslide_Xpath = "//div[contains(text(),'Advanced')]"
    iteration_values_Xpath = "//label[contains(text(),'Iteration')]/../following-sibling::div/div/div/input"
    initial_intervalPeriodDropdown_Xpath = "//label[contains(text(),'Initial Interval Period (sec)')]/../following-sibling::button"
    initial_interval_value_Xpath = "(//div[starts-with(@class,'item_root__2WAfs item_mRootIsText')])[3]"
    testServerIdDropdown_Xpath = "//label[contains(text(),'Test Server ID')]/../following-sibling::button"
    testServerID_values_Xpath = "(//div[starts-with(@class,'item_root')])[1]"
    custom_startLandslide_Xpath = "//div[contains(text(),'Custom')]"
    custom_selectFile_Xpath = "//div[contains(text(),'Select file')]"
    testSessionOverrideConfigFile_Xpath = "(//div[starts-with(@class,'radio-button_root')])[1]"
    update_CustomConfigFile_Xpath = "//div[contains(text(),'Update')]"
    format_Xpath = "//label[contains(text(),'Format')]/../following-sibling::button"
    format_Dropdown_Xpath = "(//div[starts-with(@class,'item_root')])[2]"
    namespace_Dropdown_Xpath = "(//input[@type='text'])[3]"
    podSelection_Dropdown_Xpath = "(//input[@type='text'])[4]"
    containerSelection_Dropdown_Xpath = "(//input[@type='text'])[5]"
    namespace_list_Xpath = "//div[starts-with(@class,'editable-dropdown_menuItem_')]"
    addTarget_Xpath = "//div[contains(text(),'Add target')]"
    affected_Pod_Xpath = "//*[contains(text(),'Affected Pods')]/../div/div/div/div/input"
    recovery_timeout_Xpath = "//*[contains(text(),'Recovery Timeout')]/../div/div/input"
    pod_selection_Xpath = "(//div[starts-with(@class,'scenario-target-block_controlDropdown')]/button)[1]"
    container_selection_Xpath = "(//div[starts-with(@class,'scenario-target-block_controlDropdown')]/button)[2]"
    podName_select_Xpath = "(//div[starts-with(@class,'panel_itemsContainer')]/div)[2]"
    firstPodName_select_Xpath = "(//div[starts-with(@class,'editable-dropdown_menuItem__')])[1]"
    network_device_input_Xpath = "//*[contains(text(),'Network Device')]/../div/div/input"
    rateLimit_input_Xpath = "//*[contains(text(),'Rate Limit (mbits)')]/../div/div/input"
    packetLoss_input_Xpath = "//*[contains(text(),'Packet Loss')]/../div/div/input"
    duration_input_Xpath = "//*[contains(text(),'Duration')]/../div/div/input"

    


    

    def __init__(self,driver):
        self.driver = driver

    def advanced_startLandslide(self):
        self.driver.find_element(By.XPATH,self.advanced_startLandslide_Xpath).click()

    def iteration_values(self,value):
        self.driver.find_element(By.XPATH,self.iteration_values_Xpath).send_keys(value) 

    def initialIntervalPeriodDropdown(self):
        self.driver.find_element(By.XPATH,self.initial_intervalPeriodDropdown_Xpath).click()  

    def initialIntervalPeriodValue(self):
        self.driver.find_element(By.XPATH,self.initial_interval_value_Xpath).click()  

    def testServerID(self):
        self.driver.find_element(By.XPATH,self.testServerIdDropdown_Xpath).click()   

    def testServerIDValues(self):
        self.driver.find_element(By.XPATH,self.testServerID_values_Xpath).click()   

    def custom_startLandslide(self):
        self.driver.find_element(By.XPATH,self.custom_startLandslide_Xpath).click()    

    def custom_selectFile(self):
        self.driver.find_element(By.XPATH,self.custom_selectFile_Xpath).click() 

    def custom_TestSessionOverrideConfigFile(self):
        self.driver.find_element(By.XPATH,self.testSessionOverrideConfigFile_Xpath).click()

    def update_TestSessionOverrideConfigFile(self):
        self.driver.find_element(By.XPATH,self.update_CustomConfigFile_Xpath).click() 

    def formatDropdown(self):
        self.driver.find_element(By.XPATH,self.format_Xpath).click()  

    def formatDropdownValues(self):
        self.driver.find_element(By.XPATH,self.format_Dropdown_Xpath).click()   

    def namespace_value(self,value):
        self.driver.find_element(By.XPATH,self.namespace_Dropdown_Xpath).send_keys(value)   

    def namespace_list(self):
        self.driver.find_element(By.XPATH,self.namespace_list_Xpath).click()    

    def addTarget(self):
        self.driver.find_element(By.XPATH,self.addTarget_Xpath).click()  

    def affectedPod(self,value1):
        self.driver.find_element(By.XPATH,self.affected_Pod_Xpath).send_keys(value1)  

    def recoveryTimeout(self,value2):
        self.driver.find_element(By.XPATH,self.recovery_timeout_Xpath).send_keys(value2) 

    def podSelectionDropdown(self):
        self.driver.find_element(By.XPATH,self.pod_selection_Xpath).click() 

    def podSelectionName(self):
        self.driver.find_element(By.XPATH,self.podName_select_Xpath).click()    

    def selectPodNameDropdown(self):
        self.driver.find_element(By.XPATH,self.podSelection_Dropdown_Xpath).click()   

    def selectFirstPodName(self):
        self.driver.find_element(By.XPATH,self.firstPodName_select_Xpath).click()  

    def containerSelectionDropdown(self):
        self.driver.find_element(By.XPATH,self.container_selection_Xpath).click()  

    def selectContainerNameDropdown(self):
        self.driver.find_element(By.XPATH,self.containerSelection_Dropdown_Xpath).click() 

    def networkDevice(self,network_device):
        self.driver.find_element(By.XPATH,self.network_device_input_Xpath).send_keys(network_device)    

    def RateLimit_mbits(self,rate_limit_value):
        self.driver.find_element(By.XPATH,self.rateLimit_input_Xpath).send_keys(rate_limit_value)       

    def PacketLossPercent(self,packetLoss_value):
        self.driver.find_element(By.XPATH,self.packetLoss_input_Xpath).send_keys(packetLoss_value)               

    def Duration_sec(self,duration):
        self.driver.find_element(By.XPATH,self.duration_input_Xpath).send_keys(duration)     








