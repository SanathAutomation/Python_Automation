#!/bin/bash
# File to validate the Jenkins file locally
VALIDATE_URL=https://jenkins01.oriondev.net/pipeline-model-converter/validate
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null && pwd )"

curl -X POST -F "jenkinsfile=<cs-regression-ocp01-Jenkinsfile" $VALIDATE_URL
curl -X POST -F "jenkinsfile=<cs-regression-okd03-Jenkinsfile" $VALIDATE_URL
curl -X POST -F "jenkinsfile=<cs-regression-open5gs-k3s-Jenkinsfile" $VALIDATE_URL
curl -X POST -F "jenkinsfile=<cs-regressionUI-Jenkinsfile" $VALIDATE_URL
