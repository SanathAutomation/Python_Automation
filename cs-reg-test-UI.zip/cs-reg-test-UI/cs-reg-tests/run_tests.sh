#!/bin/bash
set -euo pipefail

# Run the unit tests with additional checks
python3 -m pytest \
    --pycodestyle \
    --isort \
    --flakes \
    --mypy \
    --ruff \
    --cache-clear \
    --cov=. \
    --cov-branch \
    --cov-report term-missing \
    --cov-report xml:build/coverage.xml \
    --junitxml=build/pytest.xml \
    --ignore=./tests \
    --ignore=./uiAutomation \
    "$@"
